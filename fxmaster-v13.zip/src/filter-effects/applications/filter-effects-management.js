import { FXMasterBaseFormV2 } from "../../base-form.js";
import { packageId } from "../../constants.js";
import { prepareFilterOptionsForSceneStorage, resetFlag, updateSceneControlHighlights } from "../../utils.js";
import { logger } from "../../logger.js";
import { getHiddenEffectsCount, openEffectsVisibilityManager } from "../../common/effects-visibility-manager.js";
import { buildSceneEffectUid, promoteEffectStackUids } from "../../common/effect-stack.js";
import { FilterEffectsSceneManager } from "../filter-effects-scene-manager.js";

/**
 * Extract an effect parameter name from a management input name.
 *
 * @param {string|null|undefined} inputName
 * @param {object} filterDB
 * @returns {string|null}
 */
function parameterNameFromInputName(inputName, filterDB) {
  const raw = String(inputName ?? "");
  if (!raw) return null;

  for (const paramName of Object.keys(filterDB?.parameters ?? {})) {
    if (raw.endsWith(`_${paramName}`) || raw.endsWith(`_${paramName}_apply`)) return paramName;
    if (raw.endsWith(`_${paramName}_min`) || raw.endsWith(`_${paramName}_max`)) return paramName;
  }

  return null;
}

function refreshFilterEffectControls(effectDef) {
  try {
    effectDef?.refreshManualPlacementControl?.();
  } catch (err) {
    logger.debug("FXMaster:", err);
  }
}

export class FilterEffectsManagement extends FXMasterBaseFormV2 {
  static FXMASTER_DETACHED_WINDOW_FIT = true;
  static FXMASTER_POSITION_FLAG = "dialog-position-filtereffects";
  /** @type {FilterEffectsManagement|undefined} */
  static #instance;

  /** @returns {FilterEffectsManagement|undefined} */
  static get instance() {
    return this.#instance;
  }

  constructor(scene, options = {}) {
    super(options);
    FilterEffectsManagement.#instance = this;
    this.scene = scene;
  }

  static DEFAULT_OPTIONS = {
    id: "filters-config",
    tag: "section",
    classes: ["fxmaster", "form-v2", "ui-control"],
    actions: {
      updateParam: FilterEffectsManagement.updateParam,
      filterEffectAction: FilterEffectsManagement.filterEffectAction,
      openHideEffects: FilterEffectsManagement.openHideEffects,
    },
    window: {
      title: "FXMASTER.Common.FilterEffectsManagementTitle",
      resizable: true,
      minimizable: true,
      controls: [
        {
          icon: "fas fa-eye-slash",
          label: "FXMASTER.Common.HideEffects",
          action: "openHideEffects",
          visible: () => true,
        },
      ],
    },
    position: {
      width: 325,
      height: "auto",
    },
  };

  static PARTS = [
    {
      template: "modules/fxmaster/templates/filter-effects-management.hbs",
    },
  ];

  async _prepareContext() {
    const currentFilters = canvas.scene?.getFlag(packageId, "filters") ?? {};

    const currentCoreFilters = Object.entries(currentFilters)
      .filter(([id, filter]) => id?.startsWith?.("core_") && filter?.type)
      .map(([, filter]) => filter);

    const activeFilters = Object.fromEntries(currentCoreFilters.map((filter) => [filter.type, filter.options]));

    const activeFilterTypes = new Set(currentCoreFilters.map((filter) => filter.type));

    const hidden = game.user.getFlag(packageId, "hiddenFilterEffects");
    const hiddenFilterEffects = new Set(Array.isArray(hidden) ? hidden : []);

    const passiveFilters = foundry.utils.deepClone(game.settings.get(packageId, "passiveFilterConfig") ?? {});
    for (const options of Object.values(passiveFilters)) {
      if (options && typeof options === "object") delete options.levels;
    }

    const filters = Object.fromEntries(
      Object.entries(CONFIG.fxmaster.filterEffects)
        .filter(([type]) => !hiddenFilterEffects.has(type) || activeFilterTypes.has(type))
        .sort(([, a], [, b]) => game.i18n.localize(a.label).localeCompare(game.i18n.localize(b.label))),
    );

    return {
      filters,
      activeFilters,
      passiveFilters,
    };
  }

  /**
   * Open the per-user filter visibility manager.
   * @returns {void}
   */
  static openHideEffects() {
    openEffectsVisibilityManager({
      kind: "filter",
      onChange: async () => FilterEffectsManagement.instance?.render(true),
    });
  }

  /**
   * Invoke a filter effect-provided action from an effect option row.
   *
   * @param {PointerEvent} event
   * @param {HTMLElement} button
   * @returns {Promise<void>}
   */
  static async filterEffectAction(event, button) {
    event?.preventDefault?.();
    event?.stopPropagation?.();

    const action = button?.dataset?.effectAction;
    const row = button?.closest?.(".fxmaster-filter-expand")?.previousElementSibling;
    const type =
      button?.dataset?.effectType ?? button?.closest?.("[data-effect-type]")?.dataset?.effectType ?? row?.dataset?.type;
    if (!type || !action) return;

    const effectDef = CONFIG.fxmaster?.filterEffects?.[type];
    if (!effectDef) {
      logger.warn(game.i18n.format("FXMASTER.Filters.TypeErrors.TypeNotFound", { type }));
      return;
    }

    const parameterActions = Object.values(effectDef.parameters ?? {}).flatMap((parameter) =>
      Array.isArray(parameter?.actions) ? parameter.actions : [],
    );
    const actions = [
      ...(Array.isArray(effectDef.managementActions) ? effectDef.managementActions : []),
      ...(Array.isArray(effectDef.filterActions) ? effectDef.filterActions : []),
      ...parameterActions,
    ];
    const actionDef = actions.find((entry) => entry?.action === action);
    if (!actionDef) return;

    const getOptions = () => {
      try {
        return FXMasterBaseFormV2.gatherFilterOptions(
          effectDef,
          this?.element ?? button?.closest?.(".fxmaster-filter-expand") ?? document,
        );
      } catch (err) {
        logger.debug("FXMaster:", err);
        try {
          const current = canvas?.scene?.getFlag?.(packageId, "filters") ?? {};
          return foundry.utils.deepClone(current[`core_${type}`]?.options ?? {});
        } catch (fallbackErr) {
          logger.debug("FXMaster:", fallbackErr);
          return {};
        }
      }
    };

    const context = {
      app: this,
      scene: canvas?.scene ?? null,
      type,
      action,
      actionDef,
      button,
      event,
      getOptions,
      options: getOptions(),
    };

    try {
      if (typeof actionDef.handler === "string" && typeof effectDef[actionDef.handler] === "function") {
        await effectDef[actionDef.handler](context);
      } else if (typeof effectDef.handleManagementAction === "function") {
        await effectDef.handleManagementAction(action, context);
      } else if (typeof actionDef.onClick === "function") {
        await actionDef.onClick(context);
      }
    } catch (err) {
      logger.error("FXMaster | Filter effect action failed", err);
    }
  }

  /**
   * Update the Hide Effects header control tooltip with the current hidden count.
   * @returns {void}
   */
  _updateHideEffectsTooltip() {
    const count = getHiddenEffectsCount("filter");
    const tooltip = game.i18n.format("FXMASTER.Common.HideEffectsTooltip", { count });

    const control =
      this.element?.querySelector?.('.window-header [data-action="openHideEffects"]') ??
      this.element?.querySelector?.('[data-action="openHideEffects"]') ??
      null;

    if (control) control.dataset.tooltip = tooltip;
  }

  async _onRender(...args) {
    await super._onRender(...args);

    const element = this.element;
    if (!element?.isConnected) return;

    this._updateHideEffectsTooltip();

    const pos = this._fxmIsDetachedHost() ? null : game.user.getFlag(packageId, "dialog-position-filtereffects");
    if (pos) {
      await new Promise((r) => requestAnimationFrame(r));

      const liveElement = this.element;
      if (!liveElement?.isConnected) return;

      const next = { top: pos.top, left: pos.left };
      if (Number.isFinite(pos.width)) next.width = pos.width;

      try {
        this.setPosition(next);
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
    }

    const liveElement = this.element;
    if (!liveElement?.isConnected) return;

    const content = liveElement.querySelector(".window-content") ?? liveElement;

    this._wireRangeWheelBehavior({
      getScrollWrapper: (slider) => slider.closest(".fxmaster-filters-container") ?? content,
      onInput: (event, slider) => FilterEffectsManagement.updateParam.call(this, event, slider),
    });

    this.wireColorInputs(liveElement, FilterEffectsManagement.updateParam);
    this.wireMultiSelectInputs?.(liveElement, FilterEffectsManagement.updateParam);
    this.wireSelectInputs?.(liveElement, FilterEffectsManagement.updateParam);
    this.wirePowerToggleResetMenu(liveElement, {
      selector: ".fxmaster-filter-toggle",
      onReset: this.resetEffectDefaults,
    });
    this.applyTooltipDirection(liveElement);
    for (const effectDef of Object.values(CONFIG.fxmaster.filterEffects ?? {})) refreshFilterEffectControls(effectDef);
  }

  /**
   * Reset one filter effect's management parameters to its authored defaults.
   *
   * @param {string} type
   * @returns {Promise<void>}
   */
  async resetEffectDefaults(type) {
    const filtersDB = CONFIG.fxmaster.filterEffects[type];
    if (!filtersDB) {
      logger.warn(game.i18n.format("FXMASTER.Filters.TypeErrors.TypeNotFound", { type }));
      return;
    }

    try {
      for (const fn of this._debouncedFiltersWrites?.values?.() ?? []) fn?.cancel?.();
      this._debouncedFiltersWrites?.clear?.();
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    const defaults = FXMasterBaseFormV2.getDefaultOptions(filtersDB);
    const passiveDefaults = foundry.utils.deepClone(defaults);
    if (passiveDefaults && typeof passiveDefaults === "object") delete passiveDefaults.levels;

    const existingPassive = foundry.utils.deepClone(game.settings.get(packageId, "passiveFilterConfig") ?? {});
    const passiveFilters =
      existingPassive && typeof existingPassive === "object" && !Array.isArray(existingPassive) ? existingPassive : {};
    passiveFilters[type] = passiveDefaults;
    await game.settings.set(packageId, "passiveFilterConfig", passiveFilters);

    const scene = canvas.scene;
    const effectId = `core_${type}`;
    if (scene) {
      const current = foundry.utils.duplicate(scene.getFlag(packageId, "filters") ?? {});
      if (current[effectId]) {
        const options = prepareFilterOptionsForSceneStorage(type, foundry.utils.deepClone(defaults), {
          forceRestart: true,
        });
        current[effectId] = { type, options };
        await resetFlag(scene, "filters", current);
        await FilterEffectsSceneManager.instance.update({ skipFading: true });
      }
    }

    updateSceneControlHighlights();
    const label = game.i18n.localize(filtersDB.label ?? type);
    ui.notifications.info(game.i18n.format("FXMASTER.Common.ResetEffectDefaultsSuccess", { effect: label }));
    await this.render(true);
  }

  async close(options) {
    const passive = {};

    for (const [type, filterDB] of Object.entries(CONFIG.fxmaster.filterEffects)) {
      const optionsObj = FilterEffectsManagement.gatherFilterOptions(filterDB, this.element);
      if (optionsObj && typeof optionsObj === "object") delete optionsObj.levels;
      passive[type] = optionsObj;
    }

    game.settings.set(packageId, "passiveFilterConfig", passive);

    for (const effectDef of Object.values(CONFIG.fxmaster.filterEffects ?? {})) {
      try {
        await effectDef?.handleManagementClose?.({ app: this, scene: this.scene ?? canvas?.scene ?? null });
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
    }

    return super.close(options);
  }

  async updateEnabledState(type, enabled) {
    const filtersDB = CONFIG.fxmaster.filterEffects[type];
    if (!filtersDB) {
      logger.warn(game.i18n.format("FXMASTER.Filters.TypeErrors.TypeNotFound", { type: type }));
      return;
    }

    refreshFilterEffectControls(filtersDB);
    const scene = canvas.scene;
    if (!scene) return;
    const current = foundry.utils.duplicate(scene.getFlag(packageId, "filters") ?? {});

    const effectId = `core_${type}`;

    if (enabled) {
      const gatheredOptions = FilterEffectsManagement.gatherFilterOptions(filtersDB, this.element);
      const options = prepareFilterOptionsForSceneStorage(type, gatheredOptions, { forceRestart: true });
      current[effectId] = { type, options };
    } else {
      delete current[effectId];
    }

    await resetFlag(scene, "filters", current);

    if (enabled) {
      await promoteEffectStackUids([buildSceneEffectUid("filter", effectId)], scene);
    }

    updateSceneControlHighlights();
  }

  static async updateParam(event, input) {
    const control =
      (input?.name ? input : null) || input?.closest?.("[name]") || event?.target?.closest?.("[name]") || null;

    if (!control?.name) return;
    FXMasterBaseFormV2.updateRangeOutput(control);

    const type = control.closest(".fxmaster-filter-expand")?.previousElementSibling?.dataset?.type;
    if (!type) return;

    const filterDB = CONFIG.fxmaster.filterEffects[type];
    if (!filterDB) return;

    const parameterSection = control.closest(".fxmaster-filter-expand") ?? this.element;
    const syncControl = parameterSection?.querySelector?.(`[name$="_synchronizedDirection"]`) ?? null;
    const syncValue = syncControl?.type === "checkbox" ? syncControl.checked : syncControl?.value;
    FXMasterBaseFormV2.refreshSynchronizedDirectionControls(parameterSection, filterDB, {
      synchronizedDirection: syncValue,
    });
    refreshFilterEffectControls(filterDB);

    const scene = canvas.scene;
    if (!scene) return;
    const sceneId = scene.id ?? null;
    const current = foundry.utils.duplicate(scene.getFlag(packageId, "filters") ?? {});
    const isActive = !!current[`core_${type}`];
    if (!isActive) return;

    const isMultiSelect =
      control?.matches?.("multi-select, select[multiple]") ||
      !!control?.closest?.("multi-select") ||
      (event?.target && !!event.target.closest?.("multi-select"));

    if (isMultiSelect) {
      await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));
    } else {
      await new Promise(requestAnimationFrame);
    }

    const previousOptions = foundry.utils.deepClone(current[`core_${type}`]?.options ?? {});
    const gatheredOptions = FilterEffectsManagement.gatherFilterOptions(filterDB, this.element);
    const changedParam = parameterNameFromInputName(control.name, filterDB);
    const options = prepareFilterOptionsForSceneStorage(type, gatheredOptions, { previousOptions, changedParam });
    FXMasterBaseFormV2.refreshSynchronizedDirectionControls(control.closest(".fxmaster-filter-expand"), filterDB, options);

    const writeOptions = async ({ sceneId, type, options, refresh = false }) => {
      try {
        const scene = sceneId ? game.scenes?.get?.(sceneId) ?? null : null;
        if (!scene) return;
        const cur = foundry.utils.duplicate(scene.getFlag(packageId, "filters") ?? {});
        if (!cur[`core_${type}`]) return;

        const prev = cur[`core_${type}`]?.options ?? {};
        const a = foundry.utils.diffObject(prev, options);
        const b = foundry.utils.diffObject(options, prev);
        const shouldRefresh = refresh && canvas?.scene?.id === sceneId;
        if (foundry.utils.isEmpty(a) && foundry.utils.isEmpty(b)) {
          if (shouldRefresh) await FilterEffectsSceneManager.instance.update({ skipFading: true });
          return;
        }

        cur[`core_${type}`].options = options;
        await resetFlag(scene, "filters", cur);
        if (shouldRefresh) await FilterEffectsSceneManager.instance.update({ skipFading: true });
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
    };

    if (String(control.name).endsWith("_levels")) {
      await writeOptions({ sceneId, type, options: foundry.utils.deepClone(options), refresh: true });
      return;
    }

    this._debouncedFiltersWrites ??= new Map();
    const debounceKey = `${sceneId ?? "scene"}:${type}`;
    let debouncedWrite = this._debouncedFiltersWrites.get(debounceKey);
    if (!debouncedWrite) {
      debouncedWrite = foundry.utils.debounce(writeOptions, 150);
      this._debouncedFiltersWrites.set(debounceKey, debouncedWrite);
    }

    debouncedWrite({ sceneId, type, options: foundry.utils.deepClone(options) });
  }

  _storeCurrentPosition() {
    this._persistPositionFlag(this.position);
  }

  async _onClose(...args) {
    super._onClose(...args);
    this._storeCurrentPosition();
    try {
      if (FilterEffectsManagement.instance === this) FilterEffectsManagement.#instance = undefined;
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
  }
}
