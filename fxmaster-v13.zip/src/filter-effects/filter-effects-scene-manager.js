/**
 * FilterEffectsSceneManager
 * -------------------------
 * Manages scene-scoped filter runtimes for FXMaster.
 * - Creates, updates, and destroys scene filter instances from scene flags.
 * - Maintains suppression masks and viewport uniforms.
 * - Exposes live runtime lookups for the global compositor stack.
 */
import { packageId } from "../constants.js";
import { logger } from "../logger.js";
import {
  resetFlag,
  deletionUpdate,
  _belowTokensEnabled,
  _belowTilesEnabled,
  _belowForegroundEnabled,
  applyMaskUniformsToFilters,
  coalesceNextFrame,
  getCssViewportMetrics,
  getSnappedCameraCss,
  snappedStageMatrix,
  cameraMatrixChanged,
  getSceneDarknessLevel,
  isEffectActiveForSceneDarkness,
  isEffectActiveForCurrentOrVisibleCanvasLevel,
  getCanvasLiveLevelSurfaceState,
  buildBelowTokenMaskCoverageSignature,
  buildBelowTileMaskCoverageSignature,
  getSelectedSceneLevelIds,
  normalizeSceneLevelSelection,
  ensureSingleSceneLevelSelection,
  prepareFilterOptionsForSceneStorage,
} from "../utils.js";

import { SceneMaskManager } from "../common/base-effects-scene-manager.js";
import { applyRegionBehaviorsToOverheadLevels } from "../settings.js";
import {
  buildSceneEffectUid,
  getOrderedEnabledEffectRenderRows,
  hasStackedSuppressionAffectingSceneRows,
  promoteEffectStackUids,
} from "../common/effect-stack.js";

function isBelowTokensFilter(f) {
  return _belowTokensEnabled(f?.__fxmBelowTokens ?? f?.options?.belowTokens);
}

function isBelowTilesFilter(f) {
  return _belowTilesEnabled(f?.__fxmBelowTiles ?? f?.options?.belowTiles);
}

/**
 * Extract a normalized Level selection from a live scene-filter runtime.
 *
 * @param {object|null|undefined} filter
 * @returns {*}
 * @private
 */
function _runtimeFilterLevelsValue(filter) {
  return (
    filter?.__fxmLevels?.value ??
    filter?.__fxmLevels ??
    filter?.__fxmOptions?.levels?.value ??
    filter?.__fxmOptions?.levels ??
    filter?.options?.levels?.value ??
    filter?.options?.levels ??
    null
  );
}

/**
 * Return the union of explicit Level ids selected by all active scene filters. A null return means at least one scene filter applies to all Levels.
 *
 * @param {object[]} filters
 * @returns {Set<string>|null}
 * @private
 */
function _collectSelectedSceneFilterLevelIds(filters) {
  const selected = new Set();
  for (const filter of filters ?? []) {
    const levels = getSelectedSceneLevelIds(_runtimeFilterLevelsValue(filter), canvas?.scene ?? null);
    if (!levels?.size) return null;
    for (const levelId of levels) selected.add(String(levelId));
  }
  return selected;
}

/**
 * Return whether active suppress-scene-filters Regions can affect the supplied scene-filter runtimes. This mirrors the scene-particle Level intersection gate and avoids rebuilding the expensive scene allow mask while panning when, for example, a Level 2 suppression Region is present but active scene filters are explicitly assigned to Levels 1 & 3.
 *
 * @param {object[]} filters
 * @returns {boolean}
 * @private
 */
function _hasRelevantSuppressionForSceneFilters(filters) {
  try {
    if (!filters?.length) return false;
    if (!hasStackedSuppressionAffectingSceneRows(canvas?.scene, "filters")) return false;
    const selectedLevels = _collectSelectedSceneFilterLevelIds(filters);
    const manager = SceneMaskManager.instance;
    if (typeof manager.hasSuppressionRegionsForLevelSelection === "function") {
      return manager.hasSuppressionRegionsForLevelSelection("filters", selectedLevels);
    }
    return !!manager.hasSuppressionRegions?.("filters");
  } catch (err) {
    logger.debug("FXMaster:", err);
    return !!SceneMaskManager.instance.hasSuppressionRegions?.("filters");
  }
}

/**
 * Return whether the global compositor can handle scene-filter suppression for the supplied filter runtimes without requiring the shared scene allow-mask.
 *
 * This is intentionally limited to explicit-Level, no-below-object filters while the overhead-Level Region behavior path is enabled. In that case the compositor already renders each scene filter through selected Level masks, so it can restore the pre-filter pixels for overlapping suppress Regions in the same Level-local pass. Avoiding the shared scene mask prevents the expensive full overlay-preservation rebuild on every camera movement.
 *
 * @param {object[]} filters
 * @param {{anyBelow?: boolean, anyBelowTiles?: boolean, hasRelevantSuppression?: boolean}} [state]
 * @returns {boolean}
 * @private
 */
function _sceneFilterSuppressionCanUseCompositor(
  filters,
  { anyBelow = false, anyBelowTiles = false, hasRelevantSuppression = false } = {},
) {
  try {
    if (CONFIG?.fxmaster?.overheadPerformance?.compositorSceneFilterSuppression === false) return false;
    if (!applyRegionBehaviorsToOverheadLevels()) return false;
    if (!hasRelevantSuppression || anyBelow || anyBelowTiles) return false;
    if (!filters?.length) return false;
    if (typeof CONFIG?.fxmaster?.getGlobalEffectsCompositor !== "function") return false;

    const selectedLevels = _collectSelectedSceneFilterLevelIds(filters);
    if (!(selectedLevels?.size > 0)) return false;

    const compositor = CONFIG.fxmaster.getGlobalEffectsCompositor?.();
    if (typeof compositor?.canHandleSceneFilterSuppressionForSelectedLevelIds !== "function") return false;

    return compositor.canHandleSceneFilterSuppressionForSelectedLevelIds(selectedLevels) === true;
  } catch (err) {
    logger.debug("FXMaster:", err);
    return false;
  }
}

export class FilterEffectsSceneManager {
  constructor() {
    this.filters = {};
    this._dyingFilters = new Set();
    this._ticker = false;
    this._lastRegionsMatrix = null;
    this._lastCamFrac = undefined;
    this._lastBelowTokenCoverageSignature = null;
    this._lastBelowTileCoverageSignature = null;
    this.stackEntries = new Map();
    this._transientStackRows = new Map();
    this._lastKnownOrder = new Map();
    this._lastSceneDarknessSignature = "";
    this._lastSuppressionOverlaySignature = "";
    this._lastSceneSuppressionNeedsMasking = false;
    this._lastDarknessLevel = getSceneDarknessLevel();
    this._runtimeFilterScratch = [];
    this._timedRemovalPending = new Set();

    /** @type {Function|null} */
    this._coalescedBindSceneMask = null;
  }

  static get instance() {
    if (!this.#instance) this.#instance = new this();
    return this.#instance;
  }
  static #instance;

  static get container() {
    return globalThis.canvas?.environment ?? null;
  }

  /**
   * Build a signature describing which scene-scoped filters are currently active at the supplied darkness level.
   *
   * @param {number} darknessLevel
   * @returns {string}
   */
  #buildSceneDarknessActivationSignature(darknessLevel = getSceneDarknessLevel()) {
    const infos = canvas?.scene?.getFlag(packageId, "filters") ?? {};
    return Object.entries(infos)
      .filter(([, info]) => !!info && typeof info === "object")
      .map(([id, info]) => {
        const options = normalizeSceneLevelSelection(
          info?.options && typeof info.options === "object" ? { ...info.options } : {},
          canvas?.scene,
        );
        const levelsKey = Array.isArray(options?.levels) ? options.levels.map(String).sort().join(",") : "*";
        const active =
          isEffectActiveForSceneDarkness(options, darknessLevel) &&
          isEffectActiveForCurrentOrVisibleCanvasLevel(options, canvas?.scene);
        return `${id}:${active ? 1 : 0}:${levelsKey}`;
      })
      .sort()
      .join("|");
  }

  async activate() {
    await this.update({ skipFading: true });
    if (!this._ticker) {
      const lowPriority = PIXI.UPDATE_PRIORITY?.LOW ?? -25;
      const PRIO = lowPriority + 0.75;
      try {
        canvas.app.ticker.add(this.#animate, this, PRIO);
      } catch {
        canvas.app.ticker.add(this.#animate, this);
      }
      this._ticker = true;
    }

    this.#refreshSceneFilterSuppressionMasks(true);
  }

  async clear() {
    const env = this.constructor.container;
    const managed = Object.values(this.filters);
    const dying = [...this._dyingFilters];

    const promises = [...managed, ...dying].map((f) => f.stop?.({ skipFading: true }));
    await Promise.all(promises);

    try {
      if (env?.filters?.length) {
        const set = new Set([...managed, ...dying]);
        env.filters = env.filters.filter((f) => !set.has(f));
      }
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    this.filters = {};
    this.stackEntries.clear();
    this._transientStackRows.clear();
    this._lastKnownOrder.clear();
    this._dyingFilters.clear();
    this._lastSuppressionOverlaySignature = "";
    this._timedRemovalPending.clear();

    try {
      canvas?.app?.ticker?.remove?.(this.#animate, this);
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
    this._ticker = false;
    this._lastCamFrac = undefined;
    this._lastBelowTokenCoverageSignature = null;
    this._lastBelowTileCoverageSignature = null;

    try {
      SceneMaskManager.instance.setBelowTokensNeeded?.("filters", false);
      SceneMaskManager.instance.setBelowTilesNeeded?.("filters", false);
      SceneMaskManager.instance.setKindActive?.("filters", false);
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
  }

  async update({ skipFading = false } = {}) {
    if (!canvas.scene) return;

    const darknessLevel = getSceneDarknessLevel();
    const filterInfos = Object.fromEntries(
      Object.entries(canvas.scene.getFlag(packageId, "filters") ?? {}).flatMap(([id, info]) => {
        if (!info || typeof info !== "object") return [];
        if (!(info.type in CONFIG.fxmaster.filterEffects)) {
          logger.warn(game.i18n.format("FXMASTER.Filters.TypeErrors.TypeUnknown", { id, type: info.type }));
          return [];
        }
        const options = normalizeSceneLevelSelection(
          info.options && typeof info.options === "object" ? { ...info.options } : {},
          canvas?.scene,
        );
        if (!isEffectActiveForSceneDarkness(options, darknessLevel)) return [];
        if (!isEffectActiveForCurrentOrVisibleCanvasLevel(options, canvas?.scene)) return [];
        return [[id, { ...info, options }]];
      }),
    );

    const createKeys = Object.keys(filterInfos).filter((k) => !(k in this.filters));
    const updateKeys = Object.keys(filterInfos).filter((k) => k in this.filters);
    const deleteKeys = Object.keys(this.filters).filter((k) => !(k in filterInfos));

    for (const key of createKeys) {
      const { type, options } = filterInfos[key];
      const runtimeContext = {
        scope: "scene",
        sceneId: canvas?.scene?.id ?? null,
        effectId: key,
        type,
      };
      const filter = new CONFIG.fxmaster.filterEffects[type](options, key, runtimeContext);
      filter.__fxmBelowTokens = _belowTokensEnabled(options?.belowTokens);
      filter.__fxmBelowTiles = _belowTilesEnabled(options?.belowTiles);
      filter.__fxmBelowForeground = _belowForegroundEnabled(options?.belowForeground);
      filter.__fxmLevels = options?.levels;
      filter.__fxmOptions = options;
      filter.__fxmRuntimeContext = runtimeContext;
      filter.onFXMasterRuntimeContext?.(runtimeContext);
      this.filters[key] = filter;
      filter.play?.({ ...(options ?? {}), skipFading: true });

      try {
        const strength = filter?.uniforms?.strength;
        if (!skipFading && filter?.constructor?.skipInitialFade !== true && typeof strength === "number") {
          const configuredDuration = Number(filter?.constructor?.initialFadeDurationMs);
          const durationMs = Number.isFinite(configuredDuration) && configuredDuration >= 0 ? configuredDuration : 3000;
          filter.fadeUniformTo?.("strength", strength, { from: 0, durationMs });
        }
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
    }

    for (const key of updateKeys) {
      const { options } = filterInfos[key];
      const f = this.filters[key];
      f.configure?.(options);
      f.__fxmBelowTokens = _belowTokensEnabled(options?.belowTokens);
      f.__fxmBelowTiles = _belowTilesEnabled(options?.belowTiles);
      f.__fxmBelowForeground = _belowForegroundEnabled(options?.belowForeground);
      f.__fxmLevels = options?.levels;
      f.__fxmOptions = options;
      const runtimeContext = {
        scope: "scene",
        sceneId: canvas?.scene?.id ?? null,
        effectId: key,
        type: filterInfos[key]?.type ?? null,
      };
      f.__fxmRuntimeContext = runtimeContext;
      f.onFXMasterRuntimeContext?.(runtimeContext);
    }

    for (const key of deleteKeys) {
      const f = this.filters[key];
      delete this.filters[key];
      if (!f) continue;

      const uid = buildSceneEffectUid("filter", key);
      const renderIndex = this._lastKnownOrder.get(uid) ?? Number.MAX_SAFE_INTEGER;
      this._transientStackRows.set(uid, {
        uid,
        kind: "filter",
        scope: "scene",
        renderIndex,
        filter: f,
        options: f?.__fxmOptions ?? f?.options ?? null,
        levels: f?.__fxmLevels ?? f?.__fxmOptions?.levels ?? f?.options?.levels ?? null,
      });

      this._dyingFilters.add(f);
      Promise.resolve(f.stop?.({ skipFading }))
        .catch(() => {})
        .finally(() => {
          this.#removeFromEnvFilters([f]);
          try {
            f.destroy?.();
          } catch (err) {
            logger.debug("FXMaster:", err);
          }
          this._dyingFilters.delete(f);
          this._transientStackRows.delete(uid);
        });
    }

    this._lastSceneDarknessSignature = this.#buildSceneDarknessActivationSignature(darknessLevel);
    this.#syncStackEntries();
    this.#refreshSceneFilterSuppressionMasks(true);
  }

  refreshViewMaskGeometry() {
    this.#refreshSceneFilterSuppressionMasks(true);
  }

  /**
   * Refresh scene-filter suppression masks.
   *
   * Suppression-active scenes use the synchronous path so the scene allow-mask and region masks stay aligned while the camera moves.
   *
   * @returns {void}
   */
  refreshSceneFilterSuppressionMasks() {
    const r = canvas?.app?.renderer;
    const hiDpi = (r?.resolution ?? window.devicePixelRatio ?? 1) !== 1;
    const filtersArr = this.#collectRuntimeFiltersScratch();
    const anyBelow = filtersArr.some((f) => isBelowTokensFilter(f));
    const anyBelowTiles = filtersArr.some((f) => isBelowTilesFilter(f));
    const hasRelevantSuppression = filtersArr.length ? _hasRelevantSuppressionForSceneFilters(filtersArr) : false;
    const compositorHandlesSuppression = _sceneFilterSuppressionCanUseCompositor(filtersArr, {
      anyBelow,
      anyBelowTiles,
      hasRelevantSuppression,
    });
    const forceSync =
      (hasRelevantSuppression && !compositorHandlesSuppression) || ((anyBelow || anyBelowTiles) && hiDpi);
    this.#refreshSceneFilterSuppressionMasks(forceSync);
  }

  async addFilter(name, type, options) {
    const scene = canvas.scene;
    if (!scene) return;

    name = name ?? foundry.utils.randomID();
    const normalizedOptions = prepareFilterOptionsForSceneStorage(
      type,
      ensureSingleSceneLevelSelection(options && typeof options === "object" ? { ...options } : {}, scene),
      { forceRestart: true },
    );

    await scene.setFlag(packageId, "filters", { [name]: { type, options: normalizedOptions } });
    await promoteEffectStackUids([buildSceneEffectUid("filter", name)], scene);
  }

  async removeFilter(name) {
    await canvas.scene?.setFlag(packageId, "filters", deletionUpdate(name));
  }

  async removeAll() {
    await canvas.scene?.unsetFlag(packageId, "filters");
  }

  async switch(name, type, options) {
    if (!canvas.scene) return;
    const infos = canvas.scene.getFlag(packageId, "filters") ?? {};
    if (infos[name]) return this.removeFilter(name);
    return this.addFilter(name, type, options);
  }

  async setFilters(arr) {
    const scene = canvas.scene;
    if (!scene) return;

    const infos = Object.fromEntries(
      arr.map((fi) => {
        const info = fi && typeof fi === "object" ? { ...fi } : {};
        info.options = ensureSingleSceneLevelSelection(
          info.options && typeof info.options === "object" ? { ...info.options } : {},
          scene,
        );
        return [foundry.utils.randomID(), info];
      }),
    );

    await resetFlag(scene, "filters", infos);
    await promoteEffectStackUids(
      Object.keys(infos).map((id) => buildSceneEffectUid("filter", id)),
      scene,
    );
  }

  /**
   * Return the live filter runtime for a stored stack uid.
   *
   * @param {string} uid
   * @returns {PIXI.Filter|null}
   */
  getStackFilter(uid) {
    return this.stackEntries.get(uid)?.filter ?? this._transientStackRows.get(uid)?.filter ?? null;
  }

  /**
   * Return transient stack rows that should continue rendering while a filter fades out.
   *
   * @returns {Array<{ uid: string, kind: "filter", scope: "scene", renderIndex: number, options?: object|null, levels?: unknown }>}
   */
  getTransientStackRows() {
    return Array.from(this._transientStackRows.values(), ({ uid, kind, scope, renderIndex, options, levels }) => ({
      uid,
      kind,
      scope: scope ?? "scene",
      renderIndex,
      options,
      levels,
    }));
  }

  /**
   * Rebuild the runtime uid lookup for scene filters.
   *
   * @returns {void}
   */
  #syncStackEntries() {
    this.stackEntries.clear();
    for (const [effectId, filter] of Object.entries(this.filters)) {
      const uid = buildSceneEffectUid("filter", effectId);
      this.stackEntries.set(uid, {
        uid,
        filter,
        options: filter?.__fxmOptions ?? filter?.options ?? null,
        levels: filter?.__fxmLevels ?? filter?.__fxmOptions?.levels ?? filter?.options?.levels ?? null,
      });
    }

    const orderedRows = getOrderedEnabledEffectRenderRows(canvas.scene);
    for (let index = 0; index < orderedRows.length; index++) {
      const uid = orderedRows[index]?.uid;
      if (!this.stackEntries.has(uid)) continue;
      this._lastKnownOrder.set(uid, index);
    }
  }

  /**
   * Clear any scene suppression/cutout mask uniforms from active and fading filters.
   *
   * When no suppress-scene-filters Region can affect the filters' selected Levels, compositor stack passes can use their direct Level clip and the shared scene suppression mask is unnecessary. Clearing stale uniforms keeps the live runtime from sampling an obsolete mask while avoiding a rebuild.
   *
   * @private
   */
  #clearSuppressMaskUniforms() {
    const filtersArr = this.#collectRuntimeFiltersScratch();
    if (!filtersArr.length) return;

    try {
      const { cssW, cssH, deviceToCss } = getCssViewportMetrics();
      applyMaskUniformsToFilters(filtersArr, {
        baseMaskRT: null,
        cutoutTokensRT: null,
        cutoutTilesRT: null,
        cutoutCombinedRT: null,
        tokensMaskRT: null,
        cssW,
        cssH,
        deviceToCss,
        maskSoft: false,
      });
    } catch (err) {
      logger.debug("FXMaster:", err);
      for (const f of filtersArr) {
        const u = f?.uniforms || {};
        if ("maskSampler" in u) u.maskSampler = PIXI.Texture.EMPTY;
        if ("hasMask" in u) u.hasMask = 0.0;
        if ("maskReady" in u) u.maskReady = 0.0;
        if ("maskSoft" in u) u.maskSoft = 0.0;
        if ("maskWorldReady" in u) u.maskWorldReady = 0.0;
        if ("tokenSampler" in u) u.tokenSampler = PIXI.Texture.EMPTY;
        if ("hasTokenMask" in u) u.hasTokenMask = 0.0;
      }
    }
  }

  /**
   * Bind the current scene suppression masks into uniforms for all active and fading filters. If the base mask is missing or destroyed, a synchronous refresh is attempted before binding.
   *
   * @param {{ presyncedLiveLevelState?: boolean }} [options]
   * @private
   */
  #bindSuppressMaskUniforms({ presyncedLiveLevelState = false } = {}) {
    const filtersArr = this.#collectRuntimeFiltersScratch();
    if (!filtersArr.length) return;

    const anyBelow = filtersArr.some((f) => isBelowTokensFilter(f));
    const anyBelowTiles = filtersArr.some((f) => isBelowTilesFilter(f));

    let { base, cutoutTokens, cutoutTiles, cutoutCombined, tokens, soft } =
      SceneMaskManager.instance.getMasks("filters");

    if (!base || base.destroyed) {
      try {
        SceneMaskManager.instance.refreshSync("filters", { presyncedLiveLevelState });
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
      ({ base, cutoutTokens, cutoutTiles, cutoutCombined, tokens, soft } =
        SceneMaskManager.instance.getMasks("filters"));
    }

    if (!base || base.destroyed) {
      for (const f of filtersArr) {
        const u = f?.uniforms || {};
        if ("maskSampler" in u) u.maskSampler = PIXI.Texture.EMPTY;
        if ("hasMask" in u) u.hasMask = 0.0;
        if ("maskReady" in u) u.maskReady = 0.0;
        if ("maskSoft" in u) u.maskSoft = 0.0;
        if ("maskWorldReady" in u) u.maskWorldReady = 0.0;
        if ("tokenSampler" in u) u.tokenSampler = PIXI.Texture.EMPTY;
        if ("hasTokenMask" in u) u.hasTokenMask = 0.0;
      }
      return;
    }

    const { cssW, cssH, deviceToCss, rect: cssFA } = getCssViewportMetrics();

    applyMaskUniformsToFilters(filtersArr, {
      baseMaskRT: base,
      cutoutTokensRT: anyBelow ? cutoutTokens : null,
      cutoutTilesRT: anyBelowTiles ? cutoutTiles : null,
      cutoutCombinedRT: anyBelow && anyBelowTiles ? cutoutCombined : null,
      tokensMaskRT: anyBelow ? tokens : null,
      cssW,
      cssH,
      deviceToCss,
      maskSoft: !!soft,
      filterAreaRect: cssFA,
    });
  }

  /**
   * Refresh and bind scene suppression masks for scene-wide filter effects.
   *
   * {@link SceneMaskManager.refresh} is animation-frame coalesced and may destroy and recreate render textures when it runs. For asynchronous refreshes, uniform binding is deferred until the next animation frame to avoid referencing textures that are replaced during refresh.
   *
   * @param {boolean} [sync=false]
   * @param {{ presyncedLiveLevelState?: boolean }} [options]
   * @private
   */
  #applySuppressMaskToFilters(sync = false, { presyncedLiveLevelState = false } = {}) {
    const filtersArr = this.#collectRuntimeFiltersScratch();
    const hasAny = filtersArr.length > 0;
    const anyBelow = hasAny ? filtersArr.some((f) => isBelowTokensFilter(f)) : false;
    const anyBelowTiles = hasAny ? filtersArr.some((f) => isBelowTilesFilter(f)) : false;
    const hasRelevantSuppression = hasAny ? _hasRelevantSuppressionForSceneFilters(filtersArr) : false;
    const compositorHandlesSuppression = hasAny
      ? _sceneFilterSuppressionCanUseCompositor(filtersArr, { anyBelow, anyBelowTiles, hasRelevantSuppression })
      : false;
    const needsMasking = (hasRelevantSuppression && !compositorHandlesSuppression) || anyBelow || anyBelowTiles;
    this._lastSceneSuppressionNeedsMasking = !!needsMasking;

    try {
      SceneMaskManager.instance.setKindActive?.("filters", hasAny && needsMasking);
      SceneMaskManager.instance.setBelowTokensNeeded?.("filters", needsMasking && anyBelow);
      SceneMaskManager.instance.setBelowTilesNeeded?.("filters", needsMasking && anyBelowTiles);
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    if (!hasAny) return;

    if (!needsMasking) {
      this.#clearSuppressMaskUniforms();
      return;
    }

    try {
      const r = canvas?.app?.renderer;
      const hiDpi = (r?.resolution ?? window.devicePixelRatio ?? 1) !== 1;

      if (sync || hasRelevantSuppression || ((anyBelow || anyBelowTiles) && hiDpi)) {
        SceneMaskManager.instance.refreshSync("filters", { presyncedLiveLevelState });
        this.#bindSuppressMaskUniforms({ presyncedLiveLevelState });
      } else {
        SceneMaskManager.instance.refresh("filters");
        this._coalescedBindSceneMask ??= coalesceNextFrame(
          () => {
            try {
              this.#bindSuppressMaskUniforms();
            } catch (err) {
              logger?.error?.(err);
            }
          },
          { key: "fxm:bindFilterSceneMasks" },
        );
        this._coalescedBindSceneMask();
      }
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
  }

  /**
   * Refresh scene-filter suppression masks.
   *
   * @param {boolean} [sync=false]
   * @param {{ presyncedLiveLevelState?: boolean }} [options]
   * @private
   */
  #refreshSceneFilterSuppressionMasks(sync = false, { presyncedLiveLevelState = false } = {}) {
    const hasAny = Object.keys(this.filters).length > 0 || this._dyingFilters.size > 0;
    if (hasAny) this.#applySuppressMaskToFilters(sync, { presyncedLiveLevelState });
    else {
      try {
        SceneMaskManager.instance.setBelowTokensNeeded?.("filters", false);
        SceneMaskManager.instance.setBelowTilesNeeded?.("filters", false);
        SceneMaskManager.instance.setKindActive?.("filters", false);
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
    }

    const M = snappedStageMatrix();
    if (!M) return;
    this._lastRegionsMatrix = { a: M.a, b: M.b, c: M.c, d: M.d, tx: M.tx, ty: M.ty };
  }

  #removeFromEnvFilters(filtersToRemove = []) {
    const env = this.constructor.container;
    if (!env?.filters?.length) return;
    const set = new Set(filtersToRemove);
    env.filters = env.filters.filter((f) => !set.has(f));
  }

  /**
   * Return live and fading scene-filter runtimes using a reusable scratch array.
   *
   * @returns {PIXI.Filter[]}
   */
  #collectRuntimeFiltersScratch() {
    const out = this._runtimeFilterScratch ?? (this._runtimeFilterScratch = []);
    out.length = 0;

    for (const key in this.filters) {
      if (!Object.prototype.hasOwnProperty.call(this.filters, key)) continue;
      const filter = this.filters[key];
      if (filter) out.push(filter);
    }
    for (const filter of this._dyingFilters ?? []) {
      if (filter) out.push(filter);
    }

    return out;
  }

  /**
   * Remove expired timed scene filters from the active scene.
   *
   * @returns {void}
   */
  #pruneExpiredTimedFilters() {
    if (!game?.user?.isGM || !canvas?.scene) return;

    for (const [key, filter] of Object.entries(this.filters ?? {})) {
      if (!filter || typeof filter.isTimedExpired !== "function") continue;
      if (!filter.isTimedExpired()) continue;
      if (this._timedRemovalPending.has(key)) continue;

      this._timedRemovalPending.add(key);
      Promise.resolve(this.removeFilter(key)).finally(() => this._timedRemovalPending.delete(key));
    }
  }

  #animate() {
    this.#pruneExpiredTimedFilters();

    for (const key in this.filters) {
      if (!Object.prototype.hasOwnProperty.call(this.filters, key)) continue;
      this.filters[key]?.step?.();
    }

    const filtersArr = this.#collectRuntimeFiltersScratch();

    try {
      for (const f of filtersArr) {
        if (typeof f?.lockViewport === "function") {
          f.lockViewport({ setDeviceToCss: false, setCamFrac: true });
        }
      }
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    try {
      const darknessLevel = getSceneDarknessLevel();
      this._lastDarknessLevel = darknessLevel;
      const sceneSignature = this.#buildSceneDarknessActivationSignature(darknessLevel);
      if (sceneSignature !== this._lastSceneDarknessSignature) {
        this._lastSceneDarknessSignature = sceneSignature;
        void this.update();
      }
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    const M = snappedStageMatrix();
    if (!M) return;

    const L = this._lastRegionsMatrix;
    const changed = cameraMatrixChanged(M, L);
    const hasAny = filtersArr.length > 0;
    const anyBelowTokens = hasAny ? filtersArr.some((f) => isBelowTokensFilter(f)) : false;
    const anyBelowTiles = hasAny ? filtersArr.some((f) => isBelowTilesFilter(f)) : false;
    const hasRelevantSuppression = hasAny ? _hasRelevantSuppressionForSceneFilters(filtersArr) : false;
    const compositorHandlesSuppression = hasAny
      ? _sceneFilterSuppressionCanUseCompositor(filtersArr, {
          anyBelow: anyBelowTokens,
          anyBelowTiles,
          hasRelevantSuppression,
        })
      : false;
    const needsMasking = (hasRelevantSuppression && !compositorHandlesSuppression) || anyBelowTokens || anyBelowTiles;
    const maskingChanged = !!needsMasking !== (this._lastSceneSuppressionNeedsMasking === true);
    /** Foundry's primary/perception tickers run before this low-priority FXMaster ticker. */
    const overlayState =
      hasRelevantSuppression && !compositorHandlesSuppression
        ? getCanvasLiveLevelSurfaceState(canvas?.scene ?? null, {
            presynced: true,
            includeTransientFades: false,
          })
        : null;
    const overlaySignature = overlayState?.key ?? "";
    const overlayChanged =
      hasRelevantSuppression &&
      !compositorHandlesSuppression &&
      overlaySignature !== this._lastSuppressionOverlaySignature;

    const worldAtlasMasks = SceneMaskManager.instance.usesWorldAtlas?.("filters") === true;
    if (needsMasking && (changed || overlayChanged || maskingChanged)) {
      if (changed && worldAtlasMasks && !overlayChanged && !maskingChanged) {
        this.#bindSuppressMaskUniforms({ presyncedLiveLevelState: true });
        this._lastRegionsMatrix = { a: M.a, b: M.b, c: M.c, d: M.d, tx: M.tx, ty: M.ty };
      } else {
        this.#refreshSceneFilterSuppressionMasks(true, { presyncedLiveLevelState: true });
      }
    } else if (!needsMasking) {
      this._lastSceneSuppressionNeedsMasking = false;
      this._lastSuppressionOverlaySignature = "";
      if (maskingChanged) this.#clearSuppressMaskUniforms();
      if (changed) this._lastRegionsMatrix = { a: M.a, b: M.b, c: M.c, d: M.d, tx: M.tx, ty: M.ty };
    }

    this._lastSceneSuppressionNeedsMasking = !!needsMasking;
    this._lastSuppressionOverlaySignature = overlaySignature;

    try {
      if (!anyBelowTokens && !anyBelowTiles) {
        this._lastBelowTokenCoverageSignature = null;
        this._lastBelowTileCoverageSignature = null;
        return;
      }

      const r = canvas?.app?.renderer;
      const res = r?.resolution || window.devicePixelRatio || 1;
      const { txCss, tyCss } = getSnappedCameraCss();

      const fxFrac = (((txCss * res) % 1) + 1) % 1;
      const fyFrac = (((tyCss * res) % 1) + 1) % 1;

      if (!this._lastCamFrac) this._lastCamFrac = { x: fxFrac, y: fyFrac };

      /**
       * Sub-pixel threshold for token-mask repaints.
       *
       * Camera movements smaller than roughly one percent of a device pixel do not trigger a repaint. This avoids unnecessary sprite allocation churn during smooth panning.
       */
      const SUB_PIXEL_THRESHOLD = 0.01;
      const fracMoved =
        Math.abs(fxFrac - this._lastCamFrac.x) > SUB_PIXEL_THRESHOLD ||
        Math.abs(fyFrac - this._lastCamFrac.y) > SUB_PIXEL_THRESHOLD;

      let tokenMotionChanged = false;
      if (anyBelowTokens) {
        const tokenSignature = buildBelowTokenMaskCoverageSignature();
        tokenMotionChanged = tokenSignature !== (this._lastBelowTokenCoverageSignature ?? null);
        this._lastBelowTokenCoverageSignature = tokenSignature;
      } else {
        this._lastBelowTokenCoverageSignature = null;
      }

      let tileCoverageChanged = false;
      if (anyBelowTiles) {
        const tileSignature = buildBelowTileMaskCoverageSignature();
        tileCoverageChanged = tileSignature !== (this._lastBelowTileCoverageSignature ?? null);
        this._lastBelowTileCoverageSignature = tileSignature;
      } else {
        this._lastBelowTileCoverageSignature = null;
      }

      const worldAtlasCoverage = SceneMaskManager.instance.usesWorldAtlasCoverage?.() === true;
      const cameraCoverageChanged = !worldAtlasCoverage && fracMoved;
      if (tokenMotionChanged || tileCoverageChanged) {
        SceneMaskManager.instance.refreshTokensSync?.({ force: true });
        this.#bindSuppressMaskUniforms();
      } else if (!changed && cameraCoverageChanged) {
        SceneMaskManager.instance.refreshTokensSync?.();
        this.#bindSuppressMaskUniforms();
      } else if ((changed || fracMoved) && worldAtlasCoverage) {
        this.#bindSuppressMaskUniforms();
      }

      this._lastCamFrac.x = fxFrac;
      this._lastCamFrac.y = fyFrac;
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
  }
}
