/**
 * ParticleEffectsLayer
 * --------------------
 * Builds and maintains scene-scoped and region-scoped particle runtimes for FXMaster.
 * - Preserves suppression masks, token cutouts, and region mask state.
 * - Registers renderable particle slots for the global compositor stack.
 */
import { packageId } from "../constants.js";
import { isEnabled } from "../settings.js";
import {
  safeMaskTexture,
  buildRegionMaskRT,
  _belowTokensEnabled,
  _belowTilesEnabled,
  _belowForegroundEnabled,
  applyMaskSpriteTransform,
  computeRegionGatePass,
  coalesceNextFrame,
  getCssViewportMetrics,
  getSnappedCameraCss,
  rawStageMatrix,
  safeResolutionForCssArea,
  snappedStageMatrix,
  currentRenderParentMatrix,
  cameraMatrixChanged,
  composeMaskMinusTokens,
  composeMaskMinusTokensRT,
  composeMaskMinusTiles,
  composeMaskMinusTilesRT,
  composeMaskMinusCoverageRT,
  repaintTilesMaskInto,
  estimateRegionInradius,
  regionMaskTraceShapes,
  regionWorldBounds,
  getSceneDarknessLevel,
  isEffectActiveForSceneDarkness,
  isEffectActiveForCurrentOrVisibleCanvasLevel,
  getSelectedSceneLevelIds,
  normalizeSceneLevelSelection,
  resolveDocumentOcclusionElevation,
  getCanvasLiveLevelSurfaceState,
  getDocumentAssignedLevelIds,
  getRegionEffectPlaceablesForCurrentView,
  getRegionPlaceableOrDocumentAdapter,
  getSceneRegionDocumentById,
  getSceneLevels,
  regionDocumentCanApplyInCurrentView,
  isTileOverhead,
  tileHasActiveOcclusion,
  tileDocumentRestrictsParticles,
  getRegionBehaviorEdgeFadePercent,
  getRegionParticleEffectDefinitions,
  getRegionSoftMaskData,
  fxmUpdateDisplayObjectWorldTransform,
  buildBelowTokenMaskCoverageSignature,
  buildBelowTileMaskCoverageSignature,
  hasActiveRadialRestrictWeatherTilesForMask,
  syncActiveRadialRestrictWeatherTileMasksForCamera,
} from "../utils.js";
import {
  markSceneParticleSuppressionCompositorInteraction,
  refreshSceneParticlesSuppressionMasks,
  sceneParticlesHaveRelevantSuppressionRegions,
} from "./particle-effects-scene-manager.js";
import { BaseEffectsLayer } from "../common/base-effects-layer.js";
import { logger } from "../logger.js";
import { hasOwn, isPlainObject } from "../utils/object.js";
import {
  buildSceneEffectUid,
  buildRegionEffectUid,
  getOrderedEnabledEffectRenderRows,
  normalizeBehaviorDocs,
} from "../common/effect-stack.js";
import { SceneMaskManager } from "../common/base-effects-scene-manager.js";
import { fxmForEachEmitterParticle } from "./effects/effect.js";
import { createParticleBackgroundSurface } from "./backgrounds/background-surface-factory.js";
import { createParticleBackgroundTrailStore } from "./backgrounds/snow-trail-store.js";
import {
  particleBackgroundEnabled,
  particleBackgroundMonotonicNow,
  particleBackgroundNow,
} from "./backgrounds/background-state.js";
import {
  PARTICLE_BACKGROUND_DISTURBANCE_QUERY_VERSION,
  PARTICLE_BACKGROUND_MOVEMENT_HISTORY_MAX_EVENTS,
  getParticleBackgroundQueryParticipants,
  getParticleBackgroundQueryRecipients,
  normalizeParticleBackgroundMovementEvent,
  particleBackgroundQueriesAvailable,
  persistParticleBackgroundDisturbances,
  queryParticleBackgroundDisturbances,
  readParticleBackgroundMovementHistory,
} from "./backgrounds/particle-background-query-sync.js";

const TYPE = `${packageId}.particleEffectsRegion`;
const ACTIVE_DARKNESS_EPSILON = 1e-4;
const PARTICLE_TRAIL_ACTIVE_SAMPLE_INTERVAL_MS = 16;
const PARTICLE_TRAIL_SAMPLE_INTERVAL_MS = 50;
const PARTICLE_TRAIL_IDLE_SAMPLE_INTERVAL_MS = 160;
const PARTICLE_TRAIL_IDLE_BACKOFF_AFTER_SAMPLES = 4;
const PARTICLE_TRAIL_MIN_DISTANCE_GRID = 0.006;
const PARTICLE_TRAIL_TELEPORT_GRID_SPACES = 8;
const PARTICLE_TRAIL_QUERY_BATCH_INTERVAL_MS = 40;
const PARTICLE_TRAIL_QUERY_MAX_SEGMENTS = 24;
const PARTICLE_TRAIL_QUERY_MAX_PENDING_SEGMENTS = 72;
const PARTICLE_TRAIL_QUERY_MAX_INBOUND_SEGMENTS = 48;
const PARTICLE_TRAIL_QUERY_MAX_EVENT_AGE_MS = 2000;
const PARTICLE_TRAIL_QUERY_DEDUPE_TTL_MS = 15000;
const PARTICLE_TRAIL_QUERY_MAX_RECENT_EVENTS = 512;
const PARTICLE_TRAIL_AUTHORITY_TTL_MS = 30000;
const PARTICLE_TRAIL_ACTIVE_CANDIDATE_TTL_MS = 2000;
const PARTICLE_TRAIL_STALE_BASELINE_MS = 750;
const PARTICLE_TRAIL_HISTORY_CLOCK_SKEW_MS = 2000;

const REGION_SURFACE_EDGE_FADE_FRAGMENT_SHADER = `
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
varying vec2 vTextureCoord;
uniform sampler2D uSampler;
uniform sampler2D uRegionFadeMask;
uniform vec4 inputSize;
uniform vec4 outputFrame;
uniform vec2 camFrac;
uniform mat3 uCssToWorld;
uniform mat3 uMaskUvFromWorld;
void main() {
  vec4 color = texture2D(uSampler, vTextureCoord);
  vec2 screenPx = outputFrame.xy + vTextureCoord * inputSize.xy;
  vec2 snapPx = screenPx - camFrac;
  vec2 world = (uCssToWorld * vec3(snapPx, 1.0)).xy;
  vec2 uv = (uMaskUvFromWorld * vec3(world, 1.0)).xy;
  float inBounds = step(0.0, uv.x) * step(0.0, uv.y) * step(uv.x, 1.0) * step(uv.y, 1.0);
  float fade = texture2D(uRegionFadeMask, clamp(uv, vec2(0.0), vec2(1.0))).a * inBounds;
  gl_FragColor = color * fade;
}
`;

function writePixiMatrix3(target, matrix) {
  const out = target instanceof Float32Array && target.length >= 9 ? target : new Float32Array(9);
  out[0] = Number(matrix?.a ?? 1) || 0;
  out[1] = Number(matrix?.b ?? 0) || 0;
  out[2] = 0;
  out[3] = Number(matrix?.c ?? 0) || 0;
  out[4] = Number(matrix?.d ?? 1) || 0;
  out[5] = 0;
  out[6] = Number(matrix?.tx ?? 0) || 0;
  out[7] = Number(matrix?.ty ?? 0) || 0;
  out[8] = 1;
  return out;
}

function writeRegionSoftMaskUvFromWorld(target, entry) {
  const out = target instanceof Float32Array && target.length >= 9 ? target : new Float32Array(9);
  const source = entry?.uvFromWorld;
  if (source instanceof Float32Array && source.length >= 9) out.set(source.subarray(0, 9));
  else out.set([1, 0, 0, 0, 1, 0, 0, 0, 1]);
  return out;
}

const _regionSurfaceCssToWorldMatrix = new PIXI.Matrix();
const _regionSurfaceCssToWorldUniform = new Float32Array([1, 0, 0, 0, 1, 0, 0, 0, 1]);
let _regionSurfaceStageA = Number.NaN;
let _regionSurfaceStageB = Number.NaN;
let _regionSurfaceStageC = Number.NaN;
let _regionSurfaceStageD = Number.NaN;
let _regionSurfaceStageTx = Number.NaN;
let _regionSurfaceStageTy = Number.NaN;

function regionSurfaceCssToWorldUniform() {
  const source = snappedStageMatrix();
  if (
    source.a !== _regionSurfaceStageA ||
    source.b !== _regionSurfaceStageB ||
    source.c !== _regionSurfaceStageC ||
    source.d !== _regionSurfaceStageD ||
    source.tx !== _regionSurfaceStageTx ||
    source.ty !== _regionSurfaceStageTy
  ) {
    _regionSurfaceStageA = source.a;
    _regionSurfaceStageB = source.b;
    _regionSurfaceStageC = source.c;
    _regionSurfaceStageD = source.d;
    _regionSurfaceStageTx = source.tx;
    _regionSurfaceStageTy = source.ty;
    const matrix = _regionSurfaceCssToWorldMatrix;
    matrix.a = source.a;
    matrix.b = source.b;
    matrix.c = source.c;
    matrix.d = source.d;
    matrix.tx = source.tx;
    matrix.ty = source.ty;
    try {
      matrix.invert();
    } catch (_err) {
      matrix.identity();
    }
    writePixiMatrix3(_regionSurfaceCssToWorldUniform, matrix);
  }
  return _regionSurfaceCssToWorldUniform;
}

class RegionSurfaceEdgeFadeFilter extends PIXI.Filter {
  constructor(maskEntry) {
    super(PIXI.Filter.defaultVertex, REGION_SURFACE_EDGE_FADE_FRAGMENT_SHADER, {
      uRegionFadeMask: PIXI.Texture.EMPTY,
      camFrac: new Float32Array([0, 0]),
      uCssToWorld: new Float32Array([1, 0, 0, 0, 1, 0, 0, 0, 1]),
      uMaskUvFromWorld: new Float32Array([1, 0, 0, 0, 1, 0, 0, 0, 1]),
    });
    this.padding = 0;
    this.autoFit = false;
    this.resolution = 1;
    this.configure(maskEntry);
  }

  configure(maskEntry) {
    this.uniforms.uRegionFadeMask = maskEntry?.texture ?? PIXI.Texture.EMPTY;
    this.uniforms.uMaskUvFromWorld = writeRegionSoftMaskUvFromWorld(
      this.uniforms.uMaskUvFromWorld,
      maskEntry,
    );
  }

  apply(filterSystem, input, output, clear, currentState) {
    this.uniforms.uCssToWorld = regionSurfaceCssToWorldUniform();
    const { camFracX, camFracY } = getSnappedCameraCss();
    const camFrac =
      this.uniforms.camFrac instanceof Float32Array && this.uniforms.camFrac.length >= 2
        ? this.uniforms.camFrac
        : new Float32Array(2);
    camFrac[0] = camFracX;
    camFrac[1] = camFracY;
    this.uniforms.camFrac = camFrac;
    return super.apply(filterSystem, input, output, clear, currentState);
  }

  destroy(options) {
    this.uniforms.uRegionFadeMask = PIXI.Texture.EMPTY;
    super.destroy(options);
  }
}

function particleEffectFadeDurationMs(EffectClass) {
  const duration = Number(EffectClass?.defaultFadeDurationMs ?? 3000);
  return Number.isFinite(duration) ? Math.max(0, duration) : 3000;
}

function particleEffectUsesSoftFade(EffectClass, soft) {
  return !!soft || EffectClass?.alwaysSoftToggleFade === true;
}

function particleEffectPrewarmForSoftFade(EffectClass, soft) {
  if (!soft) return true;
  return EffectClass?.softFadePrewarm === true;
}

function particleEffectPrewarmForInstanceSoftFade(fx, soft) {
  return particleEffectPrewarmForSoftFade(fx?.constructor, soft);
}

function particleTrailFiniteNumber(value, fallback = 0) {
  const numeric = Number(value);
  return Number.isFinite(numeric) ? numeric : fallback;
}

function particleTrailClamp(value, min, max, fallback = min) {
  return Math.max(min, Math.min(max, particleTrailFiniteNumber(value, fallback)));
}

function hashParticleTrailString32(value) {
  const text = String(value ?? "fxmaster-particle-trail");
  let hash = 2166136261;
  for (let index = 0; index < text.length; index++) {
    hash ^= text.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

function particleTrailUserCanUpdateToken(user, tokenDocument) {
  if (!user || !tokenDocument) return false;
  try {
    const result = tokenDocument.canUserModify?.(user, "update");
    if (typeof result === "boolean") return result;
  } catch (_err) {}

  try {
    const owner = globalThis.CONST?.DOCUMENT_OWNERSHIP_LEVELS?.OWNER ?? 3;
    return !!tokenDocument.testUserPermission?.(user, owner);
  } catch (_err) {
    return !!user.isGM;
  }
}

function particleTrailPoint(value) {
  const x = Number(value?.x);
  const y = Number(value?.y);
  return Number.isFinite(x) && Number.isFinite(y) ? { x, y } : null;
}

/**
 * Return whether native weather occlusion filters can be used for stack-pass particle rendering.
 *
 * @returns {boolean}
 */
function canUseNativeWeatherOcclusionStackPass() {
  return Number(globalThis.game?.release?.generation ?? 0) >= 14;
}

/**
 * Foundry V13's stack pass can expose the local white scene-clip mask when a bare scene slot is rendered directly. V14 does not exhibit that leak and can keep the direct path that avoids simple-scene pan drift.
 */
function canUseDirectSceneParticleSlotRender() {
  return Number(globalThis.game?.release?.generation ?? 0) >= 14;
}

/**
 * Build a region-scoped particle context so region effects use region bounds rather than scene bounds.
 *
 * @param {PlaceableObject} placeable
 * @returns {{dimensions: object, renderer: PIXI.Renderer|null, ticker: PIXI.Ticker|null}|null}
 */
function buildRegionParticleContext(placeable) {
  const bounds = regionWorldBounds(placeable);
  if (!bounds) return null;

  const minX = Number(bounds.minX);
  const minY = Number(bounds.minY);
  const maxX = Number(bounds.maxX);
  const maxY = Number(bounds.maxY);
  if (![minX, minY, maxX, maxY].every(Number.isFinite)) return null;

  const width = Math.max(1, maxX - minX);
  const height = Math.max(1, maxY - minY);
  const size = Number(canvas?.dimensions?.size) || 100;

  return {
    dimensions: {
      width,
      height,
      size,
      sceneX: minX,
      sceneY: minY,
      sceneWidth: width,
      sceneHeight: height,
      sceneRect: new PIXI.Rectangle(minX, minY, width, height),
    },
    renderer: canvas?.app?.renderer ?? null,
    ticker: canvas?.app?.ticker ?? PIXI?.Ticker?.shared ?? null,
  };
}

function regionHasActiveSuppressionBehavior(placeable, behaviorType) {
  return normalizeBehaviorDocs(placeable?.document?.behaviors).some(
    (behavior) => behavior?.type === behaviorType && !behavior.disabled,
  );
}

function regionMaskResolutionForEdgeSync(placeable, behaviorType, cssW, cssH) {
  const rendererResolution = Number(canvas?.app?.renderer?.resolution ?? 1) || 1;
  if (rendererResolution <= 1) return undefined;
  if (!regionHasActiveSuppressionBehavior(placeable, behaviorType)) return undefined;
  return safeResolutionForCssArea(cssW, cssH);
}

/**
 * Interpret a below-tokens flag or parameter consistently.
 *
 * @param {*} value
 * @returns {boolean}
 */
function particleBelowTokensEnabled(value) {
  return _belowTokensEnabled(value);
}

/**
 * Interpret a below-tiles flag or parameter consistently.
 *
 * @param {*} value
 * @returns {boolean}
 */
function particleBelowTilesEnabled(value) {
  return _belowTilesEnabled(value);
}

/**
 * Determine whether a particle requests below-foreground rendering.
 *
 * @param {*} value
 * @returns {boolean}
 */
function particleBelowForegroundEnabled(value) {
  return _belowForegroundEnabled(value);
}

/**
 * Determine whether a particle tint option is enabled.
 *
 * @param {*} value
 * @returns {boolean}
 */
function particleTintEnabled(value) {
  if (!isPlainObject(value)) return false;
  const nested = isPlainObject(value.value) ? value.value : null;
  if (typeof nested?.apply === "boolean") return nested.apply;
  if (typeof value.apply === "boolean") return value.apply;
  return nested ? particleTintEnabled(nested) : false;
}

function normalizeStoredParticleOptionValue(value) {
  if (!isPlainObject(value) || !hasOwn(value, "value")) return value;
  if (typeof value.apply === "boolean") return { value: value.value, apply: value.apply };

  const inner = value.value;
  if (isPlainObject(inner) && hasOwn(inner, "value")) return normalizeStoredParticleOptionValue(inner);
  return inner;
}

function wrapStoredParticleOptions(options = {}) {
  return Object.fromEntries(
    Object.entries(options ?? {}).map(([key, value]) => [key, { value: normalizeStoredParticleOptionValue(value) }]),
  );
}

function particleTrailFirstFiniteNumber(...values) {
  for (const value of values) {
    const number = Number(value);
    if (Number.isFinite(number)) return number;
  }
  return Number.NaN;
}

function particleTrailNormalizeGroundElevation(value) {
  const number = Number(value);
  return Number.isFinite(number) ? number : 0;
}

function particleTrailReadBottomElevation(source) {
  if (!source) return 0;

  const elevation = source?.elevation;
  if (elevation && typeof elevation === "object") {
    if (hasOwn(elevation, "base")) return particleTrailNormalizeGroundElevation(elevation.base);
    if (hasOwn(elevation, "bottom")) return particleTrailNormalizeGroundElevation(elevation.bottom);
  }

  if (hasOwn(source, "bottom")) return particleTrailNormalizeGroundElevation(source.bottom);
  if (hasOwn(source, "elevation") && (elevation == null || typeof elevation !== "object")) {
    return particleTrailNormalizeGroundElevation(elevation);
  }

  return 0;
}

function particleTrailReadElevationThreshold(options = {}) {
  const raw = normalizeStoredParticleOptionValue(options?.backgroundInteractionElevationThreshold);
  if (typeof raw === "string") {
    const text = raw.trim();
    if (/^(?:∞|inf(?:inity)?|infinite)$/i.test(text)) return Infinity;
  }
  const number = Number(raw);
  if (number === Infinity) return Infinity;
  if (Number.isFinite(number)) return Math.max(0, number);
  return Infinity;
}

function particleTrailTokenElevationValue(tokenOrSnapshot) {
  return particleTrailFirstFiniteNumber(
    tokenOrSnapshot?.elevation,
    tokenOrSnapshot?.document?.elevation,
    tokenOrSnapshot?.document?.elevation?.value,
    tokenOrSnapshot?.document?.elevation?.bottom,
    tokenOrSnapshot?.object?.document?.elevation,
    0,
  );
}

function particleTrailLevelById(levelId, scene = canvas?.scene ?? null) {
  const id = String(levelId ?? "").trim();
  if (!id) return null;
  try {
    return getSceneLevels(scene).find((level) => String(level?.id ?? level?._id ?? "") === id) ?? null;
  } catch (_err) {
    return null;
  }
}

function particleTrailDocumentBottom(document) {
  return particleTrailReadBottomElevation(document);
}

function particleTrailRuntimeLevelIds(fx) {
  const rawSelection = normalizeStoredParticleOptionValue(
    fx?.__fxmTrailLevelIds ?? fx?.__fxmLevels ?? fx?.__fxmOptions?.levels,
  );
  const selected = getSelectedSceneLevelIds(rawSelection, canvas?.scene ?? null);
  return selected?.size ? selected : null;
}

function particleTrailMatchingLevelBottom({ fx = null, tokenLevelIds = [] } = {}) {
  const scene = canvas?.scene ?? null;
  const selected = particleTrailRuntimeLevelIds(fx);
  const tokenLevels = Array.isArray(tokenLevelIds) ? tokenLevelIds.map(String).filter(Boolean) : [];
  const candidates = [];

  if (selected?.size && tokenLevels.length) {
    for (const levelId of tokenLevels) if (selected.has(levelId)) candidates.push(levelId);
  }
  if (!candidates.length && tokenLevels.length) candidates.push(...tokenLevels);
  if (!candidates.length && selected?.size) candidates.push(...selected);

  if (!candidates.length) {
    const currentLevelId = String(canvas?.level?.id ?? canvas?.level?._id ?? "");
    if (currentLevelId) candidates.push(currentLevelId);
  }

  for (const levelId of candidates) {
    const level = particleTrailLevelById(levelId, scene);
    if (!level) continue;
    return particleTrailReadBottomElevation(level);
  }

  return 0;
}

function particleTrailEffectGroundElevation(fx, tokenLevelIds = []) {
  const context = fx?.__fxmParticleContext ?? fx?.options?.__fxmParticleContext ?? null;
  const regionId = String(context?.regionId ?? "").trim();
  if (regionId) {
    const regionDocument = getSceneRegionDocumentById(regionId, canvas?.scene ?? null) ?? null;
    const regionBottom = particleTrailDocumentBottom(regionDocument);
    if (Number.isFinite(regionBottom)) return regionBottom;
    return 0;
  }

  try {
    const levels = getSceneLevels(canvas?.scene ?? null);
    if (!levels?.length) return 0;
  } catch (_err) {
    return 0;
  }

  return particleTrailMatchingLevelBottom({ fx, tokenLevelIds });
}

function particleTrailTokenWithinElevationThreshold(tokenOrSnapshot, fx) {
  const threshold = particleTrailReadElevationThreshold(fx?.__fxmOptions ?? {});
  if (threshold === Infinity) return true;

  const elevation = particleTrailTokenElevationValue(tokenOrSnapshot);
  const tokenLevelIds = Array.isArray(tokenOrSnapshot?.levelIds) ? tokenOrSnapshot.levelIds : [];
  const ground = particleTrailEffectGroundElevation(fx, tokenLevelIds);
  const relativeElevation = elevation - ground;
  return relativeElevation <= threshold + 1e-6;
}

/**
 * Resolve the occlusion elevation used for a particle runtime.
 *
 * @param {{ belowForeground?: boolean }|null|undefined} entry
 * @param {number} fallbackElevation
 * @returns {number}
 */
function resolveParticleOcclusionElevation(entry, fallbackElevation) {
  const fallback = Number.isFinite(fallbackElevation) ? fallbackElevation : Infinity;
  const regionDocument = entry?.regionId ? canvas?.regions?.get(entry.regionId)?.document ?? null : null;
  return resolveDocumentOcclusionElevation(regionDocument, {
    fallback,
    preferForeground: particleBelowForegroundEnabled(entry?.belowForeground),
  });
}

/**
 * Select the appropriate mask texture from a shared mask bundle.
 *
 * @param {{base?: PIXI.RenderTexture|null, cutoutTokens?: PIXI.RenderTexture|null, cutoutTiles?: PIXI.RenderTexture|null, cutoutCombined?: PIXI.RenderTexture|null}|null|undefined} bundle
 * @param {boolean} belowTokens
 * @param {boolean} belowTiles
 * @returns {PIXI.RenderTexture|null}
 */
function chooseParticleMaskTexture(bundle, belowTokens, belowTiles) {
  if (!bundle) return null;
  if (belowTokens && belowTiles)
    return bundle.cutoutCombined || bundle.cutoutTokens || bundle.cutoutTiles || bundle.base || null;
  if (belowTokens) return bundle.cutoutTokens || bundle.cutoutCombined || bundle.base || null;
  if (belowTiles) return bundle.cutoutTiles || bundle.cutoutCombined || bundle.base || null;
  return bundle.base || null;
}

/**
 * Test whether a texture retains valid metadata for use as a PIXI sprite mask.
 *
 * @param {PIXI.Texture|PIXI.RenderTexture|null|undefined} texture
 * @returns {boolean}
 */
function isUsableParticleMaskTexture(texture) {
  if (
    !texture ||
    texture === PIXI.Texture.EMPTY ||
    texture.destroyed ||
    !texture.baseTexture ||
    texture.baseTexture.destroyed ||
    texture.valid === false
  )
    return false;
  const width = Number(texture.orig?.width);
  const height = Number(texture.orig?.height);
  return Number.isFinite(width) && width > 0 && Number.isFinite(height) && height > 0;
}

/**
 * Detach and clear a sprite mask without destroying the sprite.
 *
 * @param {PIXI.Container|null|undefined} container
 * @param {PIXI.Sprite|null|undefined} sprite
 * @returns {void}
 */
function disableParticleMask(container, sprite) {
  if (!sprite || sprite.destroyed) return;
  try {
    if (container?.mask === sprite) container.mask = null;
  } catch (err) {
    logger.debug("FXMaster:", err);
  }
  try {
    sprite._fxmMaskEnabled = false;
    sprite.texture = PIXI.Texture.EMPTY;
  } catch (err) {
    logger.debug("FXMaster:", err);
  }
}

/**
 * Compose a region mask that is below both tokens and tiles while reusing an already-built single cutout when possible.
 *
 * @param {PIXI.RenderTexture} baseRT
 * @param {PIXI.RenderTexture|null} tokensRT
 * @param {PIXI.RenderTexture|null} tilesRT
 * @param {PIXI.RenderTexture} outRT
 * @param {{cutoutTokens?: PIXI.RenderTexture|null, cutoutTiles?: PIXI.RenderTexture|null}|null|undefined} shared
 * @returns {PIXI.RenderTexture|null}
 */
function composeParticleCombinedCutoutRT(baseRT, tokensRT, tilesRT, outRT, shared) {
  if (shared?.cutoutTokens && tilesRT) return composeMaskMinusTilesRT(shared.cutoutTokens, tilesRT, { outRT });
  if (shared?.cutoutTiles && tokensRT) return composeMaskMinusTokensRT(shared.cutoutTiles, tokensRT, { outRT });
  return composeMaskMinusCoverageRT(baseRT, [tokensRT, tilesRT], { outRT });
}

/**
 * Keep a DisplayObject usable as a PIXI mask without letting its white mask texture render as normal scene content.
 *
 * In V13 the scene-particle soft transition can temporarily render the wrapper container directly while a belowTokens mask has just been attached. If the mask sprite remains renderable, its full-scene white allow-mask is drawn before the particle fade completes. PIXI masks should remain visible for mask evaluation, but non-renderable so they never contribute color.
 *
 * @param {PIXI.DisplayObject|null|undefined} maskObject
 * @returns {void}
 */
function suppressVisibleMaskPaint(maskObject) {
  if (!maskObject || maskObject.destroyed) return;
  try {
    maskObject.visible = true;
    maskObject.renderable = false;
    maskObject.alpha = 1;
  } catch (err) {
    logger.debug("FXMaster:", err);
  }
}

/**
 * Destroy a particle mask sprite after removing it from any wrapper container.
 *
 * @param {PIXI.Sprite|null|undefined} maskSprite
 * @param {PIXI.Container|null|undefined} [container]
 * @returns {void}
 */
function destroyParticleMaskSprite(maskSprite, container = null) {
  try {
    if (container && container.mask === maskSprite) container.mask = null;
  } catch (err) {
    logger.debug("FXMaster:", err);
  }

  if (!maskSprite || maskSprite.destroyed) return;

  try {
    maskSprite.parent?.removeChild?.(maskSprite);
  } catch (err) {
    logger.debug("FXMaster:", err);
  }

  try {
    maskSprite.mask = null;
  } catch (err) {
    logger.debug("FXMaster:", err);
  }

  try {
    maskSprite.texture = safeMaskTexture(maskSprite.texture);
  } catch (err) {
    logger.debug("FXMaster:", err);
  }

  try {
    const texture = maskSprite.texture ?? null;
    if (!texture || typeof texture.off !== "function") return;
    maskSprite.destroy({ texture: false, baseTexture: false });
  } catch (err) {
    logger.debug("FXMaster:", err);
  }
}

const PARTICLE_RUNTIME_IN_PLACE_OPTION_KEYS = new Set([
  "belowTokens",
  "belowTiles",
  "belowForeground",
  "levels",
  "backgroundEnabled",
  "backgroundMode",
  "backgroundDuration",
  "backgroundGroundMovementSpeed",
  "backgroundOpacity",
  "backgroundFillVariation",
  "backgroundDriftStrength",
  "backgroundDriftScale",
  "backgroundSandRippleStrength",
  "backgroundReflectionStrength",
  "backgroundShimmerStrength",
  "backgroundShimmerSpeed",
  "backgroundMigrationEnabled",
  "backgroundMigrationSpeed",
  "backgroundTrailsEnabled",
  "backgroundTrailRefillEnabled",
  "backgroundTrailRefillDuration",
  "backgroundTrailWidth",
  "backgroundTrailStrength",
  "backgroundCoverage",
  "backgroundPatchSize",
  "backgroundPileStrength",
  "backgroundPileSize",
  "backgroundLeafSize",
  "backgroundParticleSize",
  "backgroundInteractionEnabled",
  "backgroundInteractionRadius",
  "backgroundInteractionStrength",
  "backgroundInteractionSwirl",
  "backgroundInteractionLiftChance",
  "backgroundInteractionElevationThreshold",
  "backgroundInteractionSettleTime",
  "backgroundInteractionSettleImpact",
  "backgroundSweepEnabled",
  "backgroundSweepOpacity",
  "backgroundSweepScale",
  "backgroundSweepSpeed",
  "backgroundSweepStrength",
]);

function particleRoutingComparableValue(value) {
  const raw =
    value && typeof value === "object" && Object.prototype.hasOwnProperty.call(value, "value") ? value.value : value;
  if (Array.isArray(raw)) return raw.map((v) => String(v)).sort();
  if (raw && typeof raw === "object") {
    const out = {};
    for (const key of Object.keys(raw).sort()) out[key] = particleRoutingComparableValue(raw[key]);
    return out;
  }
  return raw;
}

function particleRoutingStableString(value) {
  try {
    return JSON.stringify(particleRoutingComparableValue(value));
  } catch (_err) {
    return String(value);
  }
}

/**
 * Return true when a scene-particle config edit changes only FXMaster-owned runtime options: compositor routing/masking or a persistent background surface. These options do not require replacing the particle emitter. Updating the existing runtime in place is cheaper, preserves timed background progress, and avoids mask transition artifacts.
 *
 * @param {object|null|undefined} previous
 * @param {object|null|undefined} next
 * @returns {boolean}
 */
function particleOptionsChangedOnlyRuntimeRoutingOrBackground(previous, next) {
  const prev = previous && typeof previous === "object" ? previous : {};
  const cur = next && typeof next === "object" ? next : {};
  const keys = new Set([...Object.keys(prev), ...Object.keys(cur)]);
  let sawInPlaceChange = false;

  for (const key of keys) {
    const before = particleRoutingStableString(prev[key]);
    const after = particleRoutingStableString(cur[key]);
    if (before === after) continue;
    if (!PARTICLE_RUNTIME_IN_PLACE_OPTION_KEYS.has(key)) return false;
    sawInPlaceChange = true;
  }

  return sawInPlaceChange;
}

function particleOptionsCanUpdateInPlace(EffectClass, existing, previous, next) {
  try {
    if (
      typeof existing?.canUpdateParticleOptionsInPlace === "function" &&
      existing.canUpdateParticleOptionsInPlace(previous, next)
    )
      return true;
  } catch (err) {
    logger.debug("FXMaster:", err);
  }

  try {
    if (
      typeof EffectClass?.canUpdateParticleOptionsInPlace === "function" &&
      EffectClass.canUpdateParticleOptionsInPlace(previous, next)
    )
      return true;
  } catch (err) {
    logger.debug("FXMaster:", err);
  }

  return false;
}

async function updateParticleOptionsInPlace(existing, options, previous) {
  if (typeof existing?.updateParticleOptions !== "function") return false;
  try {
    const result = existing.updateParticleOptions(options, { previous });
    if (result && typeof result.then === "function") await result;
    return result !== false;
  } catch (err) {
    logger.debug("FXMaster:", err);
    return false;
  }
}

export class ParticleEffectsLayer extends BaseEffectsLayer {
  static get layerOptions() {
    return foundry.utils.mergeObject(super.layerOptions, { name: "particle-effects" });
  }

  constructor() {
    super();
    this.#initializeInverseOcclusionFilter();
    this.mask = canvas.masks.scene;

    this.particleEffects = new Map();
    this.regionEffects = new Map();
    this.stackEntries = new Map();
    this._stackRoots = new Map();
    this._transientStackRows = new Map();
    this._lastKnownOrder = new Map();
    this._regionMaskRTs = new Map();
    this._regionBelowTokensNeeded = false;
    this._regionBelowTilesNeeded = false;
    this._sceneMaskBundle = { base: null, cutoutTokens: null, cutoutTiles: null, cutoutCombined: null };

    this._belowContainer = null;
    this._aboveContent = null;

    this._sceneBelowBase = null;
    this._sceneBelowCutout = null;
    this._sceneAboveBase = null;
    this._sceneAboveCutout = null;

    this._sceneBelowBaseMask = null;
    this._sceneBelowCutoutMask = null;
    this._sceneAboveBaseMask = null;
    this._sceneAboveCutoutMask = null;

    this._scratchGfx = null;
    this._aboveMaskGfx = null;
    this._dyingSceneEffects = new Set();
    this._lastViewSize = { w: canvas.app.renderer.view?.width | 0, h: canvas.app.renderer.view?.height | 0 };
    this._gatePassCache = new Map();
    this._weatherOcclusionTilePresence = { key: null, value: false };
    this._aboveWeatherRevealRT = null;
    this._aboveWeatherRevealFilter = null;
    this._aboveTintIsolationFilter = null;

    this._lastSceneMaskMatrix = null;
    this._currentCameraMatrix = null;
    this._lastSceneSuppressionOverlaySignature = "";
    this._lastSceneSuppressionNeedsMasking = false;
    this._compositedSceneParticleSourceUidsKey = null;

    this._lastRegionMaskMatrix = null;

    this._tokensDirty = false;
    this._lastBelowObjectCoverageMatrix = null;
    this._lastBelowTokenCoverageSignature = null;
    this._lastBelowTileCoverageSignature = null;

    this._coalescedSceneSuppressionRefresh = null;
    this._lastSceneDarknessSignature = "";
    this._lastRegionDarknessSignatures = new Map();
    this._lastDarknessLevel = getSceneDarknessLevel();

    this._particleBackgroundTrailStores = new Map();
    this._particleTrailTokenPositions = new Map();
    this._particleTrailStampedTokenEnds = new Map();
    this._particleTrailDirtyTokenIds = new Set();
    this._particleTrailMovementDirtyTokenIds = new Set();
    this._particleTrailActiveTokenIds = new Map();
    this._particleTrailLastSampleTick = 0;
    this._particleTrailIdleSamples = 0;
    this._particleTrailForceNextSample = false;
    this._particleTrailTokenAuthorities = new Map();
    this._particleTrailOutboundSegments = [];
    this._particleTrailLastQueryBatchTick = 0;
    this._particleTrailQuerySequence = 0;
    this._particleTrailQuerySessionId = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;
    this._particleTrailQueryUserStates = new Map();
    this._particleTrailRecentQueryEvents = new Map();
    this._particleTrailSessionEvents = new Map();
    this._particleTrailSessionRevision = 0;
    this._particleTrailHistoryStoreStates = new WeakMap();
    this._particleTrailPersistedHistorySource = null;
    this._particleTrailPersistedHistoryRevision = -1;
    this._particleTrailPersistedHistoryEvents = [];
    this._particleTrailLastHistoryRestoreKey = "";

    this.renderable = false;
  }

  _getParticleBackgroundTrailStore(descriptor, uid) {
    const key = String(uid ?? "").trim();
    if (!key || !descriptor) return null;

    const expectedType = String(descriptor?.type ?? "");
    let store = this._particleBackgroundTrailStores.get(key) ?? null;
    if (store && String(store.type ?? "") !== expectedType) {
      try {
        store.destroy?.();
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
      this._particleBackgroundTrailStores.delete(key);
      store = null;
    }

    if (!store) {
      try {
        store = createParticleBackgroundTrailStore(descriptor, { uid: key });
      } catch (err) {
        logger.debug("FXMaster:", err);
        store = null;
      }
      if (store) this._particleBackgroundTrailStores.set(key, store);
    }

    return store;
  }

  _disableParticleBackgroundTrailStore(uid) {
    const key = String(uid ?? "").trim();
    if (!key) return;
    try {
      this._particleBackgroundTrailStores.get(key)?.setEnabled?.(false);
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
  }

  _destroyAllParticleBackgroundTrailStores() {
    for (const store of this._particleBackgroundTrailStores.values()) {
      try {
        store?.destroy?.();
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
    }
    this._particleBackgroundTrailStores.clear();
    this._particleTrailTokenPositions.clear();
    this._particleTrailStampedTokenEnds.clear();
    this._particleTrailDirtyTokenIds.clear();
    this._particleTrailMovementDirtyTokenIds.clear();
    this._particleTrailActiveTokenIds.clear();
    this._particleTrailLastSampleTick = 0;
    this._particleTrailIdleSamples = 0;
    this._particleTrailForceNextSample = false;
    this._particleTrailTokenAuthorities.clear();
    this._particleTrailOutboundSegments.length = 0;
    this._particleTrailLastQueryBatchTick = 0;
    for (const state of this._particleTrailQueryUserStates.values()) state.pending.length = 0;
    this._particleTrailQueryUserStates.clear();
    this._particleTrailRecentQueryEvents.clear();
    this._particleTrailSessionEvents.clear();
    this._particleTrailSessionRevision = 0;
    this._particleTrailHistoryStoreStates = new WeakMap();
    this._particleTrailPersistedHistorySource = null;
    this._particleTrailPersistedHistoryRevision = -1;
    this._particleTrailPersistedHistoryEvents = [];
    this._particleTrailLastHistoryRestoreKey = "";
  }

  /**
   * Destroy the optional persistent background surface owned by a particle runtime.
   *
   * @param {PIXI.DisplayObject|null|undefined} fx
   * @returns {void}
   */
  _destroyParticleBackgroundSurface(fx) {
    const surface = fx?.__fxmBackgroundSurface ?? null;
    if (!surface) return;

    try {
      surface.destroy?.();
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    try {
      delete fx.__fxmBackgroundSurface;
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
  }

  /**
   * Create, configure, and place a particle effect's optional persistent background surface.
   *
   * The surface is inserted into the same wrapper as the emitter, immediately behind it, so all
   * existing scene/Region masks and stack routing apply to both pieces together.
   *
   * @param {PIXI.DisplayObject|null|undefined} fx
   * @param {PIXI.Container|null|undefined} container
   * @returns {object|null}
   */
  _syncParticleBackgroundSurface(fx, container) {
    if (!fx || fx.destroyed || !container || container.destroyed) return null;

    let descriptor = null;
    try {
      descriptor = fx.constructor?.backgroundSurface ?? null;
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    const backgroundUid = String(
      fx.__fxmBackgroundUid ?? fx.id ?? fx.constructor?.label ?? descriptor?.type ?? "particle-background",
    );
    const enabled = !!descriptor && particleBackgroundEnabled(fx.__fxmOptions ?? {});
    if (!enabled) {
      this._disableParticleBackgroundTrailStore(backgroundUid);
      this._destroyParticleBackgroundSurface(fx);
      return null;
    }

    const expectedType = String(descriptor?.type ?? "");
    let surfaceOptions = fx.__fxmOptions ?? {};
    try {
      surfaceOptions = fx.constructor?.mergeWithDefaults?.(surfaceOptions) ?? surfaceOptions;
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
    try {
      surfaceOptions = {
        ...surfaceOptions,
        __fxmResolvedTint: fx._resolveTintOption?.(surfaceOptions) ?? null,
      };
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
    const trailStore = this._getParticleBackgroundTrailStore(descriptor, backgroundUid);
    let surface = fx.__fxmBackgroundSurface ?? null;
    if (surface && String(surface.type ?? "") !== expectedType) {
      this._destroyParticleBackgroundSurface(fx);
      surface = null;
    }

    const dimensions = CONFIG.fxmaster?.getParticleDimensions?.(fx) ?? canvas?.dimensions ?? null;
    const renderer = CONFIG.fxmaster?.getParticleRenderer?.(fx) ?? canvas?.app?.renderer ?? null;
    if (!surface) {
      try {
        surface = createParticleBackgroundSurface(descriptor, {
          uid: backgroundUid,
          options: surfaceOptions,
          state: fx.__fxmBackgroundState ?? {},
          dimensions,
          renderer,
          trailStore,
          owner: fx,
        });
        if (surface) fx.__fxmBackgroundSurface = surface;
      } catch (err) {
        logger.debug("FXMaster:", err);
        surface = null;
      }
    }

    if (!surface) return null;

    try {
      surface.configure?.({
        options: surfaceOptions,
        state: fx.__fxmBackgroundState ?? {},
        dimensions,
        renderer,
        trailStore,
        owner: fx,
      });
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    const display = surface.displayObject ?? null;
    if (!display || display.destroyed) {
      this._destroyParticleBackgroundSurface(fx);
      return null;
    }

    try {
      if (display.parent !== container) {
        display.parent?.removeChild?.(display);
        const fxIndex = fx.parent === container ? container.getChildIndex(fx) : container.children.length;
        container.addChildAt(display, Math.max(1, Math.min(fxIndex, container.children.length)));
      } else {
        const fxIndex = fx.parent === container ? container.getChildIndex(fx) : container.children.length;
        const desiredIndex = Math.max(1, Math.min(Math.max(1, fxIndex - 1), container.children.length - 1));
        if (container.getChildIndex(display) !== desiredIndex) container.setChildIndex(display, desiredIndex);
      }
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    try {
      surface.update?.({ fx, now: particleBackgroundNow() });
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    return surface;
  }

  _destroyRegionSurfaceEdgeFadeFilter(entry) {
    const filter = entry?.edgeFadeFilter ?? null;
    const container = entry?.container ?? null;
    if (filter && container && !container.destroyed) {
      try {
        const filters = Array.isArray(container.filters) ? container.filters.filter((item) => item !== filter) : [];
        container.filters = filters.length ? filters : null;
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
    }
    try {
      if (filter?.uniforms) filter.uniforms.uRegionFadeMask = PIXI.Texture.EMPTY;
      filter?.destroy?.();
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
    if (entry) {
      if (container && !container.destroyed && entry.edgeFadePreviousFilterAreaCaptured) {
        try {
          container.filterArea = entry.edgeFadePreviousFilterArea ?? null;
        } catch (err) {
          logger.debug("FXMaster:", err);
        }
      }
      entry.edgeFadeFilter = null;
      entry.edgeFadeMaskEntry = null;
      entry.edgeFadePreviousFilterArea = null;
      entry.edgeFadePreviousFilterAreaCaptured = false;
    }
  }

  _syncRegionSurfaceEdgeFadeFilter(entry, maskEntry) {
    const container = entry?.container ?? null;
    const texture = maskEntry?.texture ?? null;
    if (!container || container.destroyed || !texture || texture.destroyed || texture.baseTexture?.destroyed) {
      this._destroyRegionSurfaceEdgeFadeFilter(entry);
      return false;
    }

    let filter = entry.edgeFadeFilter ?? null;
    if (!filter || filter.destroyed) {
      try {
        filter = new RegionSurfaceEdgeFadeFilter(maskEntry);
        entry.edgeFadeFilter = filter;
      } catch (err) {
        logger.debug("FXMaster:", err);
        this._destroyRegionSurfaceEdgeFadeFilter(entry);
        return false;
      }
    }

    try {
      filter.configure(maskEntry);
      const filters = Array.isArray(container.filters) ? container.filters.filter(Boolean) : [];
      if (!filters.includes(filter)) container.filters = [...filters, filter];
      if (!entry.edgeFadePreviousFilterAreaCaptured) {
        entry.edgeFadePreviousFilterArea = container.filterArea ?? null;
        entry.edgeFadePreviousFilterAreaCaptured = true;
      }
      const screen = canvas?.app?.renderer?.screen ?? null;
      if (screen) container.filterArea = screen;
      entry.edgeFadeMaskEntry = maskEntry;
      return true;
    } catch (err) {
      logger.debug("FXMaster:", err);
      this._destroyRegionSurfaceEdgeFadeFilter(entry);
      return false;
    }
  }

  /**
   * Advance every active and fading persistent particle background.
   *
   * @returns {void}
   */
  _particleTrailTokenSnapshot(token) {
    if (!token || token.destroyed || token.isPreview) return null;
    if (token?.document?.parent !== canvas?.scene) return null;
    if (token?.document?.hidden || token.visible === false) return null;

    const id = String(token.id ?? token?.document?.id ?? "").trim();
    if (!id) return null;

    let center = null;
    try {
      center = token.center ?? token.bounds?.center ?? null;
    } catch (_err) {}

    const grid = Math.max(1, Number(canvas?.dimensions?.size) || 100);
    const width = Math.max(1, Number(token.w ?? token.bounds?.width ?? token?.document?.width * grid) || grid);
    const height = Math.max(1, Number(token.h ?? token.bounds?.height ?? token?.document?.height * grid) || grid);
    const x = Number(center?.x ?? Number(token.x) + width / 2);
    const y = Number(center?.y ?? Number(token.y) + height / 2);
    if (!Number.isFinite(x) || !Number.isFinite(y)) return null;

    let levelIds = [];
    try {
      levelIds = Array.from(getDocumentAssignedLevelIds(token?.document ?? null, canvas?.scene ?? null))
        .map((levelId) => String(levelId ?? "").trim())
        .filter(Boolean)
        .sort()
        .slice(0, 32);
    } catch (_err) {
      levelIds = [];
    }

    return {
      id,
      x,
      y,
      width,
      height,
      elevation: particleTrailTokenElevationValue(token),
      sceneId: String(canvas?.scene?.id ?? ""),
      levelIds,
    };
  }

  _particleTrailTokenMatchesRuntime(token, fx) {
    const rawSelection = normalizeStoredParticleOptionValue(
      fx?.__fxmTrailLevelIds ?? fx?.__fxmLevels ?? fx?.__fxmOptions?.levels,
    );
    const selectedLevels = getSelectedSceneLevelIds(rawSelection, canvas?.scene ?? null);
    if (!selectedLevels?.size) return true;

    const tokenLevels = getDocumentAssignedLevelIds(token?.document ?? null, canvas?.scene ?? null);
    if (!tokenLevels?.size) return true;
    for (const levelId of tokenLevels) {
      if (selectedLevels.has(levelId)) return true;
    }
    return false;
  }

  _particleTrailEventMatchesRuntime(event, fx) {
    const rawSelection = normalizeStoredParticleOptionValue(
      fx?.__fxmTrailLevelIds ?? fx?.__fxmLevels ?? fx?.__fxmOptions?.levels,
    );
    const selectedLevels = getSelectedSceneLevelIds(rawSelection, canvas?.scene ?? null);
    if (!selectedLevels?.size) return true;

    const eventLevels = Array.isArray(event?.levelIds) ? event.levelIds : [];
    if (!eventLevels.length) return true;
    return eventLevels.some((levelId) => selectedLevels.has(String(levelId)));
  }

  _particleTrailHistorySignature({ surface, fx } = {}) {
    const background = fx?.__fxmBackgroundState?.background ?? {};
    const movement = fx?.__fxmBackgroundState?.backgroundMovement ?? {};
    return [
      surface?.type ?? "",
      surface?.uid ?? fx?.__fxmBackgroundUid ?? "",
      background.profile ?? 0,
      background.revision ?? 0,
      background.startedAt ?? "",
      background.patternSeed ?? "",
      movement.profile ?? 0,
      movement.revision ?? 0,
      movement.startedAt ?? "",
    ].join(":");
  }

  _particleTrailHistoryState(record) {
    const store = record?.surface?.trailStore ?? null;
    if (!store) return null;
    const signature = this._particleTrailHistorySignature(record);
    let state = this._particleTrailHistoryStoreStates.get(store) ?? null;
    if (!state || state.signature !== signature) {
      state = { signature, initialized: false, applied: new Set() };
      this._particleTrailHistoryStoreStates.set(store, state);
    }
    return state;
  }

  _particleTrailMovementEpoch({ fx } = {}) {
    const movementStartedAt = Number(fx?.__fxmBackgroundState?.backgroundMovement?.startedAt);
    if (Number.isFinite(movementStartedAt) && movementStartedAt > 0) return movementStartedAt;
    const backgroundStartedAt = Number(fx?.__fxmBackgroundState?.background?.startedAt);
    if (Number.isFinite(backgroundStartedAt) && backgroundStartedAt > 0) return backgroundStartedAt;
    return 0;
  }

  _rememberParticleTrailEvent(rawEvent) {
    const event = normalizeParticleBackgroundMovementEvent(rawEvent);
    if (!event) return null;
    const previous = this._particleTrailSessionEvents.get(event.eventId) ?? null;
    this._particleTrailSessionEvents.set(event.eventId, event);
    if (!previous) this._particleTrailSessionRevision += 1;

    if (this._particleTrailSessionEvents.size > PARTICLE_BACKGROUND_MOVEMENT_HISTORY_MAX_EVENTS) {
      const ordered = Array.from(this._particleTrailSessionEvents.values()).sort(
        (a, b) => a.occurredAt - b.occurredAt || a.eventId.localeCompare(b.eventId),
      );
      const removeCount = ordered.length - PARTICLE_BACKGROUND_MOVEMENT_HISTORY_MAX_EVENTS;
      for (let index = 0; index < removeCount; index++) {
        this._particleTrailSessionEvents.delete(ordered[index].eventId);
      }
    }
    return event;
  }

  _particleTrailMovementHistoryEvents(persistedOverride = null) {
    const scene = canvas?.scene ?? null;
    if (!scene) return Array.from(this._particleTrailSessionEvents.values());

    const persisted = persistedOverride ?? readParticleBackgroundMovementHistory(scene);
    if (
      persisted.source !== this._particleTrailPersistedHistorySource ||
      persisted.revision !== this._particleTrailPersistedHistoryRevision
    ) {
      this._particleTrailPersistedHistorySource = persisted.source;
      this._particleTrailPersistedHistoryRevision = persisted.revision;
      this._particleTrailPersistedHistoryEvents = persisted.events;
    }

    const merged = new Map();
    for (const event of this._particleTrailSessionEvents.values()) merged.set(event.eventId, event);
    for (const event of this._particleTrailPersistedHistoryEvents) merged.set(event.eventId, event);

    const events = Array.from(merged.values()).sort(
      (a, b) => a.occurredAt - b.occurredAt || a.eventId.localeCompare(b.eventId),
    );
    if (events.length > PARTICLE_BACKGROUND_MOVEMENT_HISTORY_MAX_EVENTS) {
      events.splice(0, events.length - PARTICLE_BACKGROUND_MOVEMENT_HISTORY_MAX_EVENTS);
    }
    return events;
  }

  _restoreParticleBackgroundMovementHistory(records, { now, tick } = {}) {
    const trackingRecords = this._particleTrailTrackingRecords(records);
    if (!trackingRecords.length) return;

    const scene = canvas?.scene ?? null;
    const persisted = scene ? readParticleBackgroundMovementHistory(scene) : null;
    const states = trackingRecords.map((record) => this._particleTrailHistoryState(record));
    const restoreKey = [
      trackingRecords.map((record) => this._particleTrailHistorySignature(record)).join("|"),
      this._particleTrailSessionRevision,
      persisted?.revision ?? -1,
      persisted?.updatedAt ?? 0,
      persisted?.events?.length ?? 0,
    ].join("::");
    if (restoreKey === this._particleTrailLastHistoryRestoreKey && states.every((state) => state?.initialized)) return;

    const wallNow = Number.isFinite(Number(now)) ? Number(now) : particleBackgroundNow();
    const currentTick = Number.isFinite(Number(tick)) ? Number(tick) : particleBackgroundMonotonicNow();
    const events = this._particleTrailMovementHistoryEvents(persisted);
    let flushNeeded = false;

    for (let index = 0; index < trackingRecords.length; index++) {
      const record = trackingRecords[index];
      const { surface, fx } = record;
      const state = states[index];
      if (!state) continue;

      const shouldRestoreHistory =
        typeof surface?.shouldRestoreTokenTrailHistory === "function"
          ? surface.shouldRestoreTokenTrailHistory()
          : true;
      if (!shouldRestoreHistory) {
        state.initialized = true;
        state.applied = new Set(events.map((event) => event.eventId));
        continue;
      }

      const epoch = this._particleTrailMovementEpoch(record);
      const activitySeconds =
        typeof surface?._trailActivityDurationSeconds === "function"
          ? Number(surface._trailActivityDurationSeconds())
          : Infinity;
      const historyWindowMs = Number.isFinite(activitySeconds)
        ? Math.max(250, activitySeconds * 1000 + PARTICLE_TRAIL_HISTORY_CLOCK_SKEW_MS)
        : Infinity;
      const relevant = events.filter(
        (event) =>
          event.occurredAt + PARTICLE_TRAIL_HISTORY_CLOCK_SKEW_MS >= epoch &&
          (!Number.isFinite(historyWindowMs) || wallNow - event.occurredAt <= historyWindowMs) &&
          this._particleTrailEventMatchesRuntime(event, fx) &&
          particleTrailTokenWithinElevationThreshold(
            { elevation: event.tokenElevation, levelIds: event.levelIds },
            fx,
          ),
      );
      const unseen = relevant.filter((event) => !state.applied.has(event.eventId));

      if (surface?.type === "scatter") {
        if (!state.initialized || unseen.length) {
          try {
            surface.replayTokenTrailHistory?.(relevant, { now: wallNow, tick: currentTick });
            state.applied = new Set(relevant.map((event) => event.eventId));
            state.initialized = true;
            flushNeeded = true;
          } catch (err) {
            logger.debug("FXMaster:", err);
          }
        }
        continue;
      }

      for (const event of unseen) {
        const ageMs = Math.max(0, wallNow - event.occurredAt);
        if (surface?.trailRefillEnabled) {
          const expirySeconds = Number.isFinite(activitySeconds)
            ? activitySeconds
            : Math.max(1, Number(surface.durationSeconds) || 1);
          if (ageMs >= Math.max(0.25, expirySeconds) * 1000) {
            state.applied.add(event.eventId);
            continue;
          }
        }

        try {
          surface.stampTokenTrail?.({
            from: event.from,
            to: event.to,
            tokenWidth: event.tokenWidth,
            tokenHeight: event.tokenHeight,
            tick: currentTick,
            ageMs,
            disturbanceSeed: event.seed,
          });
          state.applied.add(event.eventId);
          flushNeeded = true;
        } catch (err) {
          logger.debug("FXMaster:", err);
        }
      }
      state.initialized = true;
    }

    this._particleTrailLastHistoryRestoreKey = restoreKey;
    if (flushNeeded) this._flushParticleTrailSurfaces(trackingRecords);
  }

  _particleTrailRememberActiveToken(tokenOrId, tick = particleBackgroundMonotonicNow(), ttlMs = PARTICLE_TRAIL_ACTIVE_CANDIDATE_TTL_MS) {
    const tokenId = String(tokenOrId?.id ?? tokenOrId?.document?.id ?? tokenOrId ?? "").trim();
    if (!tokenId) return;
    const currentTick = Number.isFinite(Number(tick)) ? Number(tick) : particleBackgroundMonotonicNow();
    const expiresAt = currentTick + Math.max(100, Number(ttlMs) || PARTICLE_TRAIL_ACTIVE_CANDIDATE_TTL_MS);
    const previous = Number(this._particleTrailActiveTokenIds.get(tokenId)) || 0;
    this._particleTrailActiveTokenIds.set(tokenId, Math.max(previous, expiresAt));
  }

  /**
   * Record which connected User initiated a Token document movement. The
   * `updateToken` hook fires on every client with the requesting user id, so
   * this creates a shared authority decision without any extra transport.
   *
   * @param {TokenDocument|null|undefined} tokenDocument
   * @param {{changed?:object,userId?:string|null}} [context]
   * @returns {void}
   */
  noteParticleTrailTokenMovement(tokenDocument, { changed = {}, userId = null } = {}) {
    if (!tokenDocument || tokenDocument.parent !== canvas?.scene) return;
    const tokenId = String(tokenDocument.id ?? "").trim();
    const authorityUserId = String(userId ?? "").trim();
    if (!tokenId || !authorityUserId) return;

    const movementKeys = ["x", "y", "width", "height", "elevation"];
    if (
      changed &&
      typeof changed === "object" &&
      !movementKeys.some((key) => Object.prototype.hasOwnProperty.call(changed, key))
    )
      return;

    const tick = particleBackgroundMonotonicNow();
    this._particleTrailTokenAuthorities.set(tokenId, {
      userId: authorityUserId,
      expiresAt: tick + PARTICLE_TRAIL_AUTHORITY_TTL_MS,
    });
    this._particleTrailDirtyTokenIds.add(tokenId);
    if (["x", "y"].some((key) => Object.prototype.hasOwnProperty.call(changed, key))) {
      this._particleTrailMovementDirtyTokenIds.add(tokenId);
    }
    this._particleTrailRememberActiveToken(tokenId, tick, PARTICLE_TRAIL_ACTIVE_CANDIDATE_TTL_MS);
    this._particleTrailForceNextSample = true;
    this._particleTrailIdleSamples = 0;
  }

  /**
   * Keep a recently controlled/uncontrolled Token in the trail sampling set for
   * a short grace window. Foundry can drop a dragged Token from the controlled
   * and moving-token collections before the last visual movement sample lands,
   * so this preserves trail continuity through user deselection.
   *
   * @param {Token|TokenDocument|null|undefined} tokenOrDocument
   * @returns {void}
   */
  noteParticleTrailTokenControl(tokenOrDocument) {
    const tokenId = String(tokenOrDocument?.id ?? tokenOrDocument?.document?.id ?? "").trim();
    if (!tokenId) return;

    const tick = particleBackgroundMonotonicNow();
    this._particleTrailDirtyTokenIds.add(tokenId);
    this._particleTrailRememberActiveToken(tokenId, tick, PARTICLE_TRAIL_ACTIVE_CANDIDATE_TTL_MS * 1.5);

    const currentUserId = String(game?.user?.id ?? "").trim();
    if (currentUserId) {
      this._particleTrailTokenAuthorities.set(tokenId, {
        userId: currentUserId,
        expiresAt: tick + PARTICLE_TRAIL_AUTHORITY_TTL_MS,
      });
    }

    this._particleTrailForceNextSample = true;
    this._particleTrailIdleSamples = 0;
  }

  /**
   * Forget transient movement state for a deleted Token.
   *
   * @param {TokenDocument|string|null|undefined} tokenOrId
   * @returns {void}
   */
  forgetParticleTrailToken(tokenOrId) {
    const tokenId = String(tokenOrId?.id ?? tokenOrId ?? "").trim();
    if (!tokenId) return;
    this._particleTrailTokenAuthorities.delete(tokenId);
    this._particleTrailDirtyTokenIds.delete(tokenId);
    this._particleTrailMovementDirtyTokenIds.delete(tokenId);
    this._particleTrailActiveTokenIds.delete(tokenId);
    this._particleTrailTokenPositions.delete(tokenId);
    this._particleTrailStampedTokenEnds.delete(tokenId);
  }

  _particleTrailFallbackAuthorityUserId(token, participants = null) {
    const sceneId = String(canvas?.scene?.id ?? "");
    const users = Array.isArray(participants)
      ? participants
      : getParticleBackgroundQueryParticipants(sceneId);
    const permitted = users.filter((user) => particleTrailUserCanUpdateToken(user, token?.document));
    permitted.sort((a, b) => {
      const gmOrder = Number(!!b?.isActiveGM) - Number(!!a?.isActiveGM);
      return gmOrder || String(a?.id ?? "").localeCompare(String(b?.id ?? ""));
    });
    return String(permitted[0]?.id ?? "");
  }

  _particleTrailUserMovesToken(user, token) {
    const tokenId = String(token?.id ?? token?.document?.id ?? "");
    if (!user || !tokenId) return false;

    try {
      const movingTokens = user.movingTokens ?? null;
      if (!movingTokens) return false;
      if (movingTokens.has?.(token?.document)) return true;
      for (const document of movingTokens) {
        if (String(document?.id ?? "") === tokenId) return true;
      }
    } catch (_err) {}
    return false;
  }

  _particleTrailIsLocalAuthority(token, tick) {
    if (!particleBackgroundQueriesAvailable()) return true;

    const currentUserId = String(game?.user?.id ?? "");
    const tokenId = String(token?.id ?? token?.document?.id ?? "");
    const sceneId = String(canvas?.scene?.id ?? "");
    if (!currentUserId || !tokenId || !sceneId) return false;

    const participants = getParticleBackgroundQueryParticipants(sceneId);
    if (participants.length <= 1) return true;

    const permitted = participants.filter((user) => particleTrailUserCanUpdateToken(user, token?.document));
    if (!permitted.length) return true;

    const movingUsers = permitted.filter((user) => this._particleTrailUserMovesToken(user, token));
    movingUsers.sort((a, b) => String(a?.id ?? "").localeCompare(String(b?.id ?? "")));
    if (movingUsers.length) return String(movingUsers[0]?.id ?? "") === currentUserId;

    const authority = this._particleTrailTokenAuthorities.get(tokenId) ?? null;
    if (authority) {
      if (Number(authority.expiresAt) >= Number(tick)) {
        const authorityId = String(authority.userId ?? "");
        if (permitted.some((user) => String(user?.id ?? "") === authorityId)) {
          return authorityId === currentUserId;
        }
      } else {
        this._particleTrailTokenAuthorities.delete(tokenId);
      }
    }

    const fallback = this._particleTrailFallbackAuthorityUserId(token, permitted);
    return fallback ? fallback === currentUserId : true;
  }

  _particleTrailAdjustedMovementEndpoints(previous, current, sampleTick) {
    const from = { x: Number(previous?.x), y: Number(previous?.y) };
    const to = { x: Number(current?.x), y: Number(current?.y) };
    if (![from.x, from.y, to.x, to.y].every(Number.isFinite)) return { from, to };

    const tokenId = String(current?.id ?? "").trim();
    const sceneId = String(current?.sceneId ?? canvas?.scene?.id ?? "").trim();
    const last = this._particleTrailStampedTokenEnds.get(tokenId) ?? null;
    if (!tokenId || !last || String(last.sceneId ?? "") !== sceneId) return { from, to };

    const tick = Number.isFinite(Number(sampleTick)) ? Number(sampleTick) : particleBackgroundMonotonicNow();
    if (tick - (Number(last.tick) || 0) > PARTICLE_TRAIL_ACTIVE_CANDIDATE_TTL_MS * 3) return { from, to };

    const grid = Math.max(1, Number(canvas?.dimensions?.size) || 100);
    const footprint = Math.max(grid, Number(current?.width) || grid, Number(current?.height) || grid);
    const fromGap = Math.hypot(from.x - last.x, from.y - last.y);
    const toGap = Math.hypot(to.x - last.x, to.y - last.y);
    const segmentLength = Math.hypot(to.x - from.x, to.y - from.y);
    const snapDistance = Math.max(grid * 0.22, footprint * 0.18);
    const nearLastEnd = Math.max(snapDistance * 2.6, Math.min(footprint * 1.20, segmentLength * 0.55));

    if (fromGap > snapDistance && toGap <= nearLastEnd) {
      return { from: { x: last.x, y: last.y }, to };
    }

    return { from, to };
  }

  _particleTrailRememberStampedTokenEnd(event, tick, ageMs = 0) {
    const tokenId = String(event?.tokenId ?? "").trim();
    const to = event?.to ?? null;
    if (!tokenId || !to) return;

    const x = Number(to.x);
    const y = Number(to.y);
    if (!Number.isFinite(x) || !Number.isFinite(y)) return;

    const currentTick = Number.isFinite(Number(tick)) ? Number(tick) : particleBackgroundMonotonicNow();
    const agedTick = currentTick - Math.max(0, Number(ageMs) || 0);
    this._particleTrailStampedTokenEnds.set(tokenId, {
      x,
      y,
      tick: Math.max(0, agedTick),
      sceneId: String(canvas?.scene?.id ?? event?.sceneId ?? ""),
    });
  }

  _createParticleTrailDisturbance(previous, current, sampleTick) {
    this._particleTrailQuerySequence = (this._particleTrailQuerySequence + 1) >>> 0;
    const sceneId = String(canvas?.scene?.id ?? "");
    const senderUserId = String(game?.user?.id ?? "");
    const eventId = [
      sceneId,
      senderUserId,
      this._particleTrailQuerySessionId,
      this._particleTrailQuerySequence.toString(36),
    ].join(":");
    const endpoints = this._particleTrailAdjustedMovementEndpoints(previous, current, sampleTick);

    return {
      eventId,
      tokenId: String(current?.id ?? ""),
      from: endpoints.from,
      to: endpoints.to,
      tokenWidth: (Number(previous.width) + Number(current.width)) / 2,
      tokenHeight: (Number(previous.height) + Number(current.height)) / 2,
      tokenElevation: particleTrailFiniteNumber(current?.elevation, particleTrailTokenElevationValue(current)),
      sampleTick: Number(sampleTick),
      occurredAt: particleBackgroundNow(),
      seed: hashParticleTrailString32(eventId),
      levelIds: Array.isArray(current?.levelIds) ? current.levelIds.slice(0, 32) : [],
    };
  }

  _applyParticleTrailDisturbance(
    records,
    token,
    disturbance,
    tick,
    { ageMs = 0, remember = true } = {},
  ) {
    const normalized = normalizeParticleBackgroundMovementEvent(disturbance) ?? disturbance;
    if (remember) this._rememberParticleTrailEvent(normalized);
    let matched = false;
    let stamped = false;

    for (const record of records) {
      const { surface, fx } = record;
      const hasEventLevels = Array.isArray(normalized?.levelIds) && normalized.levelIds.length > 0;
      if (hasEventLevels) {
        if (!this._particleTrailEventMatchesRuntime(normalized, fx)) continue;
      } else if (token && !this._particleTrailTokenMatchesRuntime(token, fx)) continue;
      const thresholdSource = {
        elevation: Number.isFinite(Number(normalized?.tokenElevation))
          ? Number(normalized.tokenElevation)
          : particleTrailTokenElevationValue(token),
        levelIds: Array.isArray(normalized?.levelIds) ? normalized.levelIds : [],
      };
      if (!particleTrailTokenWithinElevationThreshold(thresholdSource, fx)) continue;

      matched = true;
      const historyState = this._particleTrailHistoryState(record);
      if (normalized?.eventId && historyState?.applied.has(normalized.eventId)) continue;
      try {
        const result = surface.stampTokenTrail?.({
          from: normalized.from,
          to: normalized.to,
          tokenWidth: normalized.tokenWidth,
          tokenHeight: normalized.tokenHeight,
          tick,
          ageMs,
          disturbanceSeed: normalized.seed,
        });
        stamped ||= !!result;
        if (normalized?.eventId) historyState?.applied.add(normalized.eventId);
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
    }

    if (stamped) this._particleTrailRememberStampedTokenEnd(normalized, tick, ageMs);
    return { matched, stamped };
  }

  _flushParticleTrailSurfaces(records) {
    const seen = new Set();
    for (const { surface } of records) {
      if (!surface || seen.has(surface)) continue;
      seen.add(surface);
      try {
        surface.flushTrails?.();
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
    }
  }

  _queueParticleTrailDisturbance(disturbance) {
    if (!disturbance) return;
    this._particleTrailOutboundSegments.push(disturbance);
    if (this._particleTrailOutboundSegments.length > PARTICLE_TRAIL_QUERY_MAX_PENDING_SEGMENTS) {
      this._particleTrailOutboundSegments.splice(
        0,
        this._particleTrailOutboundSegments.length - PARTICLE_TRAIL_QUERY_MAX_PENDING_SEGMENTS,
      );
    }
  }

  _queueParticleTrailQueryForUser(user, segments) {
    const userId = String(user?.id ?? "");
    const sceneId = String(canvas?.scene?.id ?? "");
    if (!userId || !sceneId || !segments.length) return;

    let state = this._particleTrailQueryUserStates.get(userId) ?? null;
    if (!state) {
      state = { user, sceneId, inFlight: false, pending: [] };
      this._particleTrailQueryUserStates.set(userId, state);
    }

    state.user = user;
    if (state.sceneId !== sceneId) {
      state.sceneId = sceneId;
      state.pending.length = 0;
    }
    state.pending.push(...segments);
    if (state.pending.length > PARTICLE_TRAIL_QUERY_MAX_PENDING_SEGMENTS) {
      state.pending.splice(0, state.pending.length - PARTICLE_TRAIL_QUERY_MAX_PENDING_SEGMENTS);
    }

    this._sendNextParticleTrailQuery(userId, state);
  }

  _sendNextParticleTrailQuery(userId, state) {
    if (!state || state.inFlight || !state.pending.length) return;
    if (this._particleTrailQueryUserStates.get(userId) !== state) return;
    if (!particleBackgroundQueriesAvailable() || !state.user?.active) {
      state.pending.length = 0;
      this._particleTrailQueryUserStates.delete(userId);
      return;
    }

    const sceneId = String(canvas?.scene?.id ?? "");
    if (!sceneId || state.sceneId !== sceneId) {
      state.pending.length = 0;
      return;
    }

    const rawSegments = state.pending.splice(0, PARTICLE_TRAIL_QUERY_MAX_SEGMENTS);
    const nowTick = particleBackgroundMonotonicNow();
    const payload = {
      version: PARTICLE_BACKGROUND_DISTURBANCE_QUERY_VERSION,
      sceneId,
      senderUserId: String(game?.user?.id ?? ""),
      issuedAt: particleBackgroundNow(),
      segments: rawSegments.map((segment) => ({
        eventId: segment.eventId,
        tokenId: segment.tokenId,
        from: segment.from,
        to: segment.to,
        tokenWidth: segment.tokenWidth,
        tokenHeight: segment.tokenHeight,
        tokenElevation: segment.tokenElevation,
        seed: segment.seed,
        occurredAt: segment.occurredAt,
        levelIds: segment.levelIds,
        ageMs: particleTrailClamp(
          nowTick - Number(segment.sampleTick),
          0,
          PARTICLE_TRAIL_QUERY_MAX_EVENT_AGE_MS,
          0,
        ),
      })),
    };

    state.inFlight = true;
    void Promise.resolve(queryParticleBackgroundDisturbances(state.user, payload))
      .catch((err) => logger.debug("FXMaster: particle-background query failed", err))
      .finally(() => {
        if (this._particleTrailQueryUserStates.get(userId) !== state) return;
        state.inFlight = false;
        if (!state.user?.active) {
          state.pending.length = 0;
          this._particleTrailQueryUserStates.delete(userId);
          return;
        }
        if (state.pending.length) this._sendNextParticleTrailQuery(userId, state);
      });
  }

  _flushParticleTrailQueryBroadcasts(tick, { force = false } = {}) {
    if (!this._particleTrailOutboundSegments.length) return;

    const sampleTick = Number.isFinite(Number(tick)) ? Number(tick) : particleBackgroundMonotonicNow();
    if (!force && sampleTick - this._particleTrailLastQueryBatchTick < PARTICLE_TRAIL_QUERY_BATCH_INTERVAL_MS) return;
    this._particleTrailLastQueryBatchTick = sampleTick;

    const sceneId = String(canvas?.scene?.id ?? "");
    if (!sceneId) {
      this._particleTrailOutboundSegments.length = 0;
      return;
    }

    const segments = this._particleTrailOutboundSegments.splice(0, PARTICLE_TRAIL_QUERY_MAX_PENDING_SEGMENTS);
    const issuedAt = particleBackgroundNow();
    const persistencePayload = {
      version: 1,
      sceneId,
      senderUserId: String(game?.user?.id ?? ""),
      issuedAt,
      segments: segments.map((segment) => ({
        eventId: segment.eventId,
        tokenId: segment.tokenId,
        from: segment.from,
        to: segment.to,
        tokenWidth: segment.tokenWidth,
        tokenHeight: segment.tokenHeight,
        tokenElevation: segment.tokenElevation,
        seed: segment.seed,
        occurredAt: segment.occurredAt,
        levelIds: segment.levelIds,
      })),
    };
    void Promise.resolve(persistParticleBackgroundDisturbances(persistencePayload)).catch((err) =>
      logger.debug("FXMaster: particle-background persistence query failed", err),
    );

    if (!particleBackgroundQueriesAvailable()) return;
    const recipients = getParticleBackgroundQueryRecipients(sceneId);
    if (!recipients.length) return;
    for (const user of recipients) this._queueParticleTrailQueryForUser(user, segments);
  }

  _pruneParticleTrailRecentQueryEvents(tick) {
    const cutoff = Number(tick) - PARTICLE_TRAIL_QUERY_DEDUPE_TTL_MS;
    for (const [eventId, observedAt] of this._particleTrailRecentQueryEvents) {
      if (Number(observedAt) >= cutoff) continue;
      this._particleTrailRecentQueryEvents.delete(eventId);
    }
    while (this._particleTrailRecentQueryEvents.size > PARTICLE_TRAIL_QUERY_MAX_RECENT_EVENTS) {
      const oldest = this._particleTrailRecentQueryEvents.keys().next().value;
      if (oldest === undefined) break;
      this._particleTrailRecentQueryEvents.delete(oldest);
    }
  }

  /**
   * Apply a batch received through Foundry's User query system.
   *
   * @param {object} queryData
   * @returns {{accepted:number}}
   */
  receiveParticleBackgroundDisturbanceQuery(queryData = {}) {
    if (Number(queryData?.version) !== PARTICLE_BACKGROUND_DISTURBANCE_QUERY_VERSION) {
      return { accepted: 0, reason: "unsupported-version" };
    }

    const sceneId = String(queryData?.sceneId ?? "");
    if (!sceneId || sceneId !== String(canvas?.scene?.id ?? "")) return { accepted: 0 };

    const senderUserId = String(queryData?.senderUserId ?? "").trim();
    if (!senderUserId || senderUserId === String(game?.user?.id ?? "")) return { accepted: 0 };

    let sender = null;
    try {
      sender = game?.users?.get?.(senderUserId) ?? null;
      if (!sender) {
        const users = Array.isArray(game?.users?.contents) ? game.users.contents : Array.from(game?.users ?? []);
        sender = users.find((user) => String(user?.id ?? "") === senderUserId) ?? null;
      }
    } catch (_err) {
      sender = null;
    }
    if (!sender?.active) return { accepted: 0 };
    const senderViewedScene = String(sender.viewedScene ?? "");
    if (senderViewedScene && senderViewedScene !== sceneId) return { accepted: 0 };

    const rawSegments = Array.isArray(queryData?.segments)
      ? queryData.segments.slice(0, PARTICLE_TRAIL_QUERY_MAX_INBOUND_SEGMENTS)
      : [];
    if (!rawSegments.length) return { accepted: 0 };

    const records = this._collectParticleBackgroundSurfaceRecords();
    const trackingRecords = this._particleTrailTrackingRecords(records);
    if (!trackingRecords.length) return { accepted: 0 };

    const receiptTick = particleBackgroundMonotonicNow();
    const receiptWallTime = particleBackgroundNow();
    const issuedAt = Number(queryData?.issuedAt);
    const transportAgeMs = Number.isFinite(issuedAt)
      ? particleTrailClamp(receiptWallTime - issuedAt, 0, PARTICLE_TRAIL_QUERY_MAX_EVENT_AGE_MS, 0)
      : 0;
    this._pruneParticleTrailRecentQueryEvents(receiptTick);
    const grid = Math.max(1, Number(canvas?.dimensions?.size) || 100);
    const minDistance = Math.max(0.5, grid * PARTICLE_TRAIL_MIN_DISTANCE_GRID);
    let accepted = 0;

    for (const raw of rawSegments) {
      const eventId = String(raw?.eventId ?? "").slice(0, 192);
      const tokenId = String(raw?.tokenId ?? "").trim();
      if (!eventId || !tokenId || this._particleTrailRecentQueryEvents.has(eventId)) continue;

      const token = canvas?.tokens?.get?.(tokenId) ?? null;
      const snapshot = this._particleTrailTokenSnapshot(token);
      if (!snapshot || !particleTrailUserCanUpdateToken(sender, token?.document)) continue;

      const from = particleTrailPoint(raw?.from);
      const to = particleTrailPoint(raw?.to);
      if (!from || !to) continue;

      const distance = Math.hypot(to.x - from.x, to.y - from.y);
      const tokenWidth = particleTrailClamp(raw?.tokenWidth, grid * 0.1, grid * 20, snapshot.width);
      const tokenHeight = particleTrailClamp(raw?.tokenHeight, grid * 0.1, grid * 20, snapshot.height);
      const teleportThreshold = Math.max(
        grid * PARTICLE_TRAIL_TELEPORT_GRID_SPACES,
        Math.max(tokenWidth, tokenHeight) * PARTICLE_TRAIL_TELEPORT_GRID_SPACES,
      );
      if (distance < minDistance || distance > teleportThreshold) continue;

      const ageMs = particleTrailClamp(
        particleTrailFiniteNumber(raw?.ageMs, 0) + transportAgeMs,
        0,
        PARTICLE_TRAIL_QUERY_MAX_EVENT_AGE_MS,
        0,
      );
      const rawOccurredAt = Number(raw?.occurredAt);
      const occurredAt = Number.isFinite(rawOccurredAt)
        ? particleTrailClamp(
            rawOccurredAt,
            receiptWallTime - PARTICLE_TRAIL_QUERY_MAX_EVENT_AGE_MS,
            receiptWallTime + PARTICLE_TRAIL_HISTORY_CLOCK_SKEW_MS,
            receiptWallTime - ageMs,
          )
        : receiptWallTime - ageMs;
      const suppliedSeed = Number(raw?.seed);
      const disturbance = {
        eventId,
        tokenId,
        from,
        to,
        tokenWidth,
        tokenHeight,
        tokenElevation: snapshot.elevation,
        occurredAt,
        seed: Number.isFinite(suppliedSeed) ? Math.trunc(suppliedSeed) >>> 0 : hashParticleTrailString32(eventId),
        levelIds: Array.isArray(raw?.levelIds)
          ? raw.levelIds
              .map((levelId) => String(levelId ?? "").trim())
              .filter(Boolean)
              .sort()
              .slice(0, 32)
          : snapshot.levelIds,
      };

      const result = this._applyParticleTrailDisturbance(
        trackingRecords,
        token,
        disturbance,
        receiptTick,
        { ageMs },
      );
      if (!result.matched) continue;

      this._particleTrailRecentQueryEvents.set(eventId, receiptTick);
      this._particleTrailTokenAuthorities.set(tokenId, {
        userId: senderUserId,
        expiresAt: receiptTick + PARTICLE_TRAIL_AUTHORITY_TTL_MS,
      });
      accepted += 1;
    }

    if (accepted) this._flushParticleTrailSurfaces(trackingRecords);
    return { accepted };
  }

  _particleTrailTokenIsInMovingCollection(tokenId) {
    const id = String(tokenId ?? "").trim();
    if (!id) return false;

    const hasMovingToken = (movingTokens) => {
      if (!movingTokens) return false;
      try {
        for (const entry of movingTokens) {
          const entryId = String(entry?.id ?? entry?.document?.id ?? entry ?? "").trim();
          if (entryId === id) return true;
        }
      } catch (_err) {}
      return false;
    };

    try {
      const users = Array.isArray(game?.users?.contents) ? game.users.contents : Array.from(game?.users ?? []);
      for (const user of users) {
        if (hasMovingToken(user?.movingTokens)) return true;
      }
    } catch (_err) {
      if (hasMovingToken(game?.user?.movingTokens)) return true;
    }

    return false;
  }

  _particleTrailBaselineCanStamp(previous, current, token, tick, movementDirtyTokenIds) {
    if (!previous || previous.sceneId !== current?.sceneId) return false;
    const tokenId = String(current?.id ?? "").trim();
    if (!tokenId) return false;
    if (movementDirtyTokenIds?.has?.(tokenId)) return true;
    if (this._particleTrailTokenIsInMovingCollection(tokenId)) return true;

    const sampledAt = Number(previous.sampledAt ?? previous.sampleTick ?? previous.seenAt ?? 0);
    if (!Number.isFinite(sampledAt) || sampledAt <= 0) return false;
    if (Number(tick) - sampledAt <= PARTICLE_TRAIL_STALE_BASELINE_MS) return true;

    try {
      if (token?.controlled && Number(tick) - sampledAt <= PARTICLE_TRAIL_ACTIVE_CANDIDATE_TTL_MS) return true;
    } catch (_err) {}

    return false;
  }

  _particleTrailTrackingRecords(records) {
    const trackingRecords = [];
    const seenStores = new Set();
    for (const record of records) {
      const surface = record?.surface ?? null;
      const store = surface?.trailStore ?? null;
      if (!surface?.trailsEnabled || !store?.enabled || surface?._destroyed || seenStores.has(store)) continue;
      seenStores.add(store);
      trackingRecords.push(record);
    }
    return trackingRecords;
  }

  _particleTrailMovementCandidateIds(tick) {
    if (!this._particleTrailTokenPositions.size) return null;

    const currentTick = Number.isFinite(Number(tick)) ? Number(tick) : particleBackgroundMonotonicNow();
    const ids = new Set(this._particleTrailDirtyTokenIds);
    for (const tokenId of this._particleTrailDirtyTokenIds) {
      this._particleTrailRememberActiveToken(tokenId, currentTick, PARTICLE_TRAIL_ACTIVE_CANDIDATE_TTL_MS);
    }

    for (const [tokenId, authority] of this._particleTrailTokenAuthorities) {
      if (Number(authority?.expiresAt) < currentTick) this._particleTrailTokenAuthorities.delete(tokenId);
    }

    for (const [tokenId, expiresAt] of this._particleTrailActiveTokenIds) {
      if (Number(expiresAt) < currentTick || !canvas?.tokens?.get?.(tokenId)) {
        this._particleTrailActiveTokenIds.delete(tokenId);
        continue;
      }
      ids.add(tokenId);
    }

    const rememberCandidate = (tokenOrId, ttlMs = PARTICLE_TRAIL_ACTIVE_CANDIDATE_TTL_MS) => {
      const id = String(tokenOrId?.id ?? tokenOrId?.document?.id ?? tokenOrId ?? "").trim();
      if (!id) return;
      ids.add(id);
      this._particleTrailRememberActiveToken(id, currentTick, ttlMs);
    };

    const pushMovingTokens = (movingTokens) => {
      if (!movingTokens) return;
      try {
        for (const document of movingTokens) rememberCandidate(document, PARTICLE_TRAIL_ACTIVE_CANDIDATE_TTL_MS * 1.5);
      } catch (_err) {}
    };

    try {
      const users = Array.isArray(game?.users?.contents) ? game.users.contents : Array.from(game?.users ?? []);
      for (const user of users) pushMovingTokens(user?.movingTokens);
    } catch (_err) {
      pushMovingTokens(game?.user?.movingTokens);
    }

    try {
      for (const token of canvas?.tokens?.controlled ?? []) {
        rememberCandidate(token, PARTICLE_TRAIL_ACTIVE_CANDIDATE_TTL_MS * 1.5);
      }
    } catch (_err) {}

    return ids;
  }

  _updateParticleTokenTrails(records, tick = particleBackgroundMonotonicNow()) {
    const trackingRecords = this._particleTrailTrackingRecords(records);
    if (!trackingRecords.length) {
      this._particleTrailTokenPositions.clear();
      this._particleTrailDirtyTokenIds.clear();
      this._particleTrailMovementDirtyTokenIds.clear();
      this._particleTrailActiveTokenIds.clear();
      this._particleTrailLastSampleTick = Number(tick) || 0;
      this._particleTrailIdleSamples = 0;
      this._particleTrailForceNextSample = false;
      this._particleTrailOutboundSegments.length = 0;
      return;
    }

    const sampleTick = Number.isFinite(Number(tick)) ? Number(tick) : particleBackgroundMonotonicNow();
    const movementDirtyTokenIdsAtSample = new Set(this._particleTrailMovementDirtyTokenIds);
    const idleSamples = Math.max(0, Number(this._particleTrailIdleSamples) || 0);
    const candidateIds = this._particleTrailMovementCandidateIds(sampleTick);
    const sampleInterval = candidateIds !== null && candidateIds.size
      ? PARTICLE_TRAIL_ACTIVE_SAMPLE_INTERVAL_MS
      : idleSamples >= PARTICLE_TRAIL_IDLE_BACKOFF_AFTER_SAMPLES
        ? PARTICLE_TRAIL_IDLE_SAMPLE_INTERVAL_MS
        : PARTICLE_TRAIL_SAMPLE_INTERVAL_MS;
    if (
      !this._particleTrailForceNextSample &&
      sampleTick - this._particleTrailLastSampleTick < sampleInterval
    ) {
      this._flushParticleTrailQueryBroadcasts(sampleTick);
      return;
    }
    this._particleTrailLastSampleTick = sampleTick;
    this._particleTrailForceNextSample = false;

    if (candidateIds !== null && !candidateIds.size) {
      this._particleTrailIdleSamples = Math.min(1000, idleSamples + 1);
      this._flushParticleTrailQueryBroadcasts(sampleTick);
      return;
    }

    const sourceTokens = candidateIds === null
      ? Array.from(canvas?.tokens?.placeables ?? [])
      : Array.from(candidateIds)
          .map((tokenId) => canvas?.tokens?.get?.(tokenId) ?? null)
          .filter(Boolean);
    if (candidateIds !== null) {
      for (const tokenId of candidateIds) {
        if (!canvas?.tokens?.get?.(tokenId)) {
          this._particleTrailDirtyTokenIds.delete(String(tokenId));
          this._particleTrailMovementDirtyTokenIds.delete(String(tokenId));
        }
      }
    }

    const nextPositions = candidateIds === null ? new Map() : new Map(this._particleTrailTokenPositions);
    const grid = Math.max(1, Number(canvas?.dimensions?.size) || 100);
    const minDistance = Math.max(0.5, grid * PARTICLE_TRAIL_MIN_DISTANCE_GRID);
    let stampedLocally = false;
    let movementObserved = false;

    for (const token of sourceTokens) {
      const current = this._particleTrailTokenSnapshot(token);
      if (!current) {
        const tokenId = String(token?.id ?? token?.document?.id ?? "").trim();
        if (tokenId) {
          this._particleTrailDirtyTokenIds.delete(tokenId);
          this._particleTrailMovementDirtyTokenIds.delete(tokenId);
        }
        continue;
      }

      const previous = this._particleTrailTokenPositions.get(current.id) ?? null;
      if (!previous || previous.sceneId !== current.sceneId) {
        nextPositions.set(current.id, { ...current, sampledAt: sampleTick });
        this._particleTrailDirtyTokenIds.delete(current.id);
        this._particleTrailMovementDirtyTokenIds.delete(current.id);
        continue;
      }

      const dx = current.x - previous.x;
      const dy = current.y - previous.y;
      const distance = Math.hypot(dx, dy);
      if (distance >= minDistance) {
        movementObserved = true;
        this._particleTrailRememberActiveToken(current.id, sampleTick, PARTICLE_TRAIL_ACTIVE_CANDIDATE_TTL_MS);
      }
      if (distance < minDistance) {
        nextPositions.set(current.id, { ...current, x: previous.x, y: previous.y, sampledAt: sampleTick });
        this._particleTrailDirtyTokenIds.delete(current.id);
        this._particleTrailMovementDirtyTokenIds.delete(current.id);
        continue;
      }

      const teleportThreshold = Math.max(
        grid * PARTICLE_TRAIL_TELEPORT_GRID_SPACES,
        Math.max(current.width, current.height) * PARTICLE_TRAIL_TELEPORT_GRID_SPACES,
      );
      const canStampFromPrevious = this._particleTrailBaselineCanStamp(
        previous,
        current,
        token,
        sampleTick,
        movementDirtyTokenIdsAtSample,
      );
      if (!canStampFromPrevious) {
        nextPositions.set(current.id, { ...current, sampledAt: sampleTick });
        this._particleTrailDirtyTokenIds.delete(current.id);
        this._particleTrailMovementDirtyTokenIds.delete(current.id);
        continue;
      }

      if (distance <= teleportThreshold && this._particleTrailIsLocalAuthority(token, sampleTick)) {
        const disturbance = this._createParticleTrailDisturbance(previous, current, sampleTick);
        const result = this._applyParticleTrailDisturbance(trackingRecords, token, disturbance, sampleTick);
        if (result.matched) {
          stampedLocally ||= result.stamped;
          this._queueParticleTrailDisturbance(disturbance);
        }
      }

      nextPositions.set(current.id, { ...current, sampledAt: sampleTick });
      this._particleTrailDirtyTokenIds.delete(current.id);
      this._particleTrailMovementDirtyTokenIds.delete(current.id);
    }

    this._particleTrailTokenPositions = nextPositions;
    if (movementObserved || stampedLocally) this._particleTrailIdleSamples = 0;
    else this._particleTrailIdleSamples = Math.min(1000, idleSamples + 1);
    if (stampedLocally) this._flushParticleTrailSurfaces(trackingRecords);
    this._flushParticleTrailQueryBroadcasts(sampleTick);
  }

  _collectParticleBackgroundSurfaceRecords() {
    const seenSurfaces = new Set();
    const records = [];

    const collect = (fx) => {
      const surface = fx?.__fxmBackgroundSurface ?? null;
      if (!surface || seenSurfaces.has(surface)) return;
      seenSurfaces.add(surface);
      records.push({ surface, fx });
    };

    for (const fx of this.particleEffects.values()) collect(fx);
    for (const fx of this._dyingSceneEffects) collect(fx);
    for (const entries of this.regionEffects.values()) {
      for (const entry of entries) collect(entry?.fx ?? null);
    }

    return records;
  }

  _updateParticleBackgroundSurfaces() {
    const records = this._collectParticleBackgroundSurfaceRecords();
    if (!records.length) {
      if (this._particleBackgroundRuntimeActive) {
        this._particleBackgroundRuntimeActive = false;
        this._updateParticleTokenTrails([], particleBackgroundMonotonicNow());
      }
      return;
    }

    this._particleBackgroundRuntimeActive = true;
    const now = particleBackgroundNow();
    const tick = particleBackgroundMonotonicNow();
    this._restoreParticleBackgroundMovementHistory(records, { now, tick });
    this._updateParticleTokenTrails(records, tick);

    for (const { surface, fx } of records) {
      try {
        surface.update?.({ fx, now, tick });
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
    }
  }

  /**
   * Register a renderable particle slot for the global compositor.
   *
   * @param {string} uid
   * @param {PIXI.Container} root
   * @param {PIXI.DisplayObject} slot
   * @param {object} [data]
   * @returns {void}
   */
  _registerStackSlot(uid, root, slot, data = {}) {
    if (!uid || !root || !slot) return;
    this._unregisterStackSlot(uid);

    let slots = this._stackRoots.get(root);
    if (!slots) {
      slots = new Set();
      this._stackRoots.set(root, slots);
    }
    slots.add(slot);

    this.stackEntries.set(uid, { uid, root, slot, ...data });
    this._compositedSceneParticleSourceUidsKey = null;
  }

  /**
   * Toggle whether a scene-particle source container should be hidden from the live canvas because it is being presented by the global stack compositor.
   *
   * The compositor temporarily restores renderability while rendering the registered slot into an off-screen texture, then restores this suppressed state. Keeping the source slot hidden between compositor frames prevents the uncomposited scene-wide emitter from leaking through native V14 Level views.
   *
   * @param {PIXI.DisplayObject|null|undefined} slot
   * @param {boolean} suppressed
   * @returns {void}
   */
  _setSceneParticleSourceSuppressed(slot, suppressed) {
    if (!slot || slot.destroyed) return;

    try {
      slot.__fxmCompositorSourceSuppressed = !!suppressed;
      slot.visible = true;
      slot.renderable = !suppressed;
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
  }

  /**
   * Resolve a registered particle stack entry's compositor source scope.
   *
   * Region particle rows created before this metadata was explicit still carry a region id. Treating that as region scope keeps live source suppression robust across Level switches and hot reloads instead of letting the raw Region emitter render over native overhead surfaces.
   *
   * @param {object|null|undefined} entry
   * @returns {"scene"|"region"|null}
   */
  _resolveStackEntryScope(entry) {
    if (entry?.scope === "scene" || entry?.scope === "region") return entry.scope;
    if (entry?.regionId || entry?.ownerId) return "region";
    return null;
  }

  /**
   * Return whether the live source slot for a stack entry should be hidden from the native canvas because the compositor is responsible for presenting it.
   *
   * @param {object|null|undefined} entry
   * @param {Set<string>} wanted
   * @returns {boolean|null}
   */
  _entryShouldSuppressCompositedSource(entry, wanted) {
    const scope = this._resolveStackEntryScope(entry);
    if (scope !== "scene" && scope !== "region") return null;

    if (scope === "region") {
      const regionDoc =
        getSceneRegionDocumentById(entry?.regionId ?? entry?.ownerId, canvas?.scene ?? null) ?? entry?.document ?? null;
      if (!regionDoc || !regionDocumentCanApplyInCurrentView(regionDoc, canvas?.scene ?? null)) return true;

      const gatedOff = entry?.fx && "enabled" in entry.fx && entry.fx.enabled === false;
      if (gatedOff || entry?.container?.visible === false) return true;
    }

    return wanted.has(entry?.uid);
  }

  /**
   * Return whether every registered composited source already matches the requested suppressed/unsuppressed state.
   *
   * The requested UID set can remain unchanged while native Level transitions or Region refreshes recreate/render-enable a source container. A cheap state check prevents the key fast-path from leaving a Region source visible after switching floors.
   *
   * @param {Set<string>} wanted
   * @returns {boolean}
   */
  _compositedSceneParticleSourcesAreSynchronized(wanted) {
    for (const entry of this.stackEntries.values()) {
      const expected = this._entryShouldSuppressCompositedSource(entry, wanted);
      if (expected === null) continue;

      const slot = entry?.slot ?? entry?.container ?? null;
      if (!slot || slot.destroyed) continue;
      if (!!slot.__fxmCompositorSourceSuppressed !== expected) return false;
      if (slot.renderable === expected) return false;
    }

    return true;
  }

  /**
   * Hide or reveal scene-particle source slots that are currently rendered through the global FX stack compositor.
   *
   * @param {string[]|Set<string>} [uids=[]]
   * @returns {void}
   */
  setCompositedSceneParticleSources(uids = []) {
    const wanted = uids instanceof Set ? uids : new Set(Array.isArray(uids) ? uids.filter(Boolean) : []);
    const key = Array.from(wanted).sort().join("|");
    if (
      key === this._compositedSceneParticleSourceUidsKey &&
      this._compositedSceneParticleSourcesAreSynchronized(wanted)
    )
      return;
    this._compositedSceneParticleSourceUidsKey = key;

    for (const entry of this.stackEntries.values()) {
      const expected = this._entryShouldSuppressCompositedSource(entry, wanted);
      if (expected === null) continue;
      this._setSceneParticleSourceSuppressed(entry?.slot ?? entry?.container ?? null, expected);
    }
  }

  /**
   * Remove a compositor slot registration.
   *
   * @param {string} uid
   * @returns {void}
   */
  _unregisterStackSlot(uid) {
    const entry = this.stackEntries.get(uid);
    if (!entry) return;

    if (this._resolveStackEntryScope(entry)) {
      this._setSceneParticleSourceSuppressed(entry?.slot ?? entry?.container ?? null, false);
    }

    const slots = this._stackRoots.get(entry.root);
    if (slots) {
      slots.delete(entry.slot);
      if (!slots.size) this._stackRoots.delete(entry.root);
    }

    this.stackEntries.delete(uid);
    this._compositedSceneParticleSourceUidsKey = null;
  }

  /**
   * Return the runtime particle registration for a stored stack uid.
   *
   * @param {string} uid
   * @returns {object|null}
   */
  getStackParticleRuntime(uid) {
    return this.stackEntries.get(uid) ?? null;
  }

  /**
   * Return transient scene-particle stack rows that should continue rendering while a prior runtime fades out.
   *
   * @returns {Array<{ uid: string, kind: "particle", scope: "scene", renderIndex: number, layerLevel?: string|null, options?: object|null, levels?: unknown }>}
   */
  getTransientStackRows() {
    return Array.from(
      this._transientStackRows.values(),
      ({ uid, kind, scope, renderIndex, layerLevel, options, levels }) => ({
        uid,
        kind,
        scope: scope ?? "scene",
        renderIndex,
        layerLevel: layerLevel ?? null,
        options,
        levels,
      }),
    );
  }

  /**
   * Cache the current scene particle ordering so transient fade-out rows can be reinserted at the correct compositor index.
   *
   * @returns {void}
   */
  _syncSceneStackOrderCache() {
    this._lastKnownOrder.clear();
    const orderedRows = getOrderedEnabledEffectRenderRows(canvas.scene);
    for (let index = 0; index < orderedRows.length; index++) {
      const uid = orderedRows[index]?.uid;
      if (!uid.startsWith("scene:particle:")) continue;
      this._lastKnownOrder.set(uid, index);
    }
  }

  /**
   * Apply stack z-index ordering to live scene-particle containers.
   *
   * @returns {void}
   */
  _syncLiveSceneParticleStackOrder() {
    const orderedRows = getOrderedEnabledEffectRenderRows(canvas.scene, { clone: false });
    const zByUid = new Map();
    for (let index = 0; index < orderedRows.length; index++) {
      const uid = orderedRows[index]?.uid;
      if (typeof uid !== "string" || !uid.startsWith("scene:particle:")) continue;
      zByUid.set(uid, orderedRows.length - index);
    }

    for (const row of this._transientStackRows.values()) {
      const uid = row?.uid;
      if (!uid) continue;
      const renderIndex = Number(row.renderIndex);
      const z = Number.isFinite(renderIndex) ? orderedRows.length - renderIndex : 0;
      zByUid.set(uid, z);
    }

    const parents = new Set();
    for (const [uid, entry] of this.stackEntries.entries()) {
      const zIndex = zByUid.get(uid);
      if (!Number.isFinite(zIndex)) continue;
      const slot = entry?.slot ?? entry?.container ?? entry?.fx ?? null;
      if (!slot || slot.destroyed) continue;
      try {
        slot.zIndex = zIndex;
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
      try {
        if (entry?.fx && !entry.fx.destroyed) entry.fx.zIndex = zIndex;
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
      if (slot.parent) parents.add(slot.parent);
    }

    for (const parent of parents) {
      if (!parent || parent.destroyed) continue;
      try {
        parent.sortableChildren = true;
        parent.sortChildren?.();
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
    }
  }

  /**
   * Re-register a scene runtime under a transient UID so it can continue rendering during fade-out.
   *
   * @param {string} runtimeUid
   * @returns {string|null}
   */
  _promoteSceneRuntimeToTransient(runtimeUid) {
    const entry = this.stackEntries.get(runtimeUid);
    if (!entry?.root || !entry?.slot) {
      this._unregisterStackSlot(runtimeUid);
      return null;
    }

    const renderIndex = this._lastKnownOrder.get(runtimeUid) ?? Number.MAX_SAFE_INTEGER;
    const transientUid = `${runtimeUid}::transient:${foundry.utils.randomID()}`;
    const { uid: _ignored, root, slot, ...data } = entry;
    this._unregisterStackSlot(runtimeUid);
    this._registerStackSlot(transientUid, root, slot, data);
    this._transientStackRows.set(transientUid, {
      uid: transientUid,
      kind: "particle",
      scope: "scene",
      renderIndex,
      layerLevel: data?.layerLevel ?? null,
      options: data?.options ?? null,
      levels: data?.levels ?? data?.options?.levels ?? null,
    });
    return transientUid;
  }

  /**
   * Remove a transient scene-particle row once fade-out has completed.
   *
   * @param {string|null|undefined} uid
   * @returns {void}
   */
  _clearTransientSceneRow(uid) {
    if (!uid) return;
    this._transientStackRows.delete(uid);
    this._unregisterStackSlot(uid);
  }

  /**
   * Ensure the pass-through filter used to isolate tinted above-darkness particles.
   *
   * @returns {PIXI.Filter|null}
   */
  _ensureAboveTintIsolationFilter() {
    if (this._aboveTintIsolationFilter && !this._aboveTintIsolationFilter.destroyed)
      return this._aboveTintIsolationFilter;

    try {
      this._aboveTintIsolationFilter = new PIXI.Filter(
        `
        precision mediump float;
        attribute vec2 aVertexPosition;
        uniform mat3 projectionMatrix;
        uniform vec4 inputSize;
        uniform vec4 outputFrame;
        varying vec2 vTextureCoord;
        void main() {
          vec2 position = aVertexPosition * max(outputFrame.zw, vec2(0.0)) + outputFrame.xy;
          vTextureCoord = aVertexPosition * (outputFrame.zw * inputSize.zw);
          gl_Position = vec4((projectionMatrix * vec3(position, 1.0)).xy, 0.0, 1.0);
        }
      `,
        `
        precision mediump float;
        varying vec2 vTextureCoord;
        uniform sampler2D uSampler;
        void main() {
          gl_FragColor = texture2D(uSampler, vTextureCoord);
        }
      `,
      );
      this._aboveTintIsolationFilter.blendMode = PIXI.BLEND_MODES.NORMAL;
      return this._aboveTintIsolationFilter;
    } catch (err) {
      logger.debug("FXMaster:", err);
      this._aboveTintIsolationFilter = null;
      return null;
    }
  }

  /**
   * Remove tint-isolation compositing from a scene particle container.
   *
   * @param {PIXI.Container|null} container
   * @returns {void}
   */
  _clearSceneParticleTintIsolation(container) {
    if (!container || container.destroyed || !container.__fxmAboveTintIsolationEnabled) return;

    const activeFilter = container.__fxmAboveTintIsolationFilter ?? this._aboveTintIsolationFilter;
    try {
      const filters = Array.isArray(container.filters)
        ? container.filters.filter((candidate) => candidate && candidate !== activeFilter)
        : [];
      container.filters = filters.length ? filters : null;
      container.filterArea = container.__fxmAboveTintIsolationFilterArea ?? null;
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    delete container.__fxmAboveTintIsolationEnabled;
    delete container.__fxmAboveTintIsolationFilter;
    delete container.__fxmAboveTintIsolationFilterArea;
  }

  /**
   * Synchronize tint-isolation compositing for a scene particle runtime.
   *
   * @param {PIXI.DisplayObject|null} fx
   * @param {PIXI.Container|null} container
   * @param {string} layerLevel
   * @returns {void}
   */
  _syncSceneParticleTintIsolation(fx, container, layerLevel) {
    if (!container || container.destroyed) return;

    const tintOption = fx?.__fxmOptions?.tint ?? fx?._fxmOptsCache?.tint ?? fx?.options?.tint;
    const shouldIsolate = layerLevel === "aboveDarkness" && particleTintEnabled(tintOption);
    if (!shouldIsolate) {
      this._clearSceneParticleTintIsolation(container);
      return;
    }

    const filter = this._ensureAboveTintIsolationFilter();
    if (!filter) return;

    try {
      const previousIsolationFilter = container.__fxmAboveTintIsolationFilter ?? null;
      const filters = Array.isArray(container.filters)
        ? container.filters.filter(
            (candidate) => candidate && candidate !== filter && candidate !== previousIsolationFilter,
          )
        : [];
      filters.push(filter);
      if (!container.__fxmAboveTintIsolationEnabled)
        container.__fxmAboveTintIsolationFilterArea = container.filterArea ?? null;
      container.filters = filters;
      container.filterArea = canvas?.app?.renderer?.screen ?? container.filterArea ?? null;
      container.__fxmAboveTintIsolationEnabled = true;
      container.__fxmAboveTintIsolationFilter = filter;
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
  }

  /**
   * Render a single particle stack slot into the supplied render texture.
   *
   * @param {string} uid
   * @param {PIXI.RenderTexture} renderTexture
   * @param {{ clear?: boolean, respectBelowTilesMask?: boolean, respectNativeOcclusion?: boolean, maskTextureOverride?: PIXI.Texture|PIXI.RenderTexture|false|null }} [options]
   * @returns {boolean}
   */
  renderStackParticle(
    uid,
    renderTexture,
    { clear = false, respectBelowTilesMask = true, respectNativeOcclusion = true, maskTextureOverride = null } = {},
  ) {
    const entry = this.stackEntries.get(uid);
    const renderer = canvas?.app?.renderer;
    if (!entry || !renderer || !renderTexture) return false;

    const { root, slot } = entry;
    if (!root || root.destroyed || !slot || slot.destroyed) return false;

    if (entry?.regionId) {
      const regionDoc = getSceneRegionDocumentById(entry.regionId, canvas?.scene ?? null) ?? entry?.document ?? null;
      if (!regionDoc || !regionDocumentCanApplyInCurrentView(regionDoc, canvas?.scene ?? null)) return false;

      const fx = entry?.fx ?? null;
      const container = entry?.container ?? slot;
      const compositorSuppressed = !!(
        container?.__fxmCompositorSourceSuppressed || slot?.__fxmCompositorSourceSuppressed
      );
      if (fx?.destroyed) return false;
      if (fx && "enabled" in fx && fx.enabled === false) return false;
      if (container?.visible === false) return false;
      if (container?.renderable === false && !compositorSuppressed) return false;
    }

    const slots = this._stackRoots.get(root);
    if (!slots?.size) return false;

    if (entry?.regionId) {
      this._applyRegionMaskForEntry(entry);
    } else {
      const sceneMaskEntry = respectBelowTilesMask || !entry?.belowTiles ? entry : { ...entry, belowTiles: false };
      this._applySceneMaskForEntry(root, { ...sceneMaskEntry, maskTextureOverride });
    }

    const previous = [];
    for (const candidate of slots) {
      if (!candidate || candidate.destroyed) continue;
      previous.push([candidate, candidate.visible, candidate.renderable]);
      const show = candidate === slot;
      candidate.visible = show;
      candidate.renderable = show;
    }

    const rootOcclusionFilter =
      root === this._belowContainer ? this._belowOccl : root === this._aboveContent ? this._aboveOccl : null;
    const priorRootOcclusionEnabled = rootOcclusionFilter ? !!rootOcclusionFilter.enabled : null;
    const canUseNativeWeatherOcclusion = canUseNativeWeatherOcclusionStackPass();
    const needsSceneWeatherTileCheck =
      canUseNativeWeatherOcclusion &&
      !entry?.regionId &&
      !!respectNativeOcclusion &&
      !entry?.belowForeground &&
      !entry?.belowTiles;
    const sceneHasWeatherOcclusionTiles = needsSceneWeatherTileCheck ? this._sceneHasWeatherOcclusionTiles() : false;

    /**
     * Plain scene particles can render directly from their dedicated scene slot when no native weather-occluding roof surfaces are involved. In V13 that direct slot path can leak its local scene clip, so only V14+ keeps the optimization.
     */
    const wantsNativeWeatherOcclusion =
      canUseNativeWeatherOcclusion &&
      !!respectNativeOcclusion &&
      (entry?.regionId
        ? !entry?.belowTiles || !!entry?.belowForeground
        : !!entry?.belowForeground || (!entry?.belowTiles && sceneHasWeatherOcclusionTiles));
    const hasMaskTextureOverride =
      !!maskTextureOverride && maskTextureOverride !== PIXI.Texture.EMPTY && !maskTextureOverride.destroyed;
    const useDirectSceneSlotRender =
      canUseDirectSceneParticleSlotRender() &&
      !hasMaskTextureOverride &&
      !entry?.regionId &&
      !entry?.belowTokens &&
      !entry?.belowTiles &&
      !entry?.belowForeground &&
      !wantsNativeWeatherOcclusion;

    let hasNativeCanvasLevel = false;
    try {
      hasNativeCanvasLevel = !!canvas?.level?.id;
    } catch (_err) {
      hasNativeCanvasLevel = false;
    }
    const useLocalSceneClip = useDirectSceneSlotRender && !hasNativeCanvasLevel;

    const stackSceneClipMask = slot instanceof PIXI.Container ? slot.__fxmStackSceneClipMask ?? null : null;
    if (stackSceneClipMask && !stackSceneClipMask.destroyed) {
      try {
        stackSceneClipMask.visible = true;
        stackSceneClipMask.renderable = false;
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
    }

    if (rootOcclusionFilter) {
      try {
        rootOcclusionFilter.enabled = wantsNativeWeatherOcclusion;
        rootOcclusionFilter.elevation = resolveParticleOcclusionElevation(entry, this.#elevation);
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
    }

    const activeMaskSprite = entry?.maskSprite ?? null;
    if (activeMaskSprite && !activeMaskSprite.destroyed) suppressVisibleMaskPaint(activeMaskSprite);
    let priorLocalSceneMask = null;
    let appliedLocalSceneClip = false;

    if (useLocalSceneClip && slot instanceof PIXI.Container) {
      const sceneClip = this._ensureSceneStackClipMask(slot);
      if (sceneClip && !sceneClip.destroyed) {
        priorLocalSceneMask = slot.mask ?? null;
        if (!priorLocalSceneMask) {
          try {
            slot.mask = sceneClip;
            appliedLocalSceneClip = true;
          } catch (err) {
            logger.debug("FXMaster:", err);
          }
        }
      }
    }

    const renderSubject = useDirectSceneSlotRender ? slot : root;

    const priorRootVisible = root.visible;
    const priorRootRenderable = root.renderable;
    root.visible = true;
    root.renderable = true;

    let renderWithLiveWorldTransform = false;
    try {
      renderWithLiveWorldTransform = fxmUpdateDisplayObjectWorldTransform(renderSubject);
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    let parentTransform = null;
    if (!renderWithLiveWorldTransform) {
      try {
        parentTransform = currentRenderParentMatrix(renderSubject);
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
    }

    try {
      renderer.render(renderSubject, {
        renderTexture,
        clear,
        ...(renderWithLiveWorldTransform ? {} : { transform: parentTransform }),
        skipUpdateTransform: !renderWithLiveWorldTransform ? false : true,
      });
      return true;
    } finally {
      if (rootOcclusionFilter) {
        try {
          rootOcclusionFilter.enabled = !!priorRootOcclusionEnabled;
          rootOcclusionFilter.elevation = this.#elevation;
        } catch (err) {
          logger.debug("FXMaster:", err);
        }
      }
      const maskSprite = entry?.maskSprite ?? null;
      if (maskSprite && !maskSprite.destroyed) suppressVisibleMaskPaint(maskSprite);
      if (stackSceneClipMask && !stackSceneClipMask.destroyed) {
        try {
          stackSceneClipMask.visible = true;
          stackSceneClipMask.renderable = false;
        } catch (err) {
          logger.debug("FXMaster:", err);
        }
      }
      if (appliedLocalSceneClip && slot instanceof PIXI.Container && !slot.destroyed) {
        try {
          slot.mask = priorLocalSceneMask ?? null;
        } catch (err) {
          logger.debug("FXMaster:", err);
        }
      }
      root.visible = priorRootVisible;
      root.renderable = priorRootRenderable;
      for (const [candidate, visible, renderable] of previous) {
        if (!candidate || candidate.destroyed) continue;
        candidate.visible = visible;
        candidate.renderable = renderable;
      }
    }
  }

  occlusionFilter;

  get elevation() {
    return this.#elevation;
  }
  set elevation(value) {
    if (typeof value !== "number" || Number.isNaN(value))
      throw new Error("ParticleEffectsLayer#elevation must be numeric.");
    if (value === this.#elevation) return;
    this.#elevation = value;
    try {
      if (this.occlusionFilter) this.occlusionFilter.elevation = value;
      if (this._belowOccl) this._belowOccl.elevation = value;
      if (this._aboveOccl) this._aboveOccl.elevation = value;
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
    if (this.parent) this.parent.sortDirty = true;
  }
  #elevation = Infinity;

  async _draw() {
    if (!isEnabled()) return;
    await this.drawParticleEffects();

    for (const region of getRegionEffectPlaceablesForCurrentView(canvas?.scene ?? null)) {
      await this.drawRegionParticleEffects(region, { soft: true });
    }

    if (!this._ticker) {
      const lowPriority = PIXI.UPDATE_PRIORITY?.LOW ?? -25;
      const PRIO = lowPriority + 0.75;
      try {
        canvas.app.ticker.add(this._animate, this, PRIO);
      } catch {
        canvas.app.ticker.add(this._animate, this);
      }
      this._ticker = true;
    }
  }

  async _tearDown() {
    if (this.requestRegionMaskRefreshAll?.cancel) this.requestRegionMaskRefreshAll.cancel();
    if (this.requestRegionMaskRefresh?.cancel) this.requestRegionMaskRefresh.cancel();
    if (this._coalescedSceneSuppressionRefresh?.cancel) this._coalescedSceneSuppressionRefresh.cancel();

    this.#destroyEffects();

    try {
      this._scratchGfx?.destroy(true);
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
    this._scratchGfx = null;

    try {
      if (this._aboveContent?.mask) this._aboveContent.mask = null;
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
    try {
      this._aboveContent?.destroy({ children: true });
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
    this._aboveContent = null;

    try {
      this._belowContainer?.destroy({ children: true });
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
    this._belowContainer = null;

    this._sceneBelowBase = null;
    this._sceneBelowCutout = null;
    this._sceneAboveBase = null;
    this._sceneAboveCutout = null;
    this._sceneBelowBaseMask = null;
    this._sceneBelowCutoutMask = null;
    this._sceneAboveBaseMask = null;
    this._sceneAboveCutoutMask = null;

    try {
      this._aboveMaskGfx?.destroy(true);
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
    this._aboveMaskGfx = null;

    try {
      if (this._aboveWeatherRevealRT) this._releaseRT(this._aboveWeatherRevealRT);
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
    this._aboveWeatherRevealRT = null;

    try {
      this._aboveWeatherRevealFilter?.destroy?.();
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
    this._aboveWeatherRevealFilter = null;

    try {
      this._aboveTintIsolationFilter?.destroy?.();
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
    this._aboveTintIsolationFilter = null;

    try {
      this.filters = [];
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
    this._belowOccl = null;
    this._aboveOccl = null;

    this._tokensDirty = false;
    this._lastBelowObjectCoverageMatrix = null;
    this._lastBelowTokenCoverageSignature = null;
    this._lastBelowTileCoverageSignature = null;
    this._lastSceneMaskMatrix = null;
    this._currentCameraMatrix = null;
    this._lastSceneSuppressionOverlaySignature = "";
    this._lastRegionMaskMatrix = null;
    this._weatherOcclusionTilePresence = { key: null, value: false };

    return super._tearDown();
  }

  #destroyEffects() {
    for (const fx of this.particleEffects.values()) {
      try {
        fx.stop?.();
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
      try {
        fx.destroy?.();
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
      try {
        this._destroySceneParticleContainer(fx);
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
    }
    this.particleEffects.clear();

    for (const fx of this._dyingSceneEffects) {
      try {
        fx.stop?.();
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
      try {
        fx.destroy?.();
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
      try {
        this._destroySceneParticleContainer(fx);
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
    }
    this._dyingSceneEffects.clear();
    this.setCompositedSceneParticleSources([]);
    this.stackEntries.clear();
    this._stackRoots.clear();
    this._transientStackRows.clear();
    this._lastKnownOrder.clear();

    for (const entries of this.regionEffects.values()) {
      for (const entry of entries) {
        if (entry?.uid) this._unregisterStackSlot(entry.uid);
        const fx = entry?.fx ?? null;
        const container = entry?.container ?? null;
        const maskSprite = entry?.maskSprite ?? null;

        this._destroyRegionSurfaceEdgeFadeFilter(entry);
        this._destroyParticleBackgroundSurface(fx);

        try {
          fx?.stop?.();
        } catch (err) {
          logger.debug("FXMaster:", err);
        }
        try {
          fx?.destroy?.();
        } catch (err) {
          logger.debug("FXMaster:", err);
        }

        try {
          if (container && maskSprite && container.mask === maskSprite) container.mask = null;
        } catch (err) {
          logger.debug("FXMaster:", err);
        }
        destroyParticleMaskSprite(maskSprite, container);

        try {
          container?.destroy?.({ children: true, texture: false, baseTexture: false });
        } catch (err) {
          logger.debug("FXMaster:", err);
        }
      }
    }
    this.regionEffects.clear();

    try {
      for (const rtPair of this._regionMaskRTs.values()) {
        try {
          this._releaseRT(rtPair.base);
        } catch (err) {
          logger.debug("FXMaster:", err);
        }
        try {
          this._releaseRT(rtPair.cutoutTokens);
        } catch (err) {
          logger.debug("FXMaster:", err);
        }
        try {
          this._releaseRT(rtPair.cutoutTiles);
        } catch (err) {
          logger.debug("FXMaster:", err);
        }
        try {
          this._releaseRT(rtPair.cutoutCombined);
        } catch (err) {
          logger.debug("FXMaster:", err);
        }
      }
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
    this._regionMaskRTs.clear?.();
    this._destroyAllParticleBackgroundTrailStores();
  }

  /**
   * Notify the layer that token silhouettes changed (movement, resize, visibility, etc).
   * - For scene FX: scene manager can use this to refresh cutout RT.
   * - For region FX: cheaply recompose cutout (base - tokens) without rebuilding base.
   */
  notifyTokensChanged() {
    this._tokensDirty = true;
  }

  /**
   * Determine whether any active particle runtime requires shared below-object coverage masks.
   *
   * @returns {{ anyBelowTokens: boolean, anyBelowTiles: boolean }}
   */
  _collectBelowObjectCoverageNeeds() {
    let anyBelowTokens = false;
    let anyBelowTiles = false;

    const inspect = (fx) => {
      if (!fx) return false;
      if (fx.__fxmBelowTokens) anyBelowTokens = true;
      if (fx.__fxmBelowTiles) anyBelowTiles = true;
      return anyBelowTokens && anyBelowTiles;
    };

    try {
      for (const fx of this.particleEffects.values()) {
        if (inspect(fx)) break;
      }

      if (!(anyBelowTokens && anyBelowTiles)) {
        for (const fx of this._dyingSceneEffects) {
          if (inspect(fx)) break;
        }
      }

      if (!(anyBelowTokens && anyBelowTiles)) {
        for (const entries of this.regionEffects.values()) {
          for (const entry of entries ?? []) {
            if (inspect(entry?.fx ?? entry)) break;
          }
          if (anyBelowTokens && anyBelowTiles) break;
        }
      }
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    return { anyBelowTokens, anyBelowTiles };
  }

  /**
   * Refresh shared token and tile coverage masks when camera or live coverage state changes.
   *
   * @returns {void}
   */
  _refreshBelowObjectCoverageForCamera() {
    const { anyBelowTokens, anyBelowTiles } = this._collectBelowObjectCoverageNeeds();
    if (!anyBelowTokens && !anyBelowTiles) {
      this._lastBelowObjectCoverageMatrix = null;
      this._lastBelowTokenCoverageSignature = null;
      this._lastBelowTileCoverageSignature = null;
      return;
    }

    const M = anyBelowTiles ? rawStageMatrix() : this._currentCameraMatrix ?? snappedStageMatrix();
    const worldAtlasCoverage = SceneMaskManager.instance.usesWorldAtlasCoverage?.() === true;
    const cameraMoved =
      !worldAtlasCoverage &&
      (!this._lastBelowObjectCoverageMatrix || cameraMatrixChanged(M, this._lastBelowObjectCoverageMatrix));
    let tokenMotionChanged = false;
    if (anyBelowTokens) {
      const tokenSignature = buildBelowTokenMaskCoverageSignature();
      tokenMotionChanged = tokenSignature !== (this._lastBelowTokenCoverageSignature ?? null);
      this._lastBelowTokenCoverageSignature = tokenSignature;
    } else {
      this._lastBelowTokenCoverageSignature = null;
    }

    let tileCoverageChanged = false;
    if (anyBelowTiles) {
      const tileSignature = buildBelowTileMaskCoverageSignature();
      tileCoverageChanged = tileSignature !== (this._lastBelowTileCoverageSignature ?? null);
      this._lastBelowTileCoverageSignature = tileSignature;
    } else {
      this._lastBelowTileCoverageSignature = null;
    }

    if (!cameraMoved && !tokenMotionChanged && !tileCoverageChanged) return;

    try {
      SceneMaskManager.instance.refreshTokensSync?.({ force: tokenMotionChanged || tileCoverageChanged });
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    this._tokensDirty = true;
    this._lastBelowObjectCoverageMatrix = M ? { a: M.a, b: M.b, c: M.c, d: M.d, tx: M.tx, ty: M.ty } : null;
  }

  /**
   * Recompute whether any region-scoped particle effects require below-tokens or below-tiles cutouts.
   *
   * @private
   */
  _updateRegionBelowTokensNeeded() {
    let anyBelowTokens = false;
    let anyBelowTiles = false;
    try {
      for (const entries of this.regionEffects.values()) {
        for (const entry of entries ?? []) {
          const fx = entry?.fx ?? entry;
          if (fx?.__fxmBelowTokens) anyBelowTokens = true;
          if (fx?.__fxmBelowTiles) anyBelowTiles = true;
          if (anyBelowTokens && anyBelowTiles) break;
        }
        if (anyBelowTokens && anyBelowTiles) break;
      }
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    const changedTokens = this._regionBelowTokensNeeded !== anyBelowTokens;
    const changedTiles = this._regionBelowTilesNeeded !== anyBelowTiles;
    this._regionBelowTokensNeeded = anyBelowTokens;
    this._regionBelowTilesNeeded = anyBelowTiles;

    if (!changedTokens && !changedTiles) return;

    try {
      SceneMaskManager.instance.setBelowTokensNeeded?.("particles", anyBelowTokens, "regions");
      SceneMaskManager.instance.setBelowTilesNeeded?.("particles", anyBelowTiles, "regions");
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
  }
  /**
   * Return the scene particle bucket that should own a scene runtime container.
   *
   * @param {string} layerLevel
   * @param {boolean} belowTokens
   * @returns {PIXI.Container|null}
   */
  _getSceneParticleBucket(layerLevel = "belowDarkness", belowTokens = false) {
    if (layerLevel === "aboveDarkness") return belowTokens ? this._sceneAboveCutout : this._sceneAboveBase;
    return belowTokens ? this._sceneBelowCutout : this._sceneBelowBase;
  }

  /**
   * Apply the current scene mask bundle to a dedicated scene runtime container.
   *
   * @param {PIXI.Container|null} container
   * @param {PIXI.Sprite|null} sprite
   * @param {{ belowTokens?: boolean, belowTiles?: boolean, maskTextureOverride?: PIXI.Texture|PIXI.RenderTexture|false|null }} [entry]
   * @returns {void}
   */
  _applySceneMaskToContainer(container, sprite, entry = {}) {
    if (!container || container.destroyed || !sprite || sprite.destroyed) return;
    suppressVisibleMaskPaint(sprite);

    const belowTokens = !!entry?.belowTokens;
    const belowTiles = !!entry?.belowTiles;
    const texture =
      entry?.maskTextureOverride ?? chooseParticleMaskTexture(this._sceneMaskBundle, belowTokens, belowTiles);

    if (!isUsableParticleMaskTexture(texture)) {
      disableParticleMask(container, sprite);
      return;
    }

    try {
      sprite.texture = texture;
      sprite._fxmMaskEnabled = true;
    } catch (err) {
      logger.debug("FXMaster:", err);
      disableParticleMask(container, sprite);
      return;
    }

    const { cssW, cssH } = getCssViewportMetrics();
    try {
      sprite.width = cssW;
      sprite.height = cssH;
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    try {
      applyMaskSpriteTransform(container, sprite);
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    if (container.mask !== sprite) {
      try {
        container.mask = sprite;
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
    }
  }

  /**
   * Ensure a reusable world-space scene clip mask exists for plain scene-particle stack rendering.
   *
   * This avoids relying on the compositor's screen-space base scene mask for the simplest scene-particle case, which can visibly drift against live camera motion while panning.
   *
   * @param {PIXI.Container|null} container
   * @returns {PIXI.Graphics|null}
   */
  _ensureSceneStackClipMask(container) {
    if (!container || container.destroyed) return null;

    let gfx = container.__fxmStackSceneClipMask ?? null;
    if (!gfx || gfx.destroyed) {
      gfx = new PIXI.Graphics();
      gfx.name = "fxmSceneParticleStackClipMask";
      gfx.eventMode = "none";
      /**
       * Keep the graphics visible so PIXI can evaluate them as a mask target when the direct scene-particle clip path is active, but leave them non-renderable outside that render call so the scene-rect fill cannot leak into parent-band renders during soft transitions.
       */
      gfx.visible = true;
      gfx.renderable = false;
      container.__fxmStackSceneClipMask = gfx;
    }

    const host = !container.parent?.destroyed ? container.parent : this;
    if (!host || host.destroyed) return null;

    if (gfx.parent !== host) {
      try {
        gfx.parent?.removeChild?.(gfx);
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
      try {
        host.addChildAt(gfx, 0);
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
    }

    const rect = canvas?.dimensions?.sceneRect ?? null;
    if (!rect) return gfx;

    const x = Number(rect.x) || 0;
    const y = Number(rect.y) || 0;
    const w = Math.max(0, Number(rect.width) || 0);
    const h = Math.max(0, Number(rect.height) || 0);
    const key = `${x}:${y}:${w}:${h}`;

    if (gfx.__fxmSceneRectKey !== key) {
      try {
        gfx.clear();
        gfx.beginFill(0xffffff, 1);
        gfx.drawRect(x, y, w, h);
        gfx.endFill();
        gfx.__fxmSceneRectKey = key;
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
    }

    return gfx;
  }

  /**
   * Ensure a dedicated wrapper container exists for a scene-level particle runtime.
   *
   * @param {PIXI.DisplayObject|null} fx
   * @param {{ layerLevel?: string, belowTokens?: boolean, belowTiles?: boolean, zIndex?: number }} [options]
   * @returns {{ container: PIXI.Container|null, maskSprite: PIXI.Sprite|null }}
   */
  _ensureSceneParticleContainer(
    fx,
    { layerLevel = "belowDarkness", belowTokens = false, belowTiles = false, zIndex = 0 } = {},
  ) {
    if (!fx || fx.destroyed) return { container: null, maskSprite: null };

    this._ensureSceneContainers();
    const bucket = this._getSceneParticleBucket(layerLevel, belowTokens);
    if (!bucket || bucket.destroyed) return { container: null, maskSprite: null };

    let container = fx.__fxmSceneContainer ?? null;
    if (!container || container.destroyed) {
      container = new PIXI.Container();
      container.name = "fxmSceneParticleRuntime";
      container.eventMode = "none";
      container.sortableChildren = false;
      fx.__fxmSceneContainer = container;
    }

    let maskSprite = fx.__fxmSceneMaskSprite ?? null;
    if (!maskSprite || maskSprite.destroyed) {
      maskSprite = new PIXI.Sprite(PIXI.Texture.EMPTY);
      maskSprite.name = "fxmSceneParticleMaskSprite";
      maskSprite.eventMode = "none";
      maskSprite.renderable = false;
      maskSprite._fxmMaskEnabled = false;
      fx.__fxmSceneMaskSprite = maskSprite;
    }

    suppressVisibleMaskPaint(maskSprite);

    if (maskSprite.parent !== container) {
      try {
        maskSprite.parent?.removeChild?.(maskSprite);
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
      try {
        container.addChildAt(maskSprite, 0);
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
    } else {
      try {
        if (container.getChildIndex(maskSprite) !== 0) container.setChildIndex(maskSprite, 0);
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
    }

    if (fx.parent !== container) {
      try {
        fx.parent?.removeChild?.(fx);
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
      try {
        container.addChild(fx);
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
    }

    if (container.parent !== bucket) {
      try {
        container.parent?.removeChild?.(container);
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
      try {
        bucket.addChild(container);
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
    }

    try {
      container.zIndex = Number.isFinite(zIndex) ? zIndex : 0;
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    this._applySceneMaskToContainer(container, maskSprite, { belowTokens, belowTiles });
    this._syncSceneParticleTintIsolation(fx, container, layerLevel);
    return { container, maskSprite };
  }

  /**
   * Destroy the wrapper container used by a scene-level particle runtime.
   *
   * @param {PIXI.DisplayObject|null} fx
   * @param {{ destroyFx?: boolean }} [options]
   * @returns {void}
   */
  _destroySceneParticleContainer(fx, { destroyFx = false } = {}) {
    if (!fx) return;

    this._destroyParticleBackgroundSurface(fx);

    const container = fx.__fxmSceneContainer ?? null;
    const maskSprite = fx.__fxmSceneMaskSprite ?? null;

    this._clearSceneParticleTintIsolation(container);

    try {
      if (container && maskSprite && container.mask === maskSprite) container.mask = null;
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    if (!destroyFx) {
      try {
        if (fx.parent === container) container.removeChild(fx);
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
    }

    const stackSceneClipMask = container?.__fxmStackSceneClipMask ?? null;

    try {
      maskSprite?.parent?.removeChild?.(maskSprite);
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    try {
      stackSceneClipMask?.parent?.removeChild?.(stackSceneClipMask);
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    try {
      container?.parent?.removeChild?.(container);
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    destroyParticleMaskSprite(maskSprite, container);

    try {
      if (stackSceneClipMask && !stackSceneClipMask.destroyed) stackSceneClipMask.destroy({ children: true });
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    try {
      if (container && !container.destroyed)
        container.destroy({ children: destroyFx, texture: false, baseTexture: false });
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    try {
      delete fx.__fxmSceneMaskSprite;
      delete fx.__fxmSceneContainer;
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
  }

  /**
   * Scene manager calls this after it refreshes SceneMaskManager RTs for particles.
   *
   * @param {{ base?: PIXI.RenderTexture|null, cutoutTokens?: PIXI.RenderTexture|null, cutoutTiles?: PIXI.RenderTexture|null, cutoutCombined?: PIXI.RenderTexture|null }} masks
   */
  setSceneMaskTextures({ base = null, cutoutTokens = null, cutoutTiles = null, cutoutCombined = null } = {}) {
    const baseValid = isUsableParticleMaskTexture(base);
    const cutoutTokensValid = isUsableParticleMaskTexture(cutoutTokens);
    const cutoutTilesValid = isUsableParticleMaskTexture(cutoutTiles);
    const cutoutCombinedValid = isUsableParticleMaskTexture(cutoutCombined);

    this._sceneMaskBundle = {
      base: baseValid ? base : null,
      cutoutTokens: cutoutTokensValid ? cutoutTokens : null,
      cutoutTiles: cutoutTilesValid ? cutoutTiles : null,
      cutoutCombined: cutoutCombinedValid ? cutoutCombined : null,
    };

    const apply = (container, sprite, texture) => {
      if (!sprite || sprite.destroyed) return;
      suppressVisibleMaskPaint(sprite);
      if (!isUsableParticleMaskTexture(texture)) {
        disableParticleMask(container, sprite);
        return;
      }
      try {
        sprite.texture = texture;
        sprite._fxmMaskEnabled = true;
      } catch (err) {
        logger.debug("FXMaster:", err);
        disableParticleMask(container, sprite);
      }
    };

    apply(this._sceneBelowBase, this._sceneBelowBaseMask, this._sceneMaskBundle.base);
    apply(this._sceneAboveBase, this._sceneAboveBaseMask, this._sceneMaskBundle.base);
    apply(this._sceneBelowCutout, this._sceneBelowCutoutMask, this._sceneMaskBundle.cutoutTokens);
    apply(this._sceneAboveCutout, this._sceneAboveCutoutMask, this._sceneMaskBundle.cutoutTokens);

    const updateSceneRuntimeMask = (fx) => {
      if (!fx || fx.destroyed) return;
      const container = fx.__fxmSceneContainer ?? null;
      const maskSprite = fx.__fxmSceneMaskSprite ?? null;
      if (!container || container.destroyed || !maskSprite || maskSprite.destroyed) return;
      this._applySceneMaskToContainer(container, maskSprite, {
        belowTokens: !!fx.__fxmBelowTokens,
        belowTiles: !!fx.__fxmBelowTiles,
        belowForeground: !!fx.__fxmBelowForeground,
      });
    };

    for (const fx of this.particleEffects.values()) updateSceneRuntimeMask(fx);
    for (const fx of this._dyingSceneEffects) updateSceneRuntimeMask(fx);
  }

  /**
   * Apply the appropriate scene mask texture to a compositor bucket for one particle runtime.
   *
   * @param {PIXI.Container|null} root
   * @param {{ belowTokens?: boolean, belowTiles?: boolean, maskTextureOverride?: PIXI.Texture|PIXI.RenderTexture|false|null }} [entry]
   * @returns {void}
   */
  _applySceneMaskForEntry(root, entry = {}) {
    const container = entry?.container ?? null;
    const sprite = entry?.maskSprite ?? null;
    if (container && sprite) {
      this._applySceneMaskToContainer(container, sprite, entry);
      return;
    }

    const belowTokens = !!entry?.belowTokens;
    const belowTiles = !!entry?.belowTiles;
    const texture =
      entry?.maskTextureOverride ?? chooseParticleMaskTexture(this._sceneMaskBundle, belowTokens, belowTiles);
    const bucketSprite =
      root === this._sceneBelowBase
        ? this._sceneBelowBaseMask
        : root === this._sceneBelowCutout
        ? this._sceneBelowCutoutMask
        : root === this._sceneAboveBase
        ? this._sceneAboveBaseMask
        : root === this._sceneAboveCutout
        ? this._sceneAboveCutoutMask
        : null;
    if (!bucketSprite || bucketSprite.destroyed) return;
    suppressVisibleMaskPaint(bucketSprite);
    if (!isUsableParticleMaskTexture(texture)) {
      disableParticleMask(root, bucketSprite);
      return;
    }
    try {
      bucketSprite.texture = texture;
      bucketSprite._fxmMaskEnabled = true;
    } catch (err) {
      logger.debug("FXMaster:", err);
      disableParticleMask(root, bucketSprite);
    }
  }

  /**
   * Apply the appropriate region mask texture to a compositor entry.
   *
   * @param {object|null} entry
   * @returns {void}
   */
  _applyRegionMaskForEntry(entry) {
    const sprite = entry?.maskSprite;
    if (!sprite || sprite.destroyed) return;
    const texture = chooseParticleMaskTexture(entry?.maskBundle, !!entry?.belowTokens, !!entry?.belowTiles);
    sprite.texture = safeMaskTexture(texture);
  }

  #updateSceneParticlesSuppressionForCamera(M = this._currentCameraMatrix ?? snappedStageMatrix()) {
    const cameraChanged = cameraMatrixChanged(M, this._lastSceneMaskMatrix);
    if (cameraChanged) {
      markSceneParticleSuppressionCompositorInteraction(this, { reason: "camera" });
    }

    let hasSuppression = sceneParticlesHaveRelevantSuppressionRegions(this);
    /** Foundry's primary/perception tickers run before this low-priority FXMaster ticker. */
    const overlayState = hasSuppression
      ? getCanvasLiveLevelSurfaceState(canvas?.scene ?? null, {
          presynced: true,
          includeTransientFades: false,
        })
      : null;
    const overlaySignature = overlayState?.key ?? "";
    const overlayChanged = hasSuppression && overlaySignature !== this._lastSceneSuppressionOverlaySignature;

    if (overlayChanged) {
      markSceneParticleSuppressionCompositorInteraction(this, { reason: "overlay" });
      hasSuppression = sceneParticlesHaveRelevantSuppressionRegions(this);
    }

    const maskingChanged = !!hasSuppression !== (this._lastSceneSuppressionNeedsMasking === true);
    const worldAtlasMasks = SceneMaskManager.instance.usesWorldAtlas?.("particles") === true;

    if (!hasSuppression) this._lastSceneSuppressionOverlaySignature = "";
    if (!cameraChanged && !overlayChanged && !maskingChanged) return;

    this._lastSceneSuppressionNeedsMasking = !!hasSuppression;
    this._lastSceneSuppressionOverlaySignature = overlaySignature;
    if (cameraChanged) {
      this._lastSceneMaskMatrix = { a: M.a, b: M.b, c: M.c, d: M.d, tx: M.tx, ty: M.ty };
    }

    if (cameraChanged && worldAtlasMasks && !overlayChanged && !maskingChanged) return;

    try {
      this._coalescedSceneSuppressionRefresh?.cancel?.();
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    try {
      refreshSceneParticlesSuppressionMasks({ sync: true, presyncedLiveLevelState: true });
    } catch (err) {
      logger?.error?.(err);
    }
  }

  /**
   * Build a signature describing which scene-scoped particle effects are currently active at the supplied darkness level.
   *
   * @param {number} darknessLevel
   * @returns {string}
   */
  _buildSceneDarknessActivationSignature(darknessLevel = getSceneDarknessLevel()) {
    const flags = canvas?.scene?.getFlag(packageId, "effects") ?? {};
    return Object.entries(flags)
      .filter(([, info]) => !!info && typeof info === "object")
      .map(([id, info]) => {
        const options = normalizeSceneLevelSelection(
          info?.options && typeof info.options === "object" ? { ...info.options } : {},
          canvas?.scene,
        );
        const levelsKey = Array.isArray(options?.levels) ? options.levels.map(String).sort().join(",") : "*";
        const active =
          isEffectActiveForSceneDarkness(options, darknessLevel) &&
          isEffectActiveForCurrentOrVisibleCanvasLevel(options, canvas?.scene);
        return `${id}:${active ? 1 : 0}:${levelsKey}`;
      })
      .sort()
      .join("|");
  }

  /**
   * Build a signature describing which region-scoped particle effects for a single region are active at the supplied darkness level.
   *
   * @param {PlaceableObject} placeable
   * @param {number} darknessLevel
   * @returns {string}
   */
  _buildRegionDarknessActivationSignature(placeable, darknessLevel = getSceneDarknessLevel()) {
    const regionId = placeable?.id ?? "";
    const behaviors = normalizeBehaviorDocs(placeable?.document?.behaviors).filter(
      (behavior) => behavior.type === TYPE && !behavior.disabled,
    );

    const parts = [];
    for (const behavior of behaviors) {
      const defs = getRegionParticleEffectDefinitions(behavior) ?? {};
      for (const [type, params] of Object.entries(defs)) {
        if (!isEffectActiveForSceneDarkness(params?.options, darknessLevel)) continue;
        parts.push(`${regionId}:${behavior.id}:${type}:1`);
      }
    }

    return parts.sort().join("|");
  }

  async drawParticleEffects({ soft = false } = {}) {
    if (!canvas.scene) return;

    this._ensureSceneContainers();

    const cur = this.particleEffects;
    const darknessLevel = getSceneDarknessLevel();
    let flags = canvas.scene.getFlag(packageId, "effects") ?? {};
    const activeFlags = Object.fromEntries(
      Object.entries(flags).flatMap(([id, info]) => {
        if (!info || typeof info !== "object") return [];
        const options = normalizeSceneLevelSelection(
          info.options && typeof info.options === "object" ? { ...info.options } : {},
          canvas?.scene,
        );
        if (!isEffectActiveForSceneDarkness(options, darknessLevel)) return [];
        if (!isEffectActiveForCurrentOrVisibleCanvasLevel(options, canvas?.scene)) return [];
        return [[id, { ...info, options }]];
      }),
    );

    const removalPromises = [];
    for (const [id, fx] of cur) {
      if (!(id in activeFlags)) {
        const runtimeUid = buildSceneEffectUid("particle", id);
        const useSoftFade = particleEffectUsesSoftFade(fx?.constructor, soft);
        const transientUid = useSoftFade && fx?.fadeOut ? this._promoteSceneRuntimeToTransient(runtimeUid) : null;
        if (!transientUid) this._unregisterStackSlot(runtimeUid);

        this._dyingSceneEffects.add(fx);
        cur.delete(id);

        removalPromises.push(
          (async () => {
            try {
              if (useSoftFade && fx.fadeOut) await fx.fadeOut({ timeout: particleEffectFadeDurationMs(fx.constructor) });
              else fx.stop?.();
            } catch (err) {
              logger.debug("FXMaster:", err);
            }
            try {
              fx.parent?.removeChild?.(fx);
            } catch (err) {
              logger.debug("FXMaster:", err);
            }
            try {
              fx.destroy?.();
            } catch (err) {
              logger.debug("FXMaster:", err);
            }
            try {
              this._destroySceneParticleContainer(fx);
            } catch (err) {
              logger.debug("FXMaster:", err);
            }
            this._clearTransientSceneRow(transientUid);
            this._dyingSceneEffects.delete(fx);
          })(),
        );
      }
    }

    flags = canvas.scene?.getFlag(packageId, "effects") ?? {};

    let zIndex = 0;
    for (const [id, { type, options: flagOptions, state: flagState }] of Object.entries(activeFlags)) {
      if (!(type in CONFIG.fxmaster.particleEffects)) {
        logger.warn(game.i18n.format("FXMASTER.Particles.TypeErrors.TypeUnknown", { id, type: flags[id]?.type }));
        continue;
      }

      const options = wrapStoredParticleOptions(flagOptions);
      options.__fxmParticleContext = {
        scope: "scene",
        sceneId: canvas?.scene?.id ?? null,
        effectId: id,
        type,
      };
      const EffectClass = CONFIG.fxmaster.particleEffects[type];
      const useSoftFade = particleEffectUsesSoftFade(EffectClass, soft);
      const defaultBlend = EffectClass?.defaultConfig?.blendMode ?? PIXI.BLEND_MODES.NORMAL;
      const existing = cur.get(id);

      const belowTokens = particleBelowTokensEnabled(options?.belowTokens);
      const belowTiles = particleBelowTilesEnabled(options?.belowTiles);
      const belowForeground = particleBelowForegroundEnabled(options?.belowForeground);
      const runtimeUid = buildSceneEffectUid("particle", id);
      const backgroundState = flagState && typeof flagState === "object" ? flagState : {};

      const addToLayer = (fx) => {
        const { layerLevel = "belowDarkness" } = EffectClass.defaultConfig || {};
        fx.__fxmBelowTokens = belowTokens;
        fx.__fxmBelowTiles = belowTiles;
        fx.__fxmBelowForeground = belowForeground;
        fx.__fxmLevels = options?.levels;
        fx.__fxmOptions = options;
        fx.__fxmBackgroundState = backgroundState;
        fx.__fxmBackgroundUid = runtimeUid;
        this._ensureSceneParticleContainer(fx, { layerLevel, belowTokens, belowTiles, zIndex: fx.zIndex ?? zIndex });
      };

      const registerRuntime = (fx) => {
        const { layerLevel = "belowDarkness" } = EffectClass.defaultConfig || {};
        const { container, maskSprite } = this._ensureSceneParticleContainer(fx, {
          layerLevel,
          belowTokens,
          belowTiles,
          zIndex: fx.zIndex ?? zIndex,
        });
        const root = layerLevel === "aboveDarkness" ? this._aboveContent : this._belowContainer;
        const slot = container ?? fx;
        const backgroundSurface = this._syncParticleBackgroundSurface(fx, container);
        this._registerStackSlot(runtimeUid, root ?? slot, slot, {
          effectId: id,
          scope: "scene",
          fx,
          layerLevel,
          belowTokens,
          belowTiles,
          belowForeground,
          options,
          levels: options?.levels,
          container,
          maskSprite,
          backgroundSurface,
        });
      };

      if (existing) {
        const XFADE_MS = particleEffectFadeDurationMs(EffectClass);
        try {
          existing.zIndex = zIndex++;
        } catch (err) {
          logger.debug("FXMaster:", err);
        }
        try {
          existing.blendMode = defaultBlend;
        } catch (err) {
          logger.debug("FXMaster:", err);
        }

        existing.__fxmBelowTokens = belowTokens;
        existing.__fxmBelowTiles = belowTiles;
        existing.__fxmBelowForeground = belowForeground;
        existing.__fxmLevels = options?.levels;
        existing.__fxmOptions = options;
        existing.__fxmBackgroundState = backgroundState;
        existing.__fxmBackgroundUid = runtimeUid;

        const prev = existing._fxmOptsCache ?? {};
        const diff = foundry.utils.diffObject(prev, options);
        const changed = !foundry.utils.isEmpty(diff);

        if (!changed) {
          try {
            existing.play?.({ skipFading: soft });
          } catch (err) {
            logger.debug("FXMaster:", err);
          }
          registerRuntime(existing);
          continue;
        }

        if (particleOptionsChangedOnlyRuntimeRoutingOrBackground(prev, options)) {
          try {
            existing._fxmOptsCache = foundry.utils.deepClone(options);
          } catch (_err) {
            existing._fxmOptsCache = options;
          }
          try {
            existing.play?.({ skipFading: true });
          } catch (err) {
            logger.debug("FXMaster:", err);
          }
          registerRuntime(existing);
          continue;
        }

        if (particleOptionsCanUpdateInPlace(EffectClass, existing, prev, options)) {
          const updated = await updateParticleOptionsInPlace(existing, options, prev);
          if (updated) {
            try {
              existing._fxmOptsCache = foundry.utils.deepClone(options);
            } catch (_err) {
              existing._fxmOptsCache = options;
            }
            try {
              existing.play?.({ skipFading: true });
            } catch (err) {
              logger.debug("FXMaster:", err);
            }
            registerRuntime(existing);
            continue;
          }
        }

        if (soft && EffectClass?.softOptionTransition !== false) {
          const transientUid = this._promoteSceneRuntimeToTransient(runtimeUid);
          const ec = new EffectClass(options);
          ec.zIndex = existing.zIndex ?? zIndex - 1;
          ec.blendMode = defaultBlend;
          ec._fxmOptsCache = foundry.utils.deepClone(options);
          ec.alpha = 0;
          addToLayer(ec);
          cur.set(id, ec);
          registerRuntime(ec);
          ec.play({ prewarm: true });

          this._dyingSceneEffects.add(existing);

          removalPromises.push(
            (async () => {
              try {
                await Promise.all([existing?.fadeOut?.({ timeout: XFADE_MS }), ec?.fadeIn?.({ timeout: XFADE_MS })]);
              } catch (err) {
                logger.debug("FXMaster:", err);
              }
              try {
                existing.parent?.removeChild?.(existing);
              } catch (err) {
                logger.debug("FXMaster:", err);
              }
              try {
                existing.destroy?.();
              } catch (err) {
                logger.debug("FXMaster:", err);
              }
              try {
                this._destroySceneParticleContainer(existing);
              } catch (err) {
                logger.debug("FXMaster:", err);
              }
              this._clearTransientSceneRow(transientUid);
              this._dyingSceneEffects.delete(existing);
            })(),
          );
          continue;
        }

        try {
          existing.stop?.();
        } catch (err) {
          logger.debug("FXMaster:", err);
        }
        try {
          existing.parent?.removeChild?.(existing);
        } catch (err) {
          logger.debug("FXMaster:", err);
        }
        try {
          existing.destroy?.();
        } catch (err) {
          logger.debug("FXMaster:", err);
        }
        try {
          this._destroySceneParticleContainer(existing);
        } catch (err) {
          logger.debug("FXMaster:", err);
        }
        cur.delete(id);

        const ec = new EffectClass(options);
        ec.zIndex = existing.zIndex ?? zIndex - 1;
        ec.blendMode = defaultBlend;
        ec._fxmOptsCache = foundry.utils.deepClone(options);
        if (useSoftFade && typeof ec.fadeIn === "function") ec.alpha = 0;
        addToLayer(ec);
        cur.set(id, ec);
        registerRuntime(ec);
        ec.play({ prewarm: particleEffectPrewarmForSoftFade(EffectClass, useSoftFade) });
        if (useSoftFade && typeof ec.fadeIn === "function") {
          void ec.fadeIn({ timeout: particleEffectFadeDurationMs(EffectClass) }).catch((err) => logger.debug("FXMaster:", err));
        }
        continue;
      }

      const ec = new EffectClass(options);
      ec.zIndex = zIndex++;
      try {
        ec.blendMode = defaultBlend;
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
      ec._fxmOptsCache = foundry.utils.deepClone(options);
      if (useSoftFade && typeof ec.fadeIn === "function") ec.alpha = 0;
      addToLayer(ec);
      cur.set(id, ec);
      registerRuntime(ec);
      ec.play({ prewarm: particleEffectPrewarmForSoftFade(EffectClass, useSoftFade) });
      if (useSoftFade && typeof ec.fadeIn === "function") {
        void ec.fadeIn({ timeout: particleEffectFadeDurationMs(EffectClass) }).catch((err) => logger.debug("FXMaster:", err));
      }
    }

    try {
      refreshSceneParticlesSuppressionMasks({ sync: true });
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    this._lastSceneDarknessSignature = this._buildSceneDarknessActivationSignature(darknessLevel);
    this._updateOcclusionGates();
    this._updateAboveWeatherRevealSuppression();
    this._updateRegionBelowTokensNeeded();
    this._syncSceneStackOrderCache();
    this._syncLiveSceneParticleStackOrder();

    if (removalPromises.length) {
      try {
        await Promise.all(removalPromises);
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
    }
  }

  /**
   * Draw region-scoped particle effects for a region placeable.
   *
   * An authoritative behavior snapshot may be supplied during behavior CRUD so effect selection does not depend on a stale placeable behavior collection.
   *
   * @param {PlaceableObject} placeable
   * @param {{ soft?: boolean, behaviorDocs?: Iterable<foundry.documents.RegionBehavior>|foundry.documents.RegionBehavior[]|null }} [options]
   * @returns {Promise<void>}
   */
  async drawRegionParticleEffects(placeable, { soft = false, behaviorDocs = null } = {}) {
    const regionId = placeable.id;
    this._ensureSceneContainers();

    if (!regionDocumentCanApplyInCurrentView(placeable?.document ?? null, canvas?.scene ?? null)) {
      this.destroyRegionParticleEffects(regionId);
      return;
    }

    const old = this.regionEffects.get(regionId) || [];
    await Promise.all(
      old.map(async (entry) => {
        if (entry?.uid) this._unregisterStackSlot(entry.uid);
        const fx = entry?.fx ?? entry;
        this._destroyRegionSurfaceEdgeFadeFilter(entry);
        this._destroyParticleBackgroundSurface(fx);
        try {
          fx?.stop?.();
        } catch (err) {
          logger.debug("FXMaster:", err);
        }
        try {
          fx?.destroy?.();
        } catch (err) {
          logger.debug("FXMaster:", err);
        }
        destroyParticleMaskSprite(entry?.maskSprite, entry?.container);

        try {
          entry?.container?.destroy?.({ children: true, texture: false, baseTexture: false });
        } catch (err) {
          logger.debug("FXMaster:", err);
        }
      }),
    );
    this.regionEffects.set(regionId, []);

    const behaviors = normalizeBehaviorDocs(behaviorDocs ?? placeable?.document?.behaviors).filter(
      (behavior) => behavior.type === TYPE && !behavior.disabled,
    );
    if (!behaviors.length) {
      this.destroyRegionParticleEffects(regionId);
      return;
    }

    const darknessLevel = getSceneDarknessLevel();
    const activeParticleSpecs = [];
    const activeBehaviorIds = new Set();
    const activeBehaviors = [];
    let anyWantsBelowTokens = false;
    let anyWantsBelowTiles = false;

    for (const behavior of behaviors) {
      const defs = getRegionParticleEffectDefinitions(behavior) ?? {};
      for (const [type, params] of Object.entries(defs)) {
        if (!isEffectActiveForSceneDarkness(params?.options, darknessLevel)) continue;
        const EffectClass = CONFIG.fxmaster.particleEffects[type];
        if (!EffectClass) continue;
        const belowTokens = particleBelowTokensEnabled(params?.belowTokens ?? params?.options?.belowTokens);
        const belowTiles = particleBelowTilesEnabled(params?.belowTiles ?? params?.options?.belowTiles);
        const belowForeground = particleBelowForegroundEnabled(
          params?.belowForeground ?? params?.options?.belowForeground,
        );
        activeParticleSpecs.push({ behavior, type, params, EffectClass, belowTokens, belowTiles, belowForeground });
        if (!activeBehaviorIds.has(behavior.id)) {
          activeBehaviorIds.add(behavior.id);
          activeBehaviors.push(behavior);
        }
        if (belowTokens) anyWantsBelowTokens = true;
        if (belowTiles) anyWantsBelowTiles = true;
      }
    }

    if (!activeParticleSpecs.length) {
      this.destroyRegionParticleEffects(regionId);
      return;
    }

    const edgeFadePercent = this._getRegionEdgeFadePercent(placeable, activeBehaviors);
    const edgeFadeCtx = this._buildPerParticleEdgeFadeContext(placeable, edgeFadePercent);
    const surfaceEdgeFadeCapable = ({ EffectClass, params }) => {
      if (EffectClass?.usesRegionSurfaceEdgeFade === true) return true;
      try {
        return !!EffectClass?.backgroundSurface && particleBackgroundEnabled(params?.options ?? {});
      } catch (err) {
        logger.debug("FXMaster:", err);
        return false;
      }
    };
    const needsSurfaceEdgeFade = edgeFadePercent > 0 && activeParticleSpecs.some(surfaceEdgeFadeCapable);
    const surfaceEdgeFadeMask = needsSurfaceEdgeFade ? getRegionSoftMaskData(placeable, edgeFadePercent) : null;
    const regionParticleContext = buildRegionParticleContext(placeable);

    let shared = this._regionMaskRTs.get(regionId);
    if (!shared) {
      shared = { base: null, cutoutTokens: null, cutoutTiles: null, cutoutCombined: null };
      this._regionMaskRTs.set(regionId, shared);
    }

    const oldBase = shared.base;
    const oldCutoutTokens = shared.cutoutTokens;
    const oldCutoutTiles = shared.cutoutTiles;
    const oldCutoutCombined = shared.cutoutCombined;

    const { cssW, cssH } = getCssViewportMetrics();
    const regionMaskResolution = regionMaskResolutionForEdgeSync(
      placeable,
      `${packageId}.suppressSceneParticles`,
      cssW,
      cssH,
    );
    shared.base = buildRegionMaskRT(placeable, {
      rtPool: this._rtPool,
      resolution: regionMaskResolution,
      reuseRT: oldBase,
    });
    shared.cutoutTokens = null;
    shared.cutoutTiles = null;
    shared.cutoutCombined = null;

    if (oldBase && oldBase !== shared.base) {
      try {
        this._releaseRT(oldBase);
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
    }
    for (const rt of [oldCutoutTokens, oldCutoutTiles, oldCutoutCombined]) {
      if (!rt) continue;
      try {
        this._releaseRT(rt);
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
    }

    const VW = Math.max(1, Number(cssW) || 1);
    const VH = Math.max(1, Number(cssH) || 1);

    let sceneMaskBundle = null;
    if (anyWantsBelowTokens || anyWantsBelowTiles) {
      try {
        SceneMaskManager.instance.setBelowTokensNeeded?.("particles", anyWantsBelowTokens, "regions");
        SceneMaskManager.instance.setBelowTilesNeeded?.("particles", anyWantsBelowTiles, "regions");
        SceneMaskManager.instance.refreshTokensSync?.();
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
      sceneMaskBundle = SceneMaskManager.instance.getMasks?.("particles") ?? {};
    }
    const tokensRT = sceneMaskBundle?.tokens ?? null;
    const tilesRT = sceneMaskBundle?.tiles ?? null;

    for (const {
      behavior,
      type,
      params,
      EffectClass,
      belowTokens,
      belowTiles,
      belowForeground,
    } of activeParticleSpecs) {
      const { layerLevel = "belowDarkness" } = EffectClass?.defaultConfig || {};
      const defaultBM = EffectClass?.defaultConfig?.blendMode ?? PIXI.BLEND_MODES.NORMAL;
      const useSoftFade = particleEffectUsesSoftFade(EffectClass, soft);

      const effectOptions = wrapStoredParticleOptions(params?.options ?? {});
      const scopedParticleContext = regionParticleContext
        ? { ...regionParticleContext, regionId, behaviorId: behavior?.id ?? null }
        : null;
      if (scopedParticleContext) effectOptions.__fxmParticleContext = scopedParticleContext;
      const uid = buildRegionEffectUid("particle", regionId, behavior.id, type);
      const surfaceFadeCapable = surfaceEdgeFadeCapable({ EffectClass, params });
      const useSurfaceEdgeFade = surfaceFadeCapable && !!surfaceEdgeFadeMask;

      const container = new PIXI.Container();
      container.sortableChildren = true;
      container.eventMode = "none";

      const spr = new PIXI.Sprite(safeMaskTexture(null));
      spr.name = "fxmRegionMaskSprite";
      spr.renderable = false;
      spr.width = VW;
      spr.height = VH;
      container.addChild(spr);

      const fx = new EffectClass(effectOptions);
      if (useSoftFade && typeof fx.fadeIn === "function") fx.alpha = 0;
      if (scopedParticleContext) fx.__fxmParticleContext = scopedParticleContext;
      fx.__fxmOptions = effectOptions;
      fx.__fxmBackgroundState = params?.state && typeof params.state === "object" ? params.state : {};
      fx.__fxmBackgroundUid = uid;
      try {
        fx.blendMode = defaultBM;
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
      container.addChild(fx);

      if (layerLevel === "aboveDarkness") this._aboveContent.addChild(container);
      else this._belowContainer.addChild(container);

      if (!shared.base)
        shared.base = buildRegionMaskRT(placeable, { rtPool: this._rtPool, resolution: regionMaskResolution });

      if (belowTokens || belowTiles) {
        if (belowTokens && !shared.cutoutTokens) {
          const outRT = this._acquireRT(shared.base.width, shared.base.height, shared.base.resolution || 1);
          shared.cutoutTokens = tokensRT
            ? composeMaskMinusTokensRT(shared.base, tokensRT, { outRT })
            : composeMaskMinusTokens(shared.base, { outRT });
        }
        if (belowTiles && !shared.cutoutTiles) {
          const outRT = this._acquireRT(shared.base.width, shared.base.height, shared.base.resolution || 1);
          shared.cutoutTiles = tilesRT
            ? composeMaskMinusTilesRT(shared.base, tilesRT, { outRT })
            : composeMaskMinusTiles(shared.base, { outRT, restrictionKind: "particles" });
        }
        if (belowTokens && belowTiles && !shared.cutoutCombined) {
          const outRT = this._acquireRT(shared.base.width, shared.base.height, shared.base.resolution || 1);
          shared.cutoutCombined = composeParticleCombinedCutoutRT(shared.base, tokensRT, tilesRT, outRT, shared);
        }
      }

      const maskTex = chooseParticleMaskTexture(shared, belowTokens, belowTiles);
      suppressVisibleMaskPaint(spr);
      spr.texture = safeMaskTexture(maskTex);
      container.mask = spr;

      applyMaskSpriteTransform(container, spr);
      const backgroundSurface = this._syncParticleBackgroundSurface(fx, container);

      const entry = {
        uid,
        scope: "region",
        fx,
        container,
        maskSprite: spr,
        maskBundle: shared,
        belowTokens,
        belowTiles,
        belowForeground,
        backgroundSurface,
        surfaceEdgeFadeCapable: surfaceFadeCapable,
        edgeFadeFilter: null,
        edgeFadeMaskEntry: null,
        edgeFadePreviousFilterArea: null,
        edgeFadePreviousFilterAreaCaptured: false,
      };
      this._syncRegionSurfaceEdgeFadeFilter(entry, useSurfaceEdgeFade ? surfaceEdgeFadeMask : null);
      if (edgeFadeCtx && !useSurfaceEdgeFade) this._applyPerParticleEdgeFadeToEffect(fx, edgeFadeCtx);
      this.regionEffects.get(regionId).push(entry);
      const root = layerLevel === "aboveDarkness" ? this._aboveContent : this._belowContainer;
      const regionLevels = getDocumentAssignedLevelIds(
        placeable?.document ?? null,
        placeable?.document?.parent ?? canvas?.scene ?? null,
      );
      const regionLevelList = regionLevels?.size ? Array.from(regionLevels) : null;
      fx.__fxmTrailLevelIds = regionLevelList;
      this._registerStackSlot(uid, root ?? container, container, {
        regionId,
        scope: "region",
        behaviorId: behavior.id,
        effectId: type,
        fx,
        container,
        layerLevel,
        belowTokens,
        belowTiles,
        belowForeground,
        levels: regionLevelList,
        options: regionLevelList ? { levels: regionLevelList } : undefined,
        maskSprite: spr,
        maskBundle: shared,
        document: placeable?.document ?? null,
        backgroundSurface,
      });
      fx.play({ prewarm: particleEffectPrewarmForInstanceSoftFade(fx, useSoftFade) });
      if (useSoftFade && typeof fx.fadeIn === "function") {
        void fx.fadeIn({ timeout: particleEffectFadeDurationMs(EffectClass) }).catch((err) => logger.debug("FXMaster:", err));
      }

      fx.__fxmBelowTokens = belowTokens;
      fx.__fxmBelowTiles = belowTiles;
      fx.__fxmBelowForeground = belowForeground;
    }

    if (!(this.regionEffects.get(regionId)?.length > 0)) {
      this.destroyRegionParticleEffects(regionId);
      return;
    }

    this._lastRegionDarknessSignatures.set(
      regionId,
      this._buildRegionDarknessActivationSignature(placeable, darknessLevel),
    );
    this._applyElevationGate(placeable, { force: true });
    this._updateOcclusionGates();
    this._updateRegionBelowTokensNeeded();
  }

  forceRegionMaskRefreshAll() {
    if (!this.regionEffects.size) return;
    for (const [regionId] of this.regionEffects.entries()) {
      const regionDoc = getSceneRegionDocumentById(regionId, canvas?.scene ?? null);
      const placeable = canvas.regions?.get(regionId) ?? getRegionPlaceableOrDocumentAdapter(regionDoc);
      if (placeable) this._rebuildRegionMaskFor(placeable);
    }
  }

  forceRegionMaskRefresh(regionId) {
    const regionDoc = getSceneRegionDocumentById(regionId, canvas?.scene ?? null);
    const placeable = canvas.regions?.get(regionId) ?? getRegionPlaceableOrDocumentAdapter(regionDoc);
    if (!placeable) return;
    this._rebuildRegionMaskFor(placeable);
  }

  /**
   * Schedule a mask refresh for one or more regions on the next animation frame. Multiple calls within the same frame are batched so that no region ID is lost.
   * @param {string} regionId
   */
  requestRegionMaskRefresh(regionId) {
    this._pendingRegionRefreshIds ??= new Set();
    this._pendingRegionRefreshIds.add(regionId);
    this._coalescedRegionRefresh ??= coalesceNextFrame(
      () => {
        const ids = this._pendingRegionRefreshIds;
        this._pendingRegionRefreshIds = new Set();
        for (const rid of ids) this.forceRegionMaskRefresh(rid);
      },
      { key: this },
    );
    this._coalescedRegionRefresh();
  }

  requestRegionMaskRefreshAll() {
    this._coalescedRefreshAll ??= coalesceNextFrame(() => this.forceRegionMaskRefreshAll(), { key: this });
    this._coalescedRefreshAll();
  }

  /**
   * Recompose live region below-object cutout masks against the current shared scene coverage textures.
   *
   * @param {{ refreshSharedMasks?: boolean }} [options]
   * @returns {void}
   */
  refreshCoverageCutoutsSync({ refreshSharedMasks = false } = {}) {
    if (!this.regionEffects.size) return;

    try {
      this._updateRegionBelowTokensNeeded();
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    if (!this._regionBelowTokensNeeded && !this._regionBelowTilesNeeded) {
      this._tokensDirty = false;
      return;
    }

    try {
      SceneMaskManager.instance.setBelowTokensNeeded?.("particles", this._regionBelowTokensNeeded, "regions");
      SceneMaskManager.instance.setBelowTilesNeeded?.("particles", this._regionBelowTilesNeeded, "regions");
      if (refreshSharedMasks) SceneMaskManager.instance.refreshTokensSync?.();
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    const masks = SceneMaskManager.instance.getMasks?.("particles") ?? {};
    const tokensRT = masks.tokens ?? null;
    const tilesRT = masks.tiles ?? null;

    for (const [regionId, shared] of this._regionMaskRTs.entries()) {
      if (!shared?.base) continue;
      const entries = this.regionEffects.get(regionId) ?? [];
      const anyBelowTokens = entries.some((entry) => !!entry?.fx?.__fxmBelowTokens);
      const anyBelowTiles = entries.some((entry) => !!entry?.fx?.__fxmBelowTiles);

      try {
        if (anyBelowTokens && shared.cutoutTokens) {
          if (tokensRT) composeMaskMinusTokensRT(shared.base, tokensRT, { outRT: shared.cutoutTokens });
          else composeMaskMinusTokens(shared.base, { outRT: shared.cutoutTokens });
        }
        if (anyBelowTiles && shared.cutoutTiles) {
          if (tilesRT) composeMaskMinusTilesRT(shared.base, tilesRT, { outRT: shared.cutoutTiles });
          else composeMaskMinusTiles(shared.base, { outRT: shared.cutoutTiles, restrictionKind: "particles" });
        }
        if (anyBelowTokens && anyBelowTiles && shared.cutoutCombined) {
          composeParticleCombinedCutoutRT(shared.base, tokensRT, tilesRT, shared.cutoutCombined, shared);
        }
      } catch (err) {
        logger?.error?.("FXMaster: error recomposing particle region coverage cutout mask", err);
      }
    }

    this._tokensDirty = false;
  }

  destroyRegionParticleEffects(regionId) {
    const entries = this.regionEffects.get(regionId) || [];
    for (const entry of entries) {
      if (entry?.uid) this._unregisterStackSlot(entry.uid);
      const fx = entry?.fx ?? entry;
      const container = entry?.container;
      const maskSprite = entry?.maskSprite;

      this._destroyRegionSurfaceEdgeFadeFilter(entry);
      this._destroyParticleBackgroundSurface(fx);

      try {
        fx?.stop?.();
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
      try {
        fx?.destroy?.();
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
      try {
        if (container && container.mask === maskSprite) container.mask = null;
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
      destroyParticleMaskSprite(maskSprite, container);

      try {
        if (container?.parent) container.parent.removeChild(container);
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
      try {
        container?.destroy?.({ children: true, texture: false, baseTexture: false });
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
    }
    this.regionEffects.delete(regionId);
    this._lastRegionDarknessSignatures.delete(regionId);
    this._updateRegionBelowTokensNeeded();

    const rt = this._regionMaskRTs.get(regionId);
    if (rt) {
      try {
        this._releaseRT(rt.base);
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
      for (const maskRT of [rt.cutoutTokens, rt.cutoutTiles, rt.cutoutCombined]) {
        try {
          this._releaseRT(maskRT);
        } catch (err) {
          logger.debug("FXMaster:", err);
        }
      }
      this._regionMaskRTs.delete(regionId);
    }
  }

  /**
   * Return the shader filter that removes live above-darkness particles where restrictive overhead tiles are revealed.
   *
   * @returns {PIXI.Filter|null}
   */
  _ensureAboveWeatherRevealFilter() {
    if (this._aboveWeatherRevealFilter && !this._aboveWeatherRevealFilter.destroyed)
      return this._aboveWeatherRevealFilter;

    try {
      this._aboveWeatherRevealFilter = new PIXI.Filter(
        `
        precision mediump float;
        attribute vec2 aVertexPosition;
        uniform mat3 projectionMatrix;
        uniform vec4 inputSize;
        uniform vec4 outputFrame;
        uniform vec2 screenDimensions;
        varying vec2 vTextureCoord;
        varying vec2 vMaskTextureCoord;
        void main() {
          vec2 position = aVertexPosition * max(outputFrame.zw, vec2(0.0)) + outputFrame.xy;
          vTextureCoord = aVertexPosition * (outputFrame.zw * inputSize.zw);
          vMaskTextureCoord = position / max(screenDimensions, vec2(1.0));
          gl_Position = vec4((projectionMatrix * vec3(position, 1.0)).xy, 0.0, 1.0);
        }
      `,
        `
        precision mediump float;
        varying vec2 vTextureCoord;
        varying vec2 vMaskTextureCoord;
        uniform sampler2D uSampler;
        uniform sampler2D revealSampler;
        void main() {
          vec4 src = texture2D(uSampler, vTextureCoord);
          vec2 maskUV = clamp(vMaskTextureCoord, vec2(0.0), vec2(1.0));
          vec4 revealSample = texture2D(revealSampler, maskUV);
          float reveal = max(revealSample.r, revealSample.a);
          float keep = clamp(1.0 - reveal, 0.0, 1.0);
          gl_FragColor = vec4(src.rgb * keep, src.a * keep);
        }
      `,
        { revealSampler: PIXI.Texture.EMPTY, screenDimensions: [1, 1] },
      );
      this._aboveWeatherRevealFilter.enabled = false;
      return this._aboveWeatherRevealFilter;
    } catch (err) {
      logger.debug("FXMaster:", err);
      this._aboveWeatherRevealFilter = null;
      return null;
    }
  }

  /**
   * Keep the above-darkness particle band filter list synchronized.
   *
   * @returns {void}
   */
  _syncAboveContentFilters() {
    if (!this._aboveContent || this._aboveContent.destroyed) return;

    const filters = [];
    if (this._aboveOccl && !this._aboveOccl.destroyed) filters.push(this._aboveOccl);
    if (this._aboveWeatherRevealFilter && !this._aboveWeatherRevealFilter.destroyed)
      filters.push(this._aboveWeatherRevealFilter);

    try {
      this._aboveContent.filters = filters.length ? filters : null;
      const screen = canvas?.app?.renderer?.screen ?? null;
      if (screen) this._aboveContent.filterArea = screen;
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
  }

  /**
   * Return whether the live above-darkness band currently has a renderable source.
   *
   * @returns {boolean}
   */
  _aboveContentHasRenderableSource() {
    for (const entry of this.stackEntries.values()) {
      if (entry?.layerLevel !== "aboveDarkness") continue;
      const slot = entry?.slot ?? entry?.container ?? entry?.fx ?? null;
      if (!slot || slot.destroyed) continue;
      if (slot.__fxmCompositorSourceSuppressed) continue;
      if (slot.visible === false || slot.renderable === false) continue;
      return true;
    }
    return false;
  }

  /**
   * Return a reusable viewport-sized Restricts Weather reveal mask for the above-darkness band.
   *
   * @returns {PIXI.RenderTexture|null}
   */
  _ensureAboveWeatherRevealRT() {
    const { cssW, cssH } = getCssViewportMetrics();
    const res = safeResolutionForCssArea(cssW, cssH);
    let rt = this._aboveWeatherRevealRT ?? null;

    const needsNew =
      !rt ||
      rt.destroyed ||
      Math.abs(Number(rt.width ?? 0) - cssW) > 0.001 ||
      Math.abs(Number(rt.height ?? 0) - cssH) > 0.001 ||
      Math.abs(Number(rt.resolution || 1) - res) > 0.0001;

    if (!needsNew) return rt;

    try {
      if (rt) this._releaseRT(rt);
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    try {
      rt = this._acquireRT(cssW, cssH, res);
      rt.baseTexture.scaleMode = PIXI.SCALE_MODES.LINEAR;
      rt.baseTexture.mipmap = PIXI.MIPMAP_MODES.OFF;
      this._aboveWeatherRevealRT = rt;
      return rt;
    } catch (err) {
      logger.debug("FXMaster:", err);
      this._aboveWeatherRevealRT = null;
      return null;
    }
  }

  /**
   * Update Restricts Weather reveal suppression for live above-darkness particles.
   *
   * @returns {void}
   */
  _updateAboveWeatherRevealSuppression() {
    const disable = () => {
      const filter = this._aboveWeatherRevealFilter ?? null;
      if (!filter || filter.destroyed) return;
      try {
        filter.enabled = false;
        if (filter.uniforms) filter.uniforms.revealSampler = PIXI.Texture.EMPTY;
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
    };

    if (!this._aboveContent || this._aboveContent.destroyed) {
      disable();
      return;
    }

    if (getSceneDarknessLevel() <= ACTIVE_DARKNESS_EPSILON) {
      disable();
      return;
    }

    if (!this._aboveContentHasRenderableSource()) {
      disable();
      return;
    }

    if (!this._sceneHasWeatherOcclusionTiles()) {
      disable();
      return;
    }

    const revealRT = this._ensureAboveWeatherRevealRT();
    const revealFilter = this._ensureAboveWeatherRevealFilter();
    if (!revealRT || !revealFilter) {
      disable();
      return;
    }

    try {
      repaintTilesMaskInto(revealRT, {
        mode: "weatherReveal",
        eraseUpperCoverage: false,
        restrictionKind: "particles",
        shouldIncludeTile: (tile) => tileDocumentRestrictsParticles(tile),
      });
      const screen = canvas?.app?.renderer?.screen ?? null;
      const screenW = Number(screen?.width ?? revealRT.width ?? 1);
      const screenH = Number(screen?.height ?? revealRT.height ?? 1);
      const fallbackW = Math.max(1, Number(revealRT.width) || 1);
      const fallbackH = Math.max(1, Number(revealRT.height) || 1);
      revealFilter.uniforms.revealSampler = revealRT;
      revealFilter.uniforms.screenDimensions = [
        Number.isFinite(screenW) && screenW > 0 ? screenW : fallbackW,
        Number.isFinite(screenH) && screenH > 0 ? screenH : fallbackH,
      ];
      revealFilter.enabled = true;
      this._syncAboveContentFilters();
    } catch (err) {
      logger.debug("FXMaster:", err);
      disable();
    }
  }

  #initializeInverseOcclusionFilter() {
    this.occlusionFilter = CONFIG.fxmaster.WeatherOcclusionMaskFilterNS.create({
      occlusionTexture: canvas.masks.depth.renderTexture,
    });
    this.occlusionFilter.enabled = false;
    this.occlusionFilter.elevation = this.#elevation;
    this.occlusionFilter.blendMode = PIXI.BLEND_MODES.NORMAL;
    this.filterArea = canvas.app.renderer.screen;
    this.filters = [this.occlusionFilter];
  }

  refreshAboveSceneMask() {
    if (!this._aboveContent) return;
    const sceneMask = canvas?.masks?.scene || null;
    try {
      this._aboveContent.mask = sceneMask;
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
    if (this._aboveMaskGfx && !this._aboveMaskGfx.destroyed) {
      try {
        this._aboveMaskGfx.destroy(true);
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
    }
    this._aboveMaskGfx = null;
  }

  _ensureSceneContainers() {
    if (!this._belowContainer || this._belowContainer.destroyed) {
      this._belowContainer = new PIXI.Container();
      this._belowContainer.name = "fxmSceneBelowBand";
      this._belowContainer.sortableChildren = true;
      this._belowContainer.eventMode = "none";
      this.addChild(this._belowContainer);

      this._belowOccl = CONFIG.fxmaster.WeatherOcclusionMaskFilterNS.create({
        occlusionTexture: canvas.masks.depth.renderTexture,
      });
      this._belowOccl.enabled = false;
      this._belowOccl.elevation = this.#elevation;
      this._belowOccl.blendMode = PIXI.BLEND_MODES.NORMAL;
      this._belowContainer.filters = [this._belowOccl];
      this._belowContainer.filterArea = canvas.app.renderer.screen;
    }

    if (!this._sceneBelowCutout || this._sceneBelowCutout.destroyed) {
      this._sceneBelowCutout = new PIXI.Container();
      this._sceneBelowCutout.name = "fxmSceneBelowCutout";
      this._sceneBelowCutout.sortableChildren = true;
      this._sceneBelowCutout.eventMode = "none";
      this._belowContainer.addChild(this._sceneBelowCutout);
    } else if (this._sceneBelowCutout.parent !== this._belowContainer) {
      try {
        this._sceneBelowCutout.parent?.removeChild?.(this._sceneBelowCutout);
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
      this._belowContainer.addChild(this._sceneBelowCutout);
    }

    if (!this._sceneBelowBase || this._sceneBelowBase.destroyed) {
      this._sceneBelowBase = new PIXI.Container();
      this._sceneBelowBase.name = "fxmSceneBelowBase";
      this._sceneBelowBase.sortableChildren = true;
      this._sceneBelowBase.eventMode = "none";
      this._belowContainer.addChild(this._sceneBelowBase);
    } else if (this._sceneBelowBase.parent !== this._belowContainer) {
      try {
        this._sceneBelowBase.parent?.removeChild?.(this._sceneBelowBase);
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
      this._belowContainer.addChild(this._sceneBelowBase);
    }

    const expectParent = canvas.effects ?? canvas.rendered ?? this;
    if (!this._aboveContent || this._aboveContent.destroyed) {
      this._aboveContent = new PIXI.Container();
      this._aboveContent.name = "fxmSceneAboveBand";
      this._aboveContent.sortableChildren = true;
      this._aboveContent.eventMode = "none";
      this._aboveContent.renderable = true;
      this._aboveContent.zIndex = Math.max(Number(this._aboveContent.zIndex ?? 0) || 0, 100000);
      expectParent.addChild(this._aboveContent);
      this.refreshAboveSceneMask();

      this._aboveOccl = CONFIG.fxmaster.WeatherOcclusionMaskFilterNS.create({
        occlusionTexture: canvas.masks.depth.renderTexture,
      });
      this._aboveOccl.enabled = false;
      this._aboveOccl.elevation = this.#elevation;
      this._aboveOccl.blendMode = PIXI.BLEND_MODES.NORMAL;
      this._syncAboveContentFilters();
    } else if (this._aboveContent.parent !== expectParent) {
      try {
        this._aboveContent.parent?.removeChild?.(this._aboveContent);
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
      expectParent.addChild(this._aboveContent);
    }
    try {
      this._aboveContent.visible = true;
      this._aboveContent.renderable = true;
      this._aboveContent.zIndex = Math.max(Number(this._aboveContent.zIndex ?? 0) || 0, 100000);
      if (expectParent.sortableChildren) expectParent.sortChildren?.();
      else if (typeof expectParent.setChildIndex === "function" && this._aboveContent.parent === expectParent) {
        const last = Math.max(0, (expectParent.children?.length ?? 1) - 1);
        if (expectParent.getChildIndex?.(this._aboveContent) !== last)
          expectParent.setChildIndex(this._aboveContent, last);
      }
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    if (!this._sceneAboveCutout || this._sceneAboveCutout.destroyed) {
      this._sceneAboveCutout = new PIXI.Container();
      this._sceneAboveCutout.name = "fxmSceneAboveCutout";
      this._sceneAboveCutout.sortableChildren = true;
      this._sceneAboveCutout.eventMode = "none";
      this._aboveContent.addChild(this._sceneAboveCutout);
    } else if (this._sceneAboveCutout.parent !== this._aboveContent) {
      try {
        this._sceneAboveCutout.parent?.removeChild?.(this._sceneAboveCutout);
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
      this._aboveContent.addChild(this._sceneAboveCutout);
    }

    if (!this._sceneAboveBase || this._sceneAboveBase.destroyed) {
      this._sceneAboveBase = new PIXI.Container();
      this._sceneAboveBase.name = "fxmSceneAboveBase";
      this._sceneAboveBase.sortableChildren = true;
      this._sceneAboveBase.eventMode = "none";
      this._aboveContent.addChild(this._sceneAboveBase);
    } else if (this._sceneAboveBase.parent !== this._aboveContent) {
      try {
        this._sceneAboveBase.parent?.removeChild?.(this._sceneAboveBase);
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
      this._aboveContent.addChild(this._sceneAboveBase);
    }

    const { cssW, cssH } = getCssViewportMetrics();

    const ensureBucketMask = (bucket, prop, name) => {
      if (!bucket || bucket.destroyed) return null;

      let spr = this[prop];
      if (!spr || spr.destroyed) {
        spr = new PIXI.Sprite(PIXI.Texture.EMPTY);
        spr.name = name;
        spr.eventMode = "none";
        spr.renderable = false;
        spr._fxmMaskEnabled = false;
        this[prop] = spr;
        try {
          bucket.addChild(spr);
        } catch (err) {
          logger.debug("FXMaster:", err);
        }
      } else if (spr.parent !== bucket) {
        try {
          spr.parent?.removeChild?.(spr);
        } catch (err) {
          logger.debug("FXMaster:", err);
        }
        try {
          bucket.addChild(spr);
        } catch (err) {
          logger.debug("FXMaster:", err);
        }
      }

      try {
        if (spr.texture?.orig) {
          spr.width = cssW;
          spr.height = cssH;
        }
      } catch (err) {
        logger.debug("FXMaster:", err);
      }

      return spr;
    };

    ensureBucketMask(this._sceneBelowCutout, "_sceneBelowCutoutMask", "fxmSceneParticlesMask:belowCutout");
    ensureBucketMask(this._sceneBelowBase, "_sceneBelowBaseMask", "fxmSceneParticlesMask:belowBase");
    ensureBucketMask(this._sceneAboveCutout, "_sceneAboveCutoutMask", "fxmSceneParticlesMask:aboveCutout");
    ensureBucketMask(this._sceneAboveBase, "_sceneAboveBaseMask", "fxmSceneParticlesMask:aboveBase");

    this._updateOcclusionGates();
    this._updateRegionBelowTokensNeeded();
  }

  _rebuildRegionMaskFor(placeable) {
    const regionId = placeable.id;
    const entries = this.regionEffects.get(regionId);
    if (!entries?.length) return;

    const { cssW, cssH } = getCssViewportMetrics();
    const VW = Math.max(1, Number(cssW) || 1);
    const VH = Math.max(1, Number(cssH) || 1);
    const regionMaskResolution = regionMaskResolutionForEdgeSync(
      placeable,
      `${packageId}.suppressSceneParticles`,
      cssW,
      cssH,
    );

    let shared = this._regionMaskRTs.get(regionId) || {
      base: null,
      cutoutTokens: null,
      cutoutTiles: null,
      cutoutCombined: null,
    };
    const oldBase = shared.base ?? null;
    const edgeFadePercent = this._getRegionEdgeFadePercent(placeable);
    const needsSurfaceEdgeFade =
      edgeFadePercent > 0 && entries.some((entry) => entry?.surfaceEdgeFadeCapable === true);
    const surfaceEdgeFadeMask = needsSurfaceEdgeFade ? getRegionSoftMaskData(placeable, edgeFadePercent) : null;
    const newBase = buildRegionMaskRT(placeable, {
      rtPool: this._rtPool,
      resolution: regionMaskResolution,
      reuseRT: oldBase,
    });
    shared.base = newBase;
    if (!newBase) return;

    const anyBelowTokens = entries.some((e) => !!e?.fx?.__fxmBelowTokens);
    const anyBelowTiles = entries.some((e) => !!e?.fx?.__fxmBelowTiles);
    if (anyBelowTokens || anyBelowTiles) {
      try {
        SceneMaskManager.instance.setBelowTokensNeeded?.("particles", anyBelowTokens, "regions");
        SceneMaskManager.instance.setBelowTilesNeeded?.("particles", anyBelowTiles, "regions");
        SceneMaskManager.instance.refreshTokensSync?.();
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
      const masks = SceneMaskManager.instance.getMasks?.("particles") ?? {};
      const tokensRT = masks.tokens ?? null;
      const tilesRT = masks.tiles ?? null;

      const reuseTokens =
        !!shared.cutoutTokens &&
        Math.abs(Number(shared.cutoutTokens.width ?? 0) - Number(newBase.width ?? 0)) <= 0.001 &&
        Math.abs(Number(shared.cutoutTokens.height ?? 0) - Number(newBase.height ?? 0)) <= 0.001 &&
        (shared.cutoutTokens.resolution || 1) === (newBase.resolution || 1);
      const reuseTiles =
        !!shared.cutoutTiles &&
        Math.abs(Number(shared.cutoutTiles.width ?? 0) - Number(newBase.width ?? 0)) <= 0.001 &&
        Math.abs(Number(shared.cutoutTiles.height ?? 0) - Number(newBase.height ?? 0)) <= 0.001 &&
        (shared.cutoutTiles.resolution || 1) === (newBase.resolution || 1);
      const reuseCombined =
        !!shared.cutoutCombined &&
        Math.abs(Number(shared.cutoutCombined.width ?? 0) - Number(newBase.width ?? 0)) <= 0.001 &&
        Math.abs(Number(shared.cutoutCombined.height ?? 0) - Number(newBase.height ?? 0)) <= 0.001 &&
        (shared.cutoutCombined.resolution || 1) === (newBase.resolution || 1);

      if (anyBelowTokens) {
        const outRT = reuseTokens
          ? shared.cutoutTokens
          : this._acquireRT(newBase.width, newBase.height, newBase.resolution || 1);
        shared.cutoutTokens = tokensRT
          ? composeMaskMinusTokensRT(newBase, tokensRT, { outRT })
          : composeMaskMinusTokens(newBase, { outRT });
      } else if (shared.cutoutTokens) {
        this._releaseRT(shared.cutoutTokens);
        shared.cutoutTokens = null;
      }

      if (anyBelowTiles) {
        const outRT = reuseTiles
          ? shared.cutoutTiles
          : this._acquireRT(newBase.width, newBase.height, newBase.resolution || 1);
        shared.cutoutTiles = tilesRT
          ? composeMaskMinusTilesRT(newBase, tilesRT, { outRT })
          : composeMaskMinusTiles(newBase, { outRT, restrictionKind: "particles" });
      } else if (shared.cutoutTiles) {
        this._releaseRT(shared.cutoutTiles);
        shared.cutoutTiles = null;
      }

      if (anyBelowTokens && anyBelowTiles) {
        const outRT = reuseCombined
          ? shared.cutoutCombined
          : this._acquireRT(newBase.width, newBase.height, newBase.resolution || 1);
        shared.cutoutCombined = composeParticleCombinedCutoutRT(newBase, tokensRT, tilesRT, outRT, shared);
      } else if (shared.cutoutCombined) {
        this._releaseRT(shared.cutoutCombined);
        shared.cutoutCombined = null;
      }
    } else {
      for (const key of ["cutoutTokens", "cutoutTiles", "cutoutCombined"]) {
        if (shared[key]) this._releaseRT(shared[key]);
        shared[key] = null;
      }
    }
    this._regionMaskRTs.set(regionId, shared);

    for (const entry of entries) {
      const spr = entry?.maskSprite;
      const cont = entry?.container;
      if (!spr || spr.destroyed || !cont || cont.destroyed) continue;

      const want = chooseParticleMaskTexture(shared, !!entry?.fx?.__fxmBelowTokens, !!entry?.fx?.__fxmBelowTiles);
      spr.texture = safeMaskTexture(want);

      if (!spr.texture) continue;
      try {
        spr.width = VW;
        spr.height = VH;
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
      try {
        applyMaskSpriteTransform(cont, spr);
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
      if (cont.mask !== spr) {
        try {
          cont.mask = spr;
        } catch (err) {
          logger.debug("FXMaster:", err);
        }
      }
      this._syncRegionSurfaceEdgeFadeFilter(
        entry,
        entry?.surfaceEdgeFadeCapable ? surfaceEdgeFadeMask : null,
      );
    }

    if (oldBase && oldBase !== newBase) this._releaseRT(oldBase);
  }

  /**
   * Compute the region-edge fade percent for particle effects (0..1). If multiple particle behaviors exist on the region, the maximum is used.
   *
   * @param {PlaceableObject} placeable
   * @param {foundry.documents.RegionBehavior[]} [behaviors]
   * @returns {number}
   * @private
   */
  _getRegionEdgeFadePercent(placeable, behaviors = null) {
    const list = behaviors ?? (placeable?.document?.behaviors || []).filter((b) => b?.type === TYPE && !b?.disabled);

    let max = 0;
    for (const b of list) {
      max = Math.max(max, getRegionBehaviorEdgeFadePercent(b));
    }
    return Math.min(Math.max(max, 0), 1);
  }

  /**
   * Build a per-particle edge fade context for a region.
   *
   * This returns a context which keeps the region mask binary and applies an additional per-particle alpha multiplier derived from world-space distance to the nearest region boundary. This avoids visible banding artifacts that can occur when generating a soft region mask on 8-bit render targets.
   *
   * @param {PlaceableObject} placeable
   * @param {number} edgeFadePercent - [0..1]
   * @returns {{bandWorld:number, computeFade:(x:number,y:number)=>number}|null}
   * @private
   */
  _buildPerParticleEdgeFadeContext(placeable, edgeFadePercent) {
    const pct = Math.min(Math.max(Number(edgeFadePercent) || 0, 0), 1);
    if (!(pct > 0)) return null;

    const inrad = estimateRegionInradius(placeable);
    const bandWorld = Math.max(1e-6, pct * (Number.isFinite(inrad) && inrad > 0 ? inrad : 0));
    if (!(bandWorld > 0)) return null;

    const shapes = regionMaskTraceShapes(placeable);
    if (!Array.isArray(shapes) || shapes.length === 0) return null;

    /** @type {Array<any>} */
    const solids = [];
    /** @type {Array<any>} */
    const holes = [];

    const toFlat = (pts) => {
      if (!pts) return null;
      if (Array.isArray(pts) && typeof pts[0] === "number") return pts.slice();
      if (Array.isArray(pts) && typeof pts[0] === "object") {
        const out = [];
        for (const p of pts) {
          if (!p) continue;
          out.push(Number(p.x) || 0, Number(p.y) || 0);
        }
        return out;
      }
      return null;
    };

    const normalizeFlat = (flat) => {
      if (!Array.isArray(flat) || flat.length < 6) return null;
      const n = (flat.length / 2) | 0;
      if (n < 3) return null;
      const lx = flat[2 * (n - 1)];
      const ly = flat[2 * (n - 1) + 1];
      const closed = lx === flat[0] && ly === flat[1];
      const m = closed ? n - 1 : n;
      if (m < 3) return null;
      return flat.slice(0, m * 2);
    };

    const centroidFlat = (flat) => {
      const n = (flat.length / 2) | 0;
      let sx = 0;
      let sy = 0;
      for (let i = 0; i < n; i++) {
        sx += flat[2 * i];
        sy += flat[2 * i + 1];
      }
      return { x: sx / n, y: sy / n };
    };

    const rotateFlat = (flat, cx, cy, rotRad) => {
      if (!rotRad) return flat;
      const c = Math.cos(rotRad);
      const s = Math.sin(rotRad);
      const out = flat.slice();
      const n = (flat.length / 2) | 0;
      for (let i = 0; i < n; i++) {
        const x = out[2 * i] - cx;
        const y = out[2 * i + 1] - cy;
        out[2 * i] = cx + x * c - y * s;
        out[2 * i + 1] = cy + x * s + y * c;
      }
      return out;
    };

    const buildPoly = (flat) => {
      const pts = new Float32Array(flat);
      const n = (pts.length / 2) | 0;
      if (n < 3) return null;

      let minX = Infinity,
        minY = Infinity,
        maxX = -Infinity,
        maxY = -Infinity;
      for (let i = 0; i < n; i++) {
        const x = pts[2 * i];
        const y = pts[2 * i + 1];
        if (x < minX) minX = x;
        if (y < minY) minY = y;
        if (x > maxX) maxX = x;
        if (y > maxY) maxY = y;
      }

      const edges = new Float32Array(n * 7);
      for (let i = 0; i < n; i++) {
        const j = (i + n - 1) % n;
        const ax = pts[2 * j];
        const ay = pts[2 * j + 1];
        const bx = pts[2 * i];
        const by = pts[2 * i + 1];
        const abx = bx - ax;
        const aby = by - ay;
        const denom = abx * abx + aby * aby;
        const inv = denom > 1e-6 ? 1 / denom : 0;

        const o = i * 7;
        edges[o] = ax;
        edges[o + 1] = ay;
        edges[o + 2] = bx;
        edges[o + 3] = by;
        edges[o + 4] = abx;
        edges[o + 5] = aby;
        edges[o + 6] = inv;
      }

      return { kind: "poly", pts, edges, minX, minY, maxX, maxY };
    };

    const addPoly = (pts, hole, rotRad = 0) => {
      let flat = normalizeFlat(toFlat(pts));
      if (!flat) return;
      if (rotRad) {
        const c = centroidFlat(flat);
        flat = rotateFlat(flat, c.x, c.y, rotRad);
      }
      const poly = buildPoly(flat);
      if (!poly) return;
      (hole ? holes : solids).push(poly);
    };

    const isEmptyShape = (s) => {
      try {
        if (typeof s?.isEmpty === "function") return !!s.isEmpty();
        return !!s?.isEmpty;
      } catch {
        return false;
      }
    };

    for (const s of shapes) {
      if (!s) continue;
      if (isEmptyShape(s)) continue;
      const hole = !!s.hole;

      if (Array.isArray(s?.polygons) && s.polygons.length) {
        for (const poly of s.polygons) {
          if (!poly) continue;
          addPoly(poly?.points ?? poly, hole, 0);
        }
        continue;
      }

      const type = s?.type;
      const rotRad = ((Number(s?.rotation) || 0) * Math.PI) / 180;

      if (type === "rectangle") {
        const x = Number(s.x) || 0;
        const y = Number(s.y) || 0;
        const w = Math.max(0, Number(s.width) || 0);
        const h = Math.max(0, Number(s.height) || 0);
        const cx = x + w / 2;
        const cy = y + h / 2;
        const c = Math.cos(rotRad);
        const sn = Math.sin(rotRad);

        const ex = Math.abs(c) * (w / 2) + Math.abs(sn) * (h / 2);
        const ey = Math.abs(sn) * (w / 2) + Math.abs(c) * (h / 2);

        (hole ? holes : solids).push({
          kind: "rect",
          cx,
          cy,
          hx: w / 2,
          hy: h / 2,
          c,
          s: sn,
          minX: cx - ex,
          minY: cy - ey,
          maxX: cx + ex,
          maxY: cy + ey,
        });
        continue;
      }

      if (type === "ellipse" || type === "circle") {
        const cx = Number(s.x) || 0;
        const cy = Number(s.y) || 0;
        const rx = Math.max(0, type === "circle" ? Number(s.radius) || 0 : Number(s.radiusX) || 0);
        const ry = Math.max(0, type === "circle" ? Number(s.radius) || 0 : Number(s.radiusY) || 0);
        const c = Math.cos(rotRad);
        const sn = Math.sin(rotRad);

        const ex = Math.sqrt(rx * c * (rx * c) + ry * sn * (ry * sn));
        const ey = Math.sqrt(rx * sn * (rx * sn) + ry * c * (ry * c));

        (hole ? holes : solids).push({
          kind: "ellipse",
          cx,
          cy,
          hx: rx,
          hy: ry,
          c,
          s: sn,
          minX: cx - ex,
          minY: cy - ey,
          maxX: cx + ex,
          maxY: cy + ey,
        });
        continue;
      }

      if (type === "polygon") {
        addPoly(s.points ?? [], hole, rotRad);
        continue;
      }

      if (Array.isArray(s?.points) && s.points.length) {
        addPoly(s.points, hole, rotRad);
      }
    }

    if (!solids.length) return null;

    const sdRect = (px, py, r) => {
      const dx = px - r.cx;
      const dy = py - r.cy;
      const x = r.c * dx + r.s * dy;
      const y = -r.s * dx + r.c * dy;
      const qx = Math.abs(x) - r.hx;
      const qy = Math.abs(y) - r.hy;
      const ox = Math.max(qx, 0);
      const oy = Math.max(qy, 0);
      const outside = Math.hypot(ox, oy);
      const inside = Math.min(Math.max(qx, qy), 0);
      return outside + inside;
    };

    const sdEllipse = (px, py, e) => {
      const dx = px - e.cx;
      const dy = py - e.cy;
      const x = e.c * dx + e.s * dy;
      const y = -e.s * dx + e.c * dy;
      const hx = Math.max(1e-6, e.hx);
      const hy = Math.max(1e-6, e.hy);
      const nx = x / hx;
      const ny = y / hy;
      const r = Math.hypot(nx, ny);
      const R = Math.max(hx, hy);
      return (r - 1) * R;
    };

    const sdPoly = (px, py, poly) => {
      const edges = poly.edges;
      const n = (edges.length / 7) | 0;
      if (n < 3) return 1e20;

      let inside = false;
      let dMin2 = 1e40;

      for (let i = 0; i < n; i++) {
        const o = i * 7;
        const ax = edges[o];
        const ay = edges[o + 1];
        const by = edges[o + 3];
        const abx = edges[o + 4];
        const aby = edges[o + 5];
        const inv = edges[o + 6];

        const intersect = ay > py !== by > py && px < (abx * (py - ay)) / (by - ay + 1e-12) + ax;
        if (intersect) inside = !inside;

        const dx = px - ax;
        const dy = py - ay;
        let t = inv > 0 ? (dx * abx + dy * aby) * inv : 0;
        if (t < 0) t = 0;
        else if (t > 1) t = 1;
        const cx = dx - abx * t;
        const cy = dy - aby * t;
        const d2 = cx * cx + cy * cy;
        if (d2 < dMin2) dMin2 = d2;
      }

      const d = Math.sqrt(dMin2);
      return inside ? -d : d;
    };

    const shapeSd = (px, py, sh) => {
      if (!sh) return 1e20;
      if (sh.kind === "rect") return sdRect(px, py, sh);
      if (sh.kind === "ellipse") return sdEllipse(px, py, sh);
      if (sh.kind === "poly") return sdPoly(px, py, sh);
      return 1e20;
    };

    const smooth01 = (t) => {
      t = Math.min(1, Math.max(0, t));
      return t * t * (3 - 2 * t);
    };

    const computeFade = (x, y) => {
      let insideSolid = 0;

      for (const sh of solids) {
        if (x < sh.minX || x > sh.maxX || y < sh.minY || y > sh.maxY) continue;

        const sd = shapeSd(x, y, sh);
        if (sd < 0) {
          const d = -sd;
          if (d > insideSolid) insideSolid = d;

          if (insideSolid >= bandWorld) {
            insideSolid = bandWorld;
            break;
          }
        }
      }

      if (!(insideSolid > 0)) return 0;

      if (!holes.length) return insideSolid >= bandWorld ? 1 : smooth01(insideSolid / bandWorld);

      let holeMin = Infinity;
      let holeMin2 = Infinity;

      for (const sh of holes) {
        if (holeMin2 !== Infinity) {
          let dx = 0;
          if (x < sh.minX) dx = sh.minX - x;
          else if (x > sh.maxX) dx = x - sh.maxX;

          let dy = 0;
          if (y < sh.minY) dy = sh.minY - y;
          else if (y > sh.maxY) dy = y - sh.maxY;

          const d2 = dx * dx + dy * dy;
          if (d2 >= holeMin2) continue;
        }

        const sd = shapeSd(x, y, sh);
        if (sd < 0) return 0;
        if (sd < holeMin) {
          holeMin = sd;
          holeMin2 = sd * sd;

          if (holeMin <= 1e-6) break;
        }
      }

      if (Number.isFinite(holeMin)) insideSolid = Math.min(insideSolid, holeMin);

      if (insideSolid >= bandWorld) return 1;

      return smooth01(insideSolid / bandWorld);
    };

    return { bandWorld, computeFade };
  }

  /**
   * Wrap emitter updates to apply per-particle edge fade.
   * @param {any} fx
   * @param {{computeFade:(x:number,y:number)=>number}} ctx
   * @private
   */
  _applyPerParticleEdgeFadeToEffect(fx, ctx) {
    if (!fx || !ctx?.computeFade) return;

    const emitters = fx.emitters ?? [];
    for (const emitter of emitters) {
      if (!emitter || emitter._fxmEdgeFadeWrapped) continue;

      const origUpdate = emitter.update?.bind(emitter);
      if (typeof origUpdate !== "function") continue;

      emitter.update = (delta) => {
        try {
          fxmForEachEmitterParticle(emitter, (p) => {
            const last = Number(p?._fxmEdgeFadeMul);
            if (!Number.isFinite(last) || last === 1) return;

            const base = p?._fxmEdgeFadeBaseAlpha;
            if (typeof base === "number" && Number.isFinite(base)) {
              p.alpha = base;
            }
          });
        } catch (err) {
          logger.debug("FXMaster:", err);
        }

        origUpdate(delta);

        try {
          fxmForEachEmitterParticle(emitter, (p) => {
            const a = Number(p?.alpha) || 0;
            p._fxmEdgeFadeBaseAlpha = a;

            const x = typeof p?.x === "number" ? p.x : Number(p?.x) || 0;
            const y = typeof p?.y === "number" ? p.y : Number(p?.y) || 0;

            const f = ctx.computeFade(x, y);
            p._fxmEdgeFadeMul = f;
            p.alpha = a * f;
          });
        } catch (err) {
          logger.debug("FXMaster:", err);
        }
      };

      emitter._fxmEdgeFadeWrapped = true;
    }
  }

  _animate() {
    super._animate();

    try {
      this._updateParticleBackgroundSurfaces();
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    try {
      this._refreshBelowObjectCoverageForCamera();
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    try {
      this._sanitizeSceneMasks();
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    try {
      this._updateAboveWeatherRevealSuppression();
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    try {
      const darknessLevel = getSceneDarknessLevel();
      const previousDarknessLevel = this._lastDarknessLevel;
      const darknessChanged =
        !Number.isFinite(previousDarknessLevel) || Math.abs(darknessLevel - previousDarknessLevel) > 1e-4;
      this._lastDarknessLevel = darknessLevel;

      const sceneSignature = this._buildSceneDarknessActivationSignature(darknessLevel);
      if (sceneSignature !== this._lastSceneDarknessSignature) {
        this._lastSceneDarknessSignature = sceneSignature;
        void this.drawParticleEffects({ soft: true });
      }

      if (darknessChanged) {
        for (const region of getRegionEffectPlaceablesForCurrentView(canvas?.scene ?? null)) {
          const signature = this._buildRegionDarknessActivationSignature(region, darknessLevel);
          if (signature !== (this._lastRegionDarknessSignatures.get(region.id) ?? "")) {
            this._lastRegionDarknessSignatures.set(region.id, signature);
            void this.drawRegionParticleEffects(region, { soft: true });
          }
        }
      }
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    try {
      this.#updateSceneParticlesSuppressionForCamera(this._currentCameraMatrix ?? snappedStageMatrix());
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    if (this.regionEffects.size === 0) return;

    const { deviceRect } = getCssViewportMetrics();
    const w = deviceRect.width | 0;
    const h = deviceRect.height | 0;
    if (w !== this._lastViewSize.w || h !== this._lastViewSize.h) {
      this._lastViewSize = { w, h };
      this.forceRegionMaskRefreshAll();
    }

    this._sanitizeRegionMasks();

    if (this._tokensDirty) {
      try {
        this.refreshCoverageCutoutsSync({ refreshSharedMasks: true });
      } catch (err) {
        logger?.error?.("FXMaster: error recomposing particle token cutout masks", err);
      }
      this._tokensDirty = false;
    }

    try {
      for (const [regionId] of this.regionEffects.entries()) {
        const regionDoc = getSceneRegionDocumentById(regionId, canvas?.scene ?? null);
        if (!regionDoc || !regionDocumentCanApplyInCurrentView(regionDoc, canvas?.scene ?? null)) {
          this.destroyRegionParticleEffects(regionId);
          continue;
        }
        const reg = canvas.regions?.get(regionId) ?? getRegionPlaceableOrDocumentAdapter(regionDoc);
        if (reg) this._applyElevationGate(reg);
      }
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
  }

  applyElevationGateForAll() {
    try {
      for (const [regionId] of this.regionEffects.entries()) {
        const regionDoc = getSceneRegionDocumentById(regionId, canvas?.scene ?? null);
        if (!regionDoc || !regionDocumentCanApplyInCurrentView(regionDoc, canvas?.scene ?? null)) {
          this.destroyRegionParticleEffects(regionId);
          continue;
        }
        const reg = canvas.regions?.get(regionId) ?? getRegionPlaceableOrDocumentAdapter(regionDoc);
        if (reg) this._applyElevationGate(reg);
      }
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
  }

  _applyElevationGate(placeable, { force = false } = {}) {
    const entries = this.regionEffects.get(placeable.id) || [];
    if (!entries.length) return;

    const pass = computeRegionGatePass(placeable, { behaviorType: `${packageId}.particleEffectsRegion` });
    const prev = this._gatePassCache.get(placeable.id);

    if (!force && prev === pass) {
      let allMatch = true;
      for (const entry of entries) {
        const vis = !!entry?.container?.visible;
        const en = entry?.fx && "enabled" in entry.fx ? !!entry.fx.enabled : vis;
        if (vis !== !!pass || en !== !!pass) {
          allMatch = false;
          break;
        }
      }
      if (allMatch) return;
    }

    for (const entry of entries) {
      try {
        if (entry?.container && entry.container.visible !== !!pass) entry.container.visible = !!pass;
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
      try {
        if (entry?.fx && "enabled" in entry.fx && entry.fx.enabled !== !!pass) entry.fx.enabled = !!pass;
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
    }

    this._gatePassCache.set(placeable.id, pass);
  }

  _updateOcclusionGates() {
    const hasChildrenExceptMask = (container, maskSprite) => {
      if (!container || container.destroyed) return false;
      const kids = container.children ?? [];
      if (!kids.length) return false;
      if (kids.length === 1 && maskSprite && kids[0] === maskSprite) return false;
      if (maskSprite && kids.length > 0) {
        return kids.some((c) => c !== maskSprite);
      }
      return kids.length > 0;
    };

    const hasBelowScene =
      hasChildrenExceptMask(this._sceneBelowBase, this._sceneBelowBaseMask) ||
      hasChildrenExceptMask(this._sceneBelowCutout, this._sceneBelowCutoutMask);

    const hasAboveScene =
      hasChildrenExceptMask(this._sceneAboveBase, this._sceneAboveBaseMask) ||
      hasChildrenExceptMask(this._sceneAboveCutout, this._sceneAboveCutoutMask);

    if (this.occlusionFilter) {
      this.occlusionFilter.enabled = false;
      this.occlusionFilter.elevation = this.#elevation;
    }

    const canUseNativeWeatherOcclusion = canUseNativeWeatherOcclusionStackPass();
    const hasRadialWeatherTiles =
      canUseNativeWeatherOcclusion &&
      hasActiveRadialRestrictWeatherTilesForMask("particles", { includeOffscreen: true });
    if (hasRadialWeatherTiles) {
      this._weatherOcclusionTilePresence = null;
      syncActiveRadialRestrictWeatherTileMasksForCamera("particles", { includeOffscreen: true });
    }
    const hasWeatherOcclusionTiles = canUseNativeWeatherOcclusion ? this._sceneHasWeatherOcclusionTiles() : false;

    if (this._belowOccl) {
      this._belowOccl.enabled =
        hasWeatherOcclusionTiles && (!!hasBelowScene || this._hasRegionFXInRoot(this._belowContainer));
      this._belowOccl.elevation = this.#elevation;
    }
    if (this._aboveOccl) {
      this._aboveOccl.enabled =
        hasWeatherOcclusionTiles && (!!hasAboveScene || this._hasRegionFXInRoot(this._aboveContent));
      this._aboveOccl.elevation = this.#elevation;
    }
  }

  _hasRegionFXInRoot(root) {
    if (!root) return false;
    for (const entries of this.regionEffects.values()) {
      for (const e of entries) {
        if (e?.container?.parent === root) return true;
      }
    }
    return false;
  }

  /**
   * Return whether the scene contains visible tile occlusion that can restrict FXMaster particles.
   *
   * @returns {boolean}
   */
  _sceneHasWeatherOcclusionTiles() {
    const cache = this._weatherOcclusionTilePresence ?? { key: null, value: false, time: 0 };
    const tiles = canvas?.tiles?.placeables ?? [];
    const now = Number(canvas?.app?.ticker?.lastTime ?? globalThis.performance?.now?.() ?? Date.now()) || 0;
    const sceneId = canvas?.scene?.id ?? "";
    const key = `${sceneId}|${tiles.length}`;

    if (cache.key === key && now - Number(cache.time ?? 0) < 250) return cache.value;

    const foundryGeneration = Number(
      globalThis.game?.release?.generation ?? String(globalThis.game?.version ?? "").split(".")[0],
    );
    const requireLegacyOverhead = !Number.isFinite(foundryGeneration) || foundryGeneration < 14;

    let value = false;
    for (const tile of tiles) {
      if (!tile || tile.document?.hidden) continue;
      if (tile.visible === false || tile?.mesh?.visible === false || tile?.mesh?.renderable === false) continue;

      if (!tileHasActiveOcclusion(tile)) continue;
      if (requireLegacyOverhead && !isTileOverhead(tile)) continue;
      if (!tileDocumentRestrictsParticles(tile)) continue;

      value = true;
      break;
    }

    this._weatherOcclusionTilePresence = { key, value, time: now };
    return value;
  }

  _sanitizeRegionMasks() {
    if (!this.regionEffects.size) return;

    const { cssW, cssH } = getCssViewportMetrics();

    for (const [regionId, entries] of this.regionEffects.entries()) {
      const shared = this._regionMaskRTs.get(regionId);
      for (const entry of entries) {
        const spr = entry?.maskSprite;
        const cont = entry?.container;
        if (!spr || spr.destroyed || !cont || cont.destroyed) continue;

        const want = chooseParticleMaskTexture(shared, !!entry?.fx?.__fxmBelowTokens, !!entry?.fx?.__fxmBelowTiles);

        suppressVisibleMaskPaint(spr);
        spr.texture = safeMaskTexture(want);
        if (!spr.texture?.orig) {
          try {
            spr.texture = safeMaskTexture(null);
          } catch (err) {
            logger.debug("FXMaster:", err);
          }
        }
        if (!spr.texture?.orig) continue;
        try {
          spr.width = cssW;
          spr.height = cssH;
        } catch (err) {
          logger.debug("FXMaster:", err);
        }
        try {
          applyMaskSpriteTransform(cont, spr);
        } catch (err) {
          logger.debug("FXMaster:", err);
        }
        if (cont.mask !== spr) {
          try {
            cont.mask = spr;
          } catch (err) {
            logger.debug("FXMaster:", err);
          }
        }
      }
    }
  }

  /**
   * Keep Scene particle bucket masks in sync with viewport size and camera transforms.
   */
  _sanitizeSceneMasks() {
    const hasSceneBuckets =
      (!!this._sceneBelowBase && !this._sceneBelowBase.destroyed) ||
      (!!this._sceneBelowCutout && !this._sceneBelowCutout.destroyed) ||
      (!!this._sceneAboveBase && !this._sceneAboveBase.destroyed) ||
      (!!this._sceneAboveCutout && !this._sceneAboveCutout.destroyed);

    if (!hasSceneBuckets) return;

    const { cssW, cssH } = getCssViewportMetrics();

    const updateBucketMask = (bucket, spr) => {
      if (!bucket || bucket.destroyed || !spr || spr.destroyed) return;
      suppressVisibleMaskPaint(spr);

      if (!spr._fxmMaskEnabled || !isUsableParticleMaskTexture(spr.texture)) {
        disableParticleMask(bucket, spr);
        return;
      }

      try {
        spr.width = cssW;
        spr.height = cssH;
      } catch (err) {
        logger.debug("FXMaster:", err);
        disableParticleMask(bucket, spr);
        return;
      }

      try {
        applyMaskSpriteTransform(bucket, spr);
      } catch (err) {
        logger.debug("FXMaster:", err);
      }

      if (bucket.mask !== spr) {
        try {
          bucket.mask = spr;
        } catch (err) {
          logger.debug("FXMaster:", err);
        }
      }
    };

    updateBucketMask(this._sceneBelowBase, this._sceneBelowBaseMask);
    updateBucketMask(this._sceneBelowCutout, this._sceneBelowCutoutMask);
    updateBucketMask(this._sceneAboveBase, this._sceneAboveBaseMask);
    updateBucketMask(this._sceneAboveCutout, this._sceneAboveCutoutMask);

    const updateSceneRuntimeMask = (fx) => {
      if (!fx || fx.destroyed) return;
      const container = fx.__fxmSceneContainer ?? null;
      const maskSprite = fx.__fxmSceneMaskSprite ?? null;
      if (!container || container.destroyed || !maskSprite || maskSprite.destroyed) return;
      this._applySceneMaskToContainer(container, maskSprite, {
        belowTokens: !!fx.__fxmBelowTokens,
        belowTiles: !!fx.__fxmBelowTiles,
        belowForeground: !!fx.__fxmBelowForeground,
      });
    };

    for (const fx of this.particleEffects.values()) updateSceneRuntimeMask(fx);
    for (const fx of this._dyingSceneEffects) updateSceneRuntimeMask(fx);
  }

  _onCameraChange() {
    if (!canvas?.scene) return;

    const M = this._currentCameraMatrix ?? snappedStageMatrix();

    try {
      if (hasActiveRadialRestrictWeatherTilesForMask("particles", { includeOffscreen: true })) {
        this._weatherOcclusionTilePresence = null;
        syncActiveRadialRestrictWeatherTileMasksForCamera("particles", { includeOffscreen: true });
        this._updateOcclusionGates();
      }
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    /**
     * Scene suppression is sampled later in the same low-priority animation callback after Foundry applies primary and perception state. A second camera and surface check during the same pan frame is redundant.
     */

    try {
      const { anyBelowTokens, anyBelowTiles } = this._collectBelowObjectCoverageNeeds();
      if (anyBelowTokens || anyBelowTiles) {
        const coverageMatrix = anyBelowTiles ? rawStageMatrix() : M;
        SceneMaskManager.instance.refreshTokensSync?.();
        this._tokensDirty = true;
        this._lastBelowObjectCoverageMatrix = coverageMatrix
          ? {
              a: coverageMatrix.a,
              b: coverageMatrix.b,
              c: coverageMatrix.c,
              d: coverageMatrix.d,
              tx: coverageMatrix.tx,
              ty: coverageMatrix.ty,
            }
          : null;
        this._lastBelowTokenCoverageSignature = anyBelowTokens ? buildBelowTokenMaskCoverageSignature() : null;
        this._lastBelowTileCoverageSignature = anyBelowTiles ? buildBelowTileMaskCoverageSignature() : null;
      } else {
        this._lastBelowObjectCoverageMatrix = null;
        this._lastBelowTokenCoverageSignature = null;
        this._lastBelowTileCoverageSignature = null;
      }
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    if (!this.regionEffects?.size) return;

    if (!cameraMatrixChanged(M, this._lastRegionMaskMatrix)) return;

    this._lastRegionMaskMatrix = { a: M.a, b: M.b, c: M.c, d: M.d, tx: M.tx, ty: M.ty };

    this.forceRegionMaskRefreshAll();
  }
}
