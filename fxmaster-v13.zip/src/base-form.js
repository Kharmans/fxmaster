import { getDialogColors } from "./utils.js";
import { ALL_LEVELS_SELECTION, packageId } from "./constants.js";
import { logger } from "./logger.js";
import { updateCompassDirectionOutput, wireCompassDirectionOutputs } from "./common/compass-direction.js";
import { formatRangeOutputValue, updateMinuteLabelOutput, wireMinuteLabelOutputs } from "./common/parameter-label-output.js";

/**
 * Abstract FormApplication base for shared FXMaster form behavior.
 *
 * - Handles collapsible elements.
 * - Mirrors range slider changes into the adjacent text output.
 * - Handles submit-button disabled state.
 *
 * @extends FormApplication
 * @abstract
 * @interface
 *
 * @param {Object} object Target data structure updated by the form.
 * @param {FormApplicationOptions} [options] Additional rendering options for the sheet.
 */

const Base = foundry.applications.api.HandlebarsApplicationMixin(foundry.applications.api.ApplicationV2);

export class FXMasterBaseFormV2 extends Base {
  static DEFAULT_OPTIONS = {
    actions: {
      toggleFilter: FXMasterBaseFormV2.toggleFilter,
      toggleCollapse: FXMasterBaseFormV2.toggleCollapse,
    },
  };

  static FXMASTER_DETACHED_WINDOW_FIT = false;

  /**
   * Foundry can finish an async ApplicationV2 render after a scene switch has already detached the window element. In that race, the core position update tries to read element.offsetWidth from null. Treat that case as a no-op instead of surfacing an unhandled render rejection.
   *
   * @param {object} [position]
   * @returns {object}
   */
  setPosition(position = {}) {
    const getElement = () => this.element?.[0] ?? this.element ?? null;
    const isDetached = () => {
      const element = getElement();
      return !element || element.isConnected === false;
    };
    const persistPosition = (value) => {
      this._persistPositionFlag(value ?? this.position ?? null);
      return value;
    };
    const handlePositionError = (err) => {
      const message = String(err?.message ?? "");
      if (message.includes("offsetWidth") && isDetached()) {
        logger.debug("FXMaster:", err);
        return this.position ?? {};
      }
      throw err;
    };

    try {
      if (isDetached()) return this.position ?? {};
      const result = super.setPosition(position);
      if (result && typeof result.then === "function") return result.then(persistPosition).catch(handlePositionError);
      return persistPosition(result ?? this.position ?? {});
    } catch (err) {
      return handlePositionError(err);
    }
  }

  /**
   * Return the user flag key used to persist this window's position.
   *
   * @returns {string|null}
   */
  _getPositionFlagKey() {
    return this.constructor.FXMASTER_POSITION_FLAG ?? null;
  }

  /**
   * Persist a finite ApplicationV2 position to the current user's FXMaster flags.
   *
   * @param {object|null|undefined} position
   * @returns {void}
   */
  _persistPositionFlag(position) {
    const key = this._getPositionFlagKey();
    if (!key || !position || this._fxmShouldSkipPositionPersistence()) return;

    const next = {};
    if (Number.isFinite(position.top)) next.top = position.top;
    if (Number.isFinite(position.left)) next.left = position.left;
    if (Number.isFinite(position.width)) next.width = position.width;
    if (!Object.keys(next).length) return;

    try {
      game.user.setFlag(packageId, key, next);
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
  }

  /**
   * Return whether a form event came from a color control.
   *
   * @param {Event|null|undefined} event
   * @returns {boolean}
   */
  static _fxmIsColorControlEvent(event) {
    const target = event?.target ?? null;
    if (!target) return false;
    const tag = String(target?.tagName ?? "").toLowerCase();
    if (tag === "color-picker") return true;
    if (target?.closest?.("color-picker")) return true;
    const type = String(target?.type ?? target?.getAttribute?.("type") ?? "").toLowerCase();
    return type === "color" && !!target?.closest?.(".fxmaster-input-color");
  }

  /**
   * Wire color controls with deferred picker commits.
   *
   * @param {HTMLElement} element Root element to search for color controls.
   * @param {Function} updateFn Update function called for committed changes.
   */
  wireColorInputs(element = this.element, updateFn = this.constructor.actions?.updateParam) {
    if (!element || !updateFn) return;

    try {
      this._fxmColorInputAbort?.abort?.();
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    const ac = new AbortController();
    this._fxmColorInputAbort = ac;
    const opts = { signal: ac.signal };
    const colorCommitTimers = new Map();

    const stopColorInputEvent = (event) => {
      event?.stopPropagation?.();
      event?.stopImmediatePropagation?.();
    };

    const invoke = (event, control) => {
      try {
        updateFn.call(this, event?.target ? event : { target: control }, control);
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
    };

    const currentControlValue = (control) => String(control?.value ?? control?.getAttribute?.("value") ?? "");

    const clearColorCommitTimer = (control) => {
      const entry = colorCommitTimers.get(control);
      if (!entry) return;
      entry.win.clearTimeout(entry.timer);
      colorCommitTimers.delete(control);
    };

    ac.signal.addEventListener(
      "abort",
      () => {
        for (const { timer, win } of colorCommitTimers.values()) win.clearTimeout(timer);
        colorCommitTimers.clear();
      },
      { once: true },
    );

    element.addEventListener(
      "input",
      (event) => {
        if (this.constructor._fxmIsColorControlEvent(event)) stopColorInputEvent(event);
      },
      { ...opts, capture: true },
    );

    const commitColorControl = (event, control) => {
      clearColorCommitTimer(control);
      if (!control?.isConnected) return;

      const value = currentControlValue(control);
      if (control.dataset.fxmColorCommittedValue === value) return;

      control.dataset.fxmColorCommittedValue = value;
      invoke(event, control);
    };

    const scheduleColorCommit = (event, control, delay = 500) => {
      if (!control?.name) return;
      if (control.dataset.fxmColorCommittedValue === currentControlValue(control)) return;

      const win = control.ownerDocument?.defaultView ?? globalThis;
      clearColorCommitTimer(control);
      const timer = win.setTimeout(() => commitColorControl(event, control), delay);
      colorCommitTimers.set(control, { timer, win });
    };

    element.querySelectorAll('.fxmaster-input-color input[type="checkbox"]').forEach((cb) => {
      cb.addEventListener("change", (event) => invoke(event, cb), opts);
    });

    const wireCommittedInput = (input) => {
      if (!input || input.closest?.("color-picker")) return;
      input.dataset.fxmColorCommittedValue = currentControlValue(input);
      input.addEventListener("change", (event) => {
        if (input.type === "color") scheduleColorCommit(event, input);
        else invoke(event, input);
      }, opts);
      input.addEventListener("focusout", (event) => {
        if (input.type === "color") scheduleColorCommit(event, input, 250);
      }, opts);
      input.addEventListener("keydown", (event) => {
        if (event.key === "Enter") commitColorControl(event, input);
      }, opts);
    };

    element.querySelectorAll('.fxmaster-input-color input[type="color"]').forEach(wireCommittedInput);
    element.querySelectorAll('.fxmaster-input-color input[type="text"]').forEach(wireCommittedInput);
    element.querySelectorAll(".fxmaster-input-color color-picker").forEach((picker) => {
      picker.dataset.fxmColorCommittedValue = currentControlValue(picker);
      picker.addEventListener("change", (event) => {
        if (event.target !== picker) return;
        scheduleColorCommit(event, picker);
      }, opts);
      picker.addEventListener("focusout", (event) => scheduleColorCommit(event, picker, 250), opts);
      picker.addEventListener("keydown", (event) => {
        if (event.key === "Enter") commitColorControl(event, picker);
      }, opts);
    });
  }

  /**
   * Wire multi-select widgets so selection changes reliably trigger updateParam.
   *
   * @param {HTMLElement} element  The root element to listen on. Defaults to the form element.
   * @param {Function} updateFn    The update function to call.
   */
  wireMultiSelectInputs(element = this.element, updateFn = this.constructor.actions?.updateParam) {
    if (!element || !updateFn) return;

    try {
      this._fxmMultiSelectAbort?.abort?.();
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    const ac = new AbortController();
    this._fxmMultiSelectAbort = ac;

    const invoke = (event, control) => {
      try {
        updateFn.call(this, event, control);
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
    };

    const queueInvoke = (event, control) => {
      try {
        requestAnimationFrame(() => invoke(event, control));
      } catch {
        invoke(event, control);
      }
    };

    const findControl = (target) => {
      if (!target) return null;
      const ms = target.closest?.("multi-select[name]");
      if (ms) return ms;
      const sel = target.closest?.("select[multiple][name]");
      return sel ?? null;
    };

    const isInternalMultiSelectEvent = (event, control) => {
      if (!control?.matches?.("multi-select[name]")) return false;
      return event?.target !== control;
    };

    const applyQuickSelection = (button) => {
      const wrapper = button?.closest?.(".fxmaster-input-multi");
      const control = wrapper?.querySelector?.("multi-select[name], select[multiple][name]");
      if (!control) return;

      let values = [];
      try {
        values = JSON.parse(decodeURIComponent(String(button.dataset.fxmMultiValues ?? "")));
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
      if (!Array.isArray(values)) return;

      if (control.matches?.("multi-select")) {
        try {
          control.value = values.map(String);
        } catch (err) {
          logger.debug("FXMaster:", err);
        }
      }

      const select = control.matches?.("select[multiple]") ? control : control.querySelector?.("select[multiple]");
      if (select) {
        const selected = new Set(values.map(String));
        for (const option of select.options ?? []) option.selected = selected.has(String(option.value));
      }

      control.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
    };

    element.addEventListener(
      "click",
      (event) => {
        const button = event.target?.closest?.(".fxmaster-multi-select-preset[data-fxm-multi-values]");
        if (!button || !element.contains(button)) return;
        event.preventDefault();
        applyQuickSelection(button);
      },
      { signal: ac.signal },
    );

    element.addEventListener(
      "change",
      (event) => {
        const control = findControl(event.target);
        if (!control || isInternalMultiSelectEvent(event, control)) return;
        queueInvoke(event, control);
      },
      { capture: true, signal: ac.signal },
    );

    element.addEventListener(
      "input",
      (event) => {
        const target = event.target;
        if (!target?.matches?.("multi-select, select[multiple]")) return;
        const control = findControl(target);
        if (!control || isInternalMultiSelectEvent(event, control)) return;
        queueInvoke(event, control);
      },
      { capture: true, signal: ac.signal },
    );
  }

  /**
   * Wire single-select widgets so selection changes trigger updateParam immediately.
   *
   * @param {HTMLElement} element  The root element to listen on. Defaults to the form element.
   * @param {Function} updateFn    The update function to call.
   */
  wireSelectInputs(element = this.element, updateFn = this.constructor.actions?.updateParam) {
    if (!element || !updateFn) return;

    try {
      this._fxmSelectAbort?.abort?.();
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    const ac = new AbortController();
    this._fxmSelectAbort = ac;

    const invoke = (event, control) => {
      try {
        updateFn.call(this, event, control);
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
    };

    const resolveControl = (target) => {
      const control = target?.closest?.("select[name]:not([multiple])") ?? null;
      if (!control || control.closest?.("multi-select")) return null;
      return control;
    };

    for (const eventName of ["change", "input"]) {
      element.addEventListener(
        eventName,
        (event) => {
          const control = resolveControl(event.target);
          if (!control || !element.contains(control)) return;
          invoke(event, control);
        },
        { capture: true, signal: ac.signal },
      );
    }
  }


  /**
   * Build a flat options object containing each parameter's authored default value.
   *
   * @param {object|null|undefined} effectDB
   * @returns {object}
   */
  static getDefaultOptions(effectDB) {
    const options = {};
    for (const [key, param] of Object.entries(effectDB?.parameters ?? {})) {
      if (!param || typeof param !== "object" || param.value === undefined) continue;
      options[key] = foundry.utils.deepClone(param.value);
    }
    return options;
  }

  /**
   * Wire a small right-click reset menu to power-toggle buttons.
   *
   * @param {HTMLElement|null|undefined} element
   * @param {{ selector: string, onReset: Function, labelKey?: string }} options
   * @returns {void}
   */
  wirePowerToggleResetMenu(
    element = this.element,
    { selector, onReset, labelKey = "FXMASTER.Common.ResetEffectDefaults" } = {},
  ) {
    if (!element || !selector || typeof onReset !== "function") return;

    try {
      this._fxmPowerToggleResetAbort?.abort?.();
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    const ac = new AbortController();
    this._fxmPowerToggleResetAbort = ac;

    element.addEventListener(
      "contextmenu",
      (event) => {
        const button = event.target?.closest?.(selector);
        if (!button || !element.contains(button)) return;

        const type = button.dataset?.filter;
        if (!type) return;

        event.preventDefault();
        event.stopPropagation();

        this._openPowerToggleResetMenu(button, {
          labelKey,
          onReset: async () => onReset.call(this, type, button),
        });
      },
      { capture: true, signal: ac.signal },
    );
  }

  /**
   * Close and discard the current power-toggle context menu, if any.
   * @returns {void}
   */
  _closePowerToggleResetMenu() {
    try {
      this._fxmPowerToggleMenuAbort?.abort?.();
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
    this._fxmPowerToggleMenuAbort = null;

    try {
      this._fxmPowerToggleContextMenu?.remove?.();
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
    this._fxmPowerToggleContextMenu = null;
  }

  /**
   * Open a compact context menu anchored to a power-toggle button.
   *
   * @param {HTMLElement} button
   * @param {{ labelKey?: string, onReset?: Function }} options
   * @returns {void}
   */
  _openPowerToggleResetMenu(button, { labelKey = "FXMASTER.Common.ResetEffectDefaults", onReset = null } = {}) {
    this._closePowerToggleResetMenu();

    const doc = button.ownerDocument ?? globalThis.document;
    const win = doc.defaultView ?? globalThis.window;

    const menu = doc.createElement("div");
    menu.className = "fxmaster-toggle-context-menu";
    menu.setAttribute("role", "menu");

    const action = doc.createElement("button");
    action.type = "button";
    action.className = "fxmaster-toggle-context-menu-action";
    action.setAttribute("role", "menuitem");
    action.innerHTML = `<i class="fa-solid fa-arrow-rotate-left"></i><span>${game.i18n.localize(labelKey)}</span>`;
    menu.appendChild(action);

    doc.body.appendChild(menu);
    this._fxmPowerToggleContextMenu = menu;

    const positionMenu = () => {
      const rect = button.getBoundingClientRect();
      const menuRect = menu.getBoundingClientRect();
      const margin = 6;
      const gap = 4;
      const maxLeft = win.innerWidth - menuRect.width - margin;

      const preferredLeft = rect.right + gap;
      const fallbackLeft = rect.left;
      const leftSource = preferredLeft <= maxLeft ? preferredLeft : fallbackLeft;
      const left = Math.max(margin, Math.min(leftSource, maxLeft));
      const top = Math.max(margin, Math.min(rect.bottom + gap, win.innerHeight - menuRect.height - margin));
      menu.style.left = `${Math.round(left)}px`;
      menu.style.top = `${Math.round(top)}px`;
    };

    positionMenu();

    const ac = new AbortController();
    this._fxmPowerToggleMenuAbort = ac;

    action.addEventListener(
      "click",
      async (event) => {
        event.preventDefault();
        event.stopPropagation();
        this._closePowerToggleResetMenu();
        try {
          await onReset?.();
        } catch (err) {
          logger.debug("FXMaster:", err);
        }
      },
      { signal: ac.signal },
    );

    requestAnimationFrame(() => {
      if (!menu.isConnected || ac.signal.aborted) return;

      document.addEventListener(
        "pointerdown",
        (event) => {
          if (!menu.contains(event.target)) this._closePowerToggleResetMenu();
        },
        { capture: true, signal: ac.signal },
      );

      document.addEventListener(
        "keydown",
        (event) => {
          if (event.key === "Escape") this._closePowerToggleResetMenu();
        },
        { capture: true, signal: ac.signal },
      );
    });
  }

  /**
   * Update the textual output next to a range input.  Many parameter update handlers repeat the same code to update the <code>.range-value</code> element whenever a range slider is adjusted. This static helper encapsulates that behavior so it can be reused by management classes.
   *
   * @param {HTMLInputElement} input  The range input element that changed.
   */
  static updateRangeOutput(input) {
    if (!input || input.type !== "range") return;

    const outputRoot = input.closest?.("form") ?? input.ownerDocument ?? null;
    updateCompassDirectionOutput(input, outputRoot);
    updateMinuteLabelOutput(input, outputRoot);

    const dual = input.closest(".fxmaster-input-range-dual");
    if (dual) {
      const formatValue = (slider, rawValue) => {
        const decimalsAttr = Number(
          slider?.dataset?.decimals ?? slider?.closest?.(".fxmaster-input-range-dual")?.dataset?.decimals,
        );
        const stepText = String(slider?.step ?? "");
        const stepDecimals = stepText.includes(".") ? Math.max(0, stepText.length - stepText.indexOf(".") - 1) : 0;
        const decimals = Number.isFinite(decimalsAttr) ? decimalsAttr : stepDecimals;
        const value = Number(rawValue);
        if (!Number.isFinite(value)) return String(rawValue ?? "");
        return decimals > 0 ? value.toFixed(decimals) : String(Math.round(value));
      };

      const sliders = Array.from(dual.querySelectorAll('input[type="range"]'));
      const minSlider = dual.querySelector('input[type="range"][data-range-role="min"]') ?? sliders[0] ?? null;
      const maxSlider = dual.querySelector('input[type="range"][data-range-role="max"]') ?? sliders[1] ?? null;
      const minOutput = dual.querySelector(".range-value-min");
      const maxOutput = dual.querySelector(".range-value-max");
      if (minSlider && minOutput) minOutput.textContent = formatValue(minSlider, minSlider.value);
      if (maxSlider && maxOutput) maxOutput.textContent = formatValue(maxSlider, maxSlider.value);

      const min = Number(minSlider?.min ?? input.min ?? 0);
      const max = Number(maxSlider?.max ?? input.max ?? 1);
      const span = Math.max(1e-9, max - min);
      const minVal = Number(minSlider?.value ?? min);
      const maxVal = Number(maxSlider?.value ?? max);
      dual.style.setProperty("--range-start-pct", String(((minVal - min) / span) * 100));
      dual.style.setProperty("--range-end-pct", String(((maxVal - min) / span) * 100));
      return;
    }

    const container = input.closest(".fxmaster-input-range");
    const output = container?.querySelector(".range-value");
    if (output) output.textContent = formatRangeOutputValue(input, input.value);
  }

  /**
   * Apply or remove the FXMaster highlight styling on a single control element.
   *
   * @param {HTMLElement|null|undefined} element
   * @param {boolean} isHighlighted
   * @returns {void}
   */
  static setControlHighlight(element, isHighlighted) {
    if (!element) return;
    if (isHighlighted) {
      element.style?.setProperty("background-color", "var(--color-warm-2)");
      element.style?.setProperty("border-color", "var(--color-warm-3)");
      return;
    }
    element.style?.removeProperty("background-color");
    element.style?.removeProperty("border-color");
  }

  /**
   * Set or remove the visual highlight on every matching tool button in the UI.
   *
   * @param {string} toolName
   * @param {boolean} isHighlighted
   * @returns {void}
   */
  static setToolButtonHighlight(toolName, isHighlighted) {
    for (const button of document.querySelectorAll(`[data-tool="${toolName}"]`)) {
      this.setControlHighlight(button, isHighlighted);
    }
  }

  /**
   * Set or remove the visual highlight on the parent Effects scene-control button.
   *
   * @param {boolean} isHighlighted
   * @returns {void}
   */
  static setSceneEffectsControlHighlight(isHighlighted) {
    const selectors = [
      '#scene-controls-layers button.control[data-control="effects"]',
      '#scene-controls-layers button[data-action="control"][data-control="effects"]',
      'button[data-action="control"][data-control="effects"]',
      'li.scene-control[data-control="effects"] button',
      'li.scene-control[data-control="effects"]',
    ];

    const seen = new Set();

    for (const selector of selectors) {
      for (const match of document.querySelectorAll(selector)) {
        const element = match?.matches?.("li") ? match.querySelector?.("button") ?? match : match;
        if (!element || seen.has(element)) continue;
        seen.add(element);
        this.setControlHighlight(element, isHighlighted);
      }
    }
  }
  static toggleFilter(event, button) {
    event.stopPropagation();
    const type = button.dataset.filter;
    const isEnabled = button.classList.toggle("enabled");
    this.updateEnabledState(type, isEnabled);
  }

  static toggleCollapse(event, element) {
    if (event.target.closest("[data-action='toggleFilter']")) return;
    element.classList.toggle("open");
  }

  static gatherFilterOptions(filterDB, form) {
    const label = filterDB.label;
    const options = {};

    for (const [key, param] of Object.entries(filterDB.parameters)) {
      if (param?.type === "filter-actions") continue;
      const base = `${label}_${key}`;
      const input = form.querySelector(`[name="${base}"]`);
      const apply = form.querySelector(`[name="${base}_apply"]`);

      if (param.type === "range-dual") {
        const minInput = form.querySelector(`[name="${base}_min"]`);
        const maxInput = form.querySelector(`[name="${base}_max"]`);
        if (!minInput && !maxInput) continue;

        const fallbackMin = Number(param.value?.min ?? param.min ?? 0);
        const fallbackMax = Number(param.value?.max ?? param.max ?? 1);
        let minValue = Number.parseFloat(minInput?.value ?? `${fallbackMin}`);
        let maxValue = Number.parseFloat(maxInput?.value ?? `${fallbackMax}`);

        if (!Number.isFinite(minValue)) minValue = fallbackMin;
        if (!Number.isFinite(maxValue)) maxValue = fallbackMax;
        if (minValue > maxValue) [minValue, maxValue] = [maxValue, minValue];

        options[key] = { min: minValue, max: maxValue };
        continue;
      }

      if (!input) continue;

      if (param.type === "color") {
        options[key] = {
          apply: Boolean(apply?.checked),
          value: input.value ?? input.getAttribute?.("value") ?? param.value?.value ?? "#000000",
        };
        continue;
      }

      if (param.type === "multi-select" || param.type === "scene-levels") {
        const multi =
          form.querySelector(`multi-select[name="${base}"]`) ||
          form.querySelector(`multi-select[data-name="${base}"]`) ||
          null;

        /** @type {string[]} */
        let values = [];

        let hasAuthoritativeMultiValue = false;

        if (multi) {
          try {
            const mv = multi.value;
            if (mv instanceof Set) {
              hasAuthoritativeMultiValue = true;
              values = Array.from(mv);
            } else if (Array.isArray(mv)) {
              hasAuthoritativeMultiValue = true;
              values = mv;
            } else if (mv && typeof mv !== "string" && typeof mv[Symbol.iterator] === "function") {
              hasAuthoritativeMultiValue = true;
              values = Array.from(mv);
            } else if (typeof mv === "string" && mv.trim()) {
              hasAuthoritativeMultiValue = true;
              const s = mv.trim();
              try {
                const parsed = JSON.parse(s);
                if (Array.isArray(parsed)) values = parsed;
                else values = s.split(",");
              } catch {
                values = s.split(",");
              }
            }
          } catch (err) {
            logger.debug("FXMaster:", err);
          }

          if (!values.length && !hasAuthoritativeMultiValue) {
            try {
              const innerSelect =
                multi.querySelector(`select[name="${base}"]`) || multi.querySelector("select[multiple]") || null;
              if (innerSelect?.multiple) {
                hasAuthoritativeMultiValue = true;
                values = Array.from(innerSelect.selectedOptions)
                  .map((o) => o.value)
                  .filter(Boolean);
              }
            } catch (err) {
              logger.debug("FXMaster:", err);
            }
          }

          if (!values.length && !hasAuthoritativeMultiValue) {
            try {
              const checkedOptions = Array.from(multi.querySelectorAll("option:checked"));
              if (checkedOptions.length) {
                hasAuthoritativeMultiValue = true;
                values = checkedOptions.map((option) => option.value).filter(Boolean);
              }
            } catch (err) {
              logger.debug("FXMaster:", err);
            }
          }

          if (!values.length && !hasAuthoritativeMultiValue) {
            try {
              const tags = Array.from(multi.querySelectorAll(".tag"));
              if (tags.length) hasAuthoritativeMultiValue = true;
              const allLevelsLabel = String(game?.i18n?.localize?.("FXMASTER.Params.AllLevels") ?? "All Levels");
              const hasAllLevelsTag = tags.some((tag) => tag.textContent?.trim() === allLevelsLabel);
              if (hasAllLevelsTag) values = [ALL_LEVELS_SELECTION];
              else {
                values = tags
                  .map((t) => t.dataset.key ?? t.dataset.value ?? t.dataset.id ?? t.dataset.tag ?? t.dataset.option)
                  .filter(Boolean);
                if (
                  !values.length &&
                  param.type === "scene-levels" &&
                  multi.querySelector(".tags, .tag-list, .selected, .selected-tags")
                ) {
                  hasAuthoritativeMultiValue = true;
                  values = [ALL_LEVELS_SELECTION];
                }
              }
            } catch (err) {
              logger.debug("FXMaster:", err);
            }
          }

          if (!values.length && !hasAuthoritativeMultiValue && param.type !== "scene-levels") {
            try {
              const mv = multi.value ?? multi.getAttribute?.("value");
              if (mv instanceof Set) values = Array.from(mv);
              else if (Array.isArray(mv)) values = mv;
              else if (typeof mv === "string" && mv.trim()) {
                const s = mv.trim();
                try {
                  const parsed = JSON.parse(s);
                  if (Array.isArray(parsed)) values = parsed;
                  else values = s.split(",");
                } catch {
                  values = s.split(",");
                }
              }
            } catch (err) {
              logger.debug("FXMaster:", err);
            }
          }

          if (!values.length && !hasAuthoritativeMultiValue && param.type !== "scene-levels") {
            try {
              const hidden =
                multi.querySelector(`input[type="hidden"][name="${base}"]`) ||
                multi.querySelector('input[type="hidden"]') ||
                null;
              const hv = hidden?.value;
              if (typeof hv === "string" && hv.trim()) {
                const s = hv.trim();
                try {
                  const parsed = JSON.parse(s);
                  if (Array.isArray(parsed)) values = parsed;
                  else values = s.split(",");
                } catch {
                  values = s.split(",");
                }
              }
            } catch (err) {
              logger.debug("FXMaster:", err);
            }
          }
        }

        if (!values.length) {
          const sel = form.querySelector(`select[name="${base}"]`);
          if (sel?.multiple)
            values = Array.from(sel.selectedOptions)
              .map((o) => o.value)
              .filter(Boolean);
        }

        if (!values.length && param.type !== "scene-levels" && param.allowEmpty !== true) {
          values = Array.isArray(param.value)
            ? param.value
            : param.value != null && param.value !== ""
            ? [param.value]
            : [];
        }

        values = Array.from(new Set(values.map(String).filter((v) => v != null && v !== "")));
        if (param.type === "scene-levels") {
          let allLevelsSelected = values.includes(ALL_LEVELS_SELECTION);
          if (!allLevelsSelected && multi) {
            try {
              const allLevelsLabel = String(game?.i18n?.localize?.("FXMASTER.Params.AllLevels") ?? "All Levels");
              allLevelsSelected = !!multi.querySelector(`option[value="${ALL_LEVELS_SELECTION}"]:checked`);
              if (!allLevelsSelected) {
                allLevelsSelected = Array.from(
                  multi.querySelectorAll(
                    ".tag[data-key], .tag[data-value], .tag[data-id], .tag[data-tag], .tag[data-option], .tag",
                  ),
                ).some((tag) => {
                  const value =
                    tag.dataset.key ??
                    tag.dataset.value ??
                    tag.dataset.id ??
                    tag.dataset.tag ??
                    tag.dataset.option ??
                    tag.textContent?.trim();
                  return value === ALL_LEVELS_SELECTION || value === allLevelsLabel;
                });
              }
            } catch (err) {
              logger.debug("FXMaster:", err);
            }
          }
          options[key] = allLevelsSelected ? [] : values.filter((value) => value !== ALL_LEVELS_SELECTION);
        } else {
          options[key] = values;
        }
        continue;
      }

      if (param.type === "checkbox") {
        options[key] = Boolean(input.checked);
        continue;
      }

      if (param.type === "number-infinity") {
        const raw = String(input.value ?? "").trim();
        if (/^(?:∞|inf(?:inity)?|infinite)$/i.test(raw)) options[key] = "Infinity";
        else {
          const numeric = Number.parseFloat(raw);
          options[key] = Number.isFinite(numeric) ? numeric : "Infinity";
        }
        continue;
      }

      if (input.type === "number" || param.type === "range") {
        options[key] = parseFloat(input.value);
        continue;
      }

      options[key] = input.value;
    }

    return options;
  }

  /**
   * Keep paired dual-range slider values ordered and clamped.
   *
   * @param {HTMLInputElement|null|undefined} input
   * @returns {void}
   */
  static syncDualRangeInput(input) {
    if (!input || input.type !== "range") return;

    const container = input.closest(".fxmaster-input-range-dual");
    if (!container) return;

    const minSlider = container.querySelector('input[type="range"][data-range-role="min"]');
    const maxSlider = container.querySelector('input[type="range"][data-range-role="max"]');
    if (!minSlider || !maxSlider) return;

    let minValue = Number.parseFloat(minSlider.value || "0");
    let maxValue = Number.parseFloat(maxSlider.value || "0");
    if (!Number.isFinite(minValue) || !Number.isFinite(maxValue)) return;

    if (input === minSlider && minValue > maxValue) {
      maxValue = minValue;
      maxSlider.value = String(maxValue);
    } else if (input === maxSlider && maxValue < minValue) {
      minValue = maxValue;
      minSlider.value = String(minValue);
    }
  }

  _onRender(options) {
    super._onRender?.(options);
    this._fxmUpdateDetachedWindowFit();
    this.animateTitleBar(this);
    try {
      this._fxmWireConditionalVisibility?.();
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
    try {
      this._fxmWireSynchronizedDirectionControls?.();
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
    try {
      this.applyTooltipDirection(this.element);
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
    try {
      this._wireCompassDirectionOutputs?.(this.element);
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
    try {
      this._wireMinuteLabelOutputs?.(this.element);
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
  }

  /**
   * Initialize live eight-point compass suffixes for direction parameters.
   *
   * @param {HTMLElement|null|undefined} root
   * @returns {void}
   */
  _wireCompassDirectionOutputs(root = this.element) {
    try {
      this._fxmCompassDirectionAbort?.abort?.();
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    const element = root?.[0] ?? root ?? null;
    if (!element) return;

    const ac = new AbortController();
    this._fxmCompassDirectionAbort = ac;
    wireCompassDirectionOutputs(element, { signal: ac.signal });
  }

  /**
   * Initialize live compact minute suffixes for duration parameters.
   *
   * @param {HTMLElement|null|undefined} root
   * @returns {void}
   */
  _wireMinuteLabelOutputs(root = this.element) {
    try {
      this._fxmMinuteLabelAbort?.abort?.();
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    const element = root?.[0] ?? root ?? null;
    if (!element) return;

    const ac = new AbortController();
    this._fxmMinuteLabelAbort = ac;
    wireMinuteLabelOutputs(element, { signal: ac.signal });
  }

  /**
   * Apply the configured FXMaster tooltip direction to every tooltip element in a rendered application.
   *
   * @param {HTMLElement|null|undefined} root
   * @returns {void}
   */
  applyTooltipDirection(root = this.element) {
    if (!root) return;

    const configuredDirection = String(game?.settings?.get?.(packageId, "tooltipDirection") ?? "UP")
      .trim()
      .toUpperCase();
    const direction = ["UP", "DOWN", "LEFT", "RIGHT"].includes(configuredDirection) ? configuredDirection : "UP";

    for (const element of root.querySelectorAll?.("[data-tooltip]") ?? []) {
      element.dataset.tooltipDirection = direction;
    }
  }

  /**
   * Refresh synchronized-direction lock state for direction controls in an already-rendered parameter section.
   *
   * @param {HTMLElement|null|undefined} root
   * @param {object|null|undefined} effectDef
   * @param {object} [options={}]
   * @returns {void}
   */
  static refreshSynchronizedDirectionControls(root, effectDef, options = {}) {
    const element = root?.[0] ?? root ?? null;
    if (!element || !effectDef) return;

    const context = this._fxmSynchronizedDirectionContext(options);
    const enabled = CONFIG.fxmaster?.synchronizedDirectionOptionEnabled?.(options) ?? false;
    const source = CONFIG.fxmaster?.getSynchronizedDirectionSourceLabel?.("", context) ?? "";
    const locked = enabled && !!source;
    const tooltip = locked
      ? game.i18n.format("FXMASTER.ParamTooltips.SynchronizedDirectionControlledBy", { source })
      : "";
    const direction = String(game?.settings?.get?.(packageId, "tooltipDirection") ?? "UP").trim().toUpperCase();
    const tooltipDirection = ["UP", "DOWN", "LEFT", "RIGHT"].includes(direction) ? direction : "UP";

    const parameters = effectDef.parameters ?? {};
    const directionParameters = Object.keys(parameters).filter((name) =>
      ["direction", "flowDirection", "waveDirection"].includes(String(name)),
    );

    for (const parameterName of directionParameters) {
      const suffix = `_${parameterName}`;
      const controls = [...(element.querySelectorAll?.("[name]") ?? [])].filter((control) => {
        if (control.type === "hidden") return false;
        return String(control.name ?? "").endsWith(suffix);
      });

      for (const control of controls) {
        const name = String(control.name ?? "");
        if (!name) continue;

        const hiddenCandidates = [...(element.querySelectorAll?.("input[type=\"hidden\"][name]") ?? [])].filter(
          (candidate) => String(candidate.name ?? "") === name,
        );
        let syncedHidden = hiddenCandidates.find((candidate) => candidate.dataset.fxmSyncDirectionHidden === name)
          ?? hiddenCandidates[0]
          ?? null;

        if (locked) {
          control.disabled = true;
          control.setAttribute("aria-disabled", "true");
          control.dataset.tooltip = tooltip;
          control.dataset.tooltipDirection = tooltipDirection;
          control.dataset.fxmSyncDirectionTooltip = "true";

          if (!syncedHidden) {
            syncedHidden = document.createElement("input");
            syncedHidden.type = "hidden";
            syncedHidden.name = name;
            syncedHidden.dataset.fxmSyncDirectionHidden = name;
            control.insertAdjacentElement("afterend", syncedHidden);
          }
          syncedHidden.value = String(control.value ?? "");
        } else {
          control.disabled = false;
          control.removeAttribute("aria-disabled");
          if (control.dataset.fxmSyncDirectionTooltip === "true") {
            delete control.dataset.tooltip;
            delete control.dataset.tooltipDirection;
            delete control.dataset.fxmSyncDirectionTooltip;
          }
          for (const hidden of hiddenCandidates) hidden.remove?.();
        }
      }
    }
  }

  /**
   * Return whether the application is hosted in a Foundry V14 detached window.
   *
   * @returns {boolean}
   */
  _fxmIsDetachedHost() {
    const element = this.element?.[0] ?? this.element ?? null;
    const doc = element?.ownerDocument ?? null;
    return !!this.window?.windowId || !!doc?.body?.classList?.contains?.("detached");
  }

  /**
   * Return whether window position persistence should be skipped.
   *
   * @returns {boolean}
   */
  _fxmShouldSkipPositionPersistence() {
    return this._fxmSuspendPositionPersistence === true || this._fxmIsDetachedHost() || this._fxmDetachedHostActive === true;
  }

  /**
   * Return the browser window which owns the rendered application element.
   *
   * @returns {Window}
   */
  _fxmHostWindow() {
    const element = this.element?.[0] ?? this.element ?? null;
    return element?.ownerDocument?.defaultView ?? globalThis.window;
  }

  /**
   * Resize eligible applications to fill a Foundry V14 detached browser window.
   *
   * @returns {void}
   */
  _fxmUpdateDetachedWindowFit() {
    const element = this.element?.[0] ?? this.element ?? null;
    if (!element?.classList) return;

    const enabled = this.constructor.FXMASTER_DETACHED_WINDOW_FIT === true && this._fxmIsDetachedHost();
    if (!enabled) {
      this._fxmDisableDetachedWindowFit();
      return;
    }

    this._fxmDetachedHostActive = true;
    element.classList.add("fxmaster-detached-fit");
    const win = this._fxmHostWindow();

    if (this._fxmDetachedFitWindow !== win) {
      try {
        this._fxmDetachedFitAbort?.abort?.();
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
      const ac = new AbortController();
      this._fxmDetachedFitAbort = ac;
      this._fxmDetachedFitWindow = win;
      win.addEventListener("resize", () => this._fxmApplyDetachedWindowFit(), { passive: true, signal: ac.signal });
    }

    this._fxmApplyDetachedWindowFit();
  }

  /**
   * Apply the current detached browser-window dimensions to the application frame.
   *
   * @returns {void}
   */
  _fxmApplyDetachedWindowFit() {
    if (this.constructor.FXMASTER_DETACHED_WINDOW_FIT !== true || !this._fxmIsDetachedHost()) return;
    const win = this._fxmHostWindow();
    const width = Math.max(320, Math.floor(win?.innerWidth ?? 0));
    const height = Math.max(240, Math.floor(win?.innerHeight ?? 0));
    this._fxmSuspendPositionPersistence = true;
    try {
      this.setPosition?.({ top: 0, left: 0, width, height });
    } catch (err) {
      logger.debug("FXMaster:", err);
    } finally {
      this._fxmSuspendPositionPersistence = false;
    }
  }

  /**
   * Remove detached browser-window fit state.
   *
   * @returns {void}
   */
  _fxmDisableDetachedWindowFit() {
    const element = this.element?.[0] ?? this.element ?? null;
    element?.classList?.remove?.("fxmaster-detached-fit");
    try {
      this._fxmDetachedFitAbort?.abort?.();
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
    this._fxmDetachedFitAbort = null;
    this._fxmDetachedFitWindow = null;
  }

  /** @override */
  _onDetach(from, to) {
    super._onDetach?.(from, to);
    this._fxmUpdateDetachedWindowFit();
    this.animateTitleBar(this);
  }

  /** @override */
  _onAttach(from, to) {
    this._fxmDetachedHostActive = false;
    this._fxmDisableDetachedWindowFit();
    super._onAttach?.(from, to);
    this.animateTitleBar(this);
  }

  _onClose(...args) {
    this._fxmDisableDetachedWindowFit();
    try {
      const animation = this._fxmTitleBarAnimation;
      if (animation?.frame != null) animation.win?.cancelAnimationFrame?.(animation.frame);
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
    this._fxmTitleBarAnimation = null;
    try {
      this._fxmUnwireConditionalVisibility?.();
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
    try {
      this._fxmUnwireSynchronizedDirectionControls?.();
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
    try {
      this._fxmMultiSelectAbort?.abort?.();
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
    try {
      this._fxmSelectAbort?.abort?.();
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
    try {
      this._fxmColorInputAbort?.abort?.();
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
    try {
      this._fxmRangeBehaviorAbort?.abort?.();
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
    try {
      this._fxmPowerToggleResetAbort?.abort?.();
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
    try {
      this._fxmCompassDirectionAbort?.abort?.();
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
    this._closePowerToggleResetMenu?.();
    this._fxmColorInputAbort = null;
    this._fxmRangeBehaviorAbort = null;
    this._fxmPowerToggleResetAbort = null;
    this._fxmCompassDirectionAbort = null;
    return super._onClose?.(...args);
  }

  /**
   * Prevent wheel and keyboard adjustments on unfocused sliders, while keeping focused slider changes synchronized with the rendered output and backing data model.
   */
  _wireRangeWheelBehavior({ getScrollWrapper, onInput } = {}) {
    try {
      this._fxmRangeBehaviorAbort?.abort();
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
    this._fxmRangeBehaviorAbort = null;

    const root = this.element;
    if (!root) return;

    const content = root.querySelector(".window-content") ?? root;
    const getWrapper = getScrollWrapper ?? ((slider) => slider.closest(".window-content") ?? content);
    const ac = new AbortController();
    this._fxmRangeBehaviorAbort = ac;

    const doc = root.ownerDocument ?? globalThis.document;
    const isFocusedSlider = (slider) => slider && (doc.activeElement === slider || slider.matches?.(":focus"));
    const clampToStep = (slider, rawValue) => {
      const min = Number.parseFloat(slider.min);
      const max = Number.parseFloat(slider.max);
      const stepAttr = Number.parseFloat(slider.step);
      const hasMin = Number.isFinite(min);
      const hasMax = Number.isFinite(max);
      const step = Number.isFinite(stepAttr) && stepAttr > 0 ? stepAttr : 1;
      const base = hasMin ? min : 0;
      let next = Number.isFinite(rawValue) ? rawValue : Number.parseFloat(slider.value || "0") || 0;
      if (hasMin) next = Math.max(min, next);
      if (hasMax) next = Math.min(max, next);
      next = base + Math.round((next - base) / step) * step;
      if (hasMin) next = Math.max(min, next);
      if (hasMax) next = Math.min(max, next);
      const decimals = (() => {
        const source = slider.step && slider.step !== "any" ? slider.step : `${step}`;
        const idx = source.indexOf(".");
        return idx >= 0 ? Math.max(0, source.length - idx - 1) : 0;
      })();
      return decimals > 0 ? Number(next.toFixed(decimals)) : next;
    };
    const syncSlider = (slider, event = null) => {
      if (!slider) return;
      this.constructor.syncDualRangeInput(slider);
      this.constructor.updateRangeOutput(slider);
      onInput?.(event, slider);
    };
    const resolveScrollWrapper = (slider) => {
      const preferred = getWrapper(slider) ?? content;
      const isScrollable = (element) => {
        if (!element) return false;
        const { scrollHeight, clientHeight } = element;
        return scrollHeight > clientHeight + 1;
      };

      if (isScrollable(preferred)) return preferred;

      let current = preferred?.parentElement ?? null;
      while (current && current !== root) {
        if (isScrollable(current)) return current;
        current = current.parentElement;
      }

      return isScrollable(content) ? content : preferred;
    };
    const applySliderValue = (slider, nextValue, { dispatchChange = true } = {}) => {
      const next = clampToStep(slider, nextValue);
      const cur = Number.parseFloat(slider.value || "0");
      if (Number.isFinite(cur) && Math.abs(cur - next) <= 1e-9) {
        this.constructor.syncDualRangeInput(slider);
        this.constructor.updateRangeOutput(slider);
        return;
      }

      slider.value = String(next);
      this.constructor.syncDualRangeInput(slider);
      this.constructor.updateRangeOutput(slider);
      slider.dispatchEvent(new Event("input", { bubbles: true }));
      if (dispatchChange) slider.dispatchEvent(new Event("change", { bubbles: true }));
    };

    root.querySelectorAll('input[type="range"]').forEach((slider) => {
      slider.addEventListener(
        "pointerdown",
        () => {
          try {
            slider.focus({ preventScroll: true });
          } catch {
            slider.focus();
          }
        },
        { passive: true, signal: ac.signal },
      );
    });

    root.addEventListener(
      "wheel",
      (event) => {
        const slider = event.target?.closest?.('input[type="range"]');
        if (!slider || !root.contains(slider)) return;

        event.preventDefault();
        event.stopImmediatePropagation();

        if (isFocusedSlider(slider)) {
          const step = Number.parseFloat(slider.step || "1") || 1;
          const cur = Number.parseFloat(slider.value || "0") || 0;
          const dir = event.deltaY < 0 ? 1 : -1;
          applySliderValue(slider, cur + dir * step);
          return;
        }

        try {
          slider.blur?.();
        } catch (err) {
          logger.debug("FXMaster:", err);
        }
        const wrapper = resolveScrollWrapper(slider);
        wrapper.scrollTop += event.deltaY;
      },
      { passive: false, capture: true, signal: ac.signal },
    );

    root.addEventListener(
      "keydown",
      (event) => {
        const slider = event.target?.closest?.('input[type="range"]');
        if (!slider || !root.contains(slider) || !isFocusedSlider(slider)) return;

        const key = String(event.key || "");
        const cur = Number.parseFloat(slider.value || "0") || 0;
        const step = Number.parseFloat(slider.step || "1") || 1;
        const pageStep = step * 10;
        const min = Number.parseFloat(slider.min);
        const max = Number.parseFloat(slider.max);

        let next = null;
        switch (key) {
          case "ArrowLeft":
          case "ArrowDown":
            next = cur - step;
            break;
          case "ArrowRight":
          case "ArrowUp":
            next = cur + step;
            break;
          case "PageDown":
            next = cur - pageStep;
            break;
          case "PageUp":
            next = cur + pageStep;
            break;
          case "Home":
            next = Number.isFinite(min) ? min : cur;
            break;
          case "End":
            next = Number.isFinite(max) ? max : cur;
            break;
          default:
            return;
        }

        event.preventDefault();
        event.stopImmediatePropagation();
        applySliderValue(slider, next);
      },
      { capture: true, signal: ac.signal },
    );

    root.addEventListener(
      "input",
      (event) => {
        const slider = event.target?.closest?.('input[type="range"]');
        if (!slider || !root.contains(slider)) return;
        syncSlider(slider, event);
      },
      { capture: true, signal: ac.signal },
    );

    root.addEventListener(
      "change",
      (event) => {
        const slider = event.target?.closest?.('input[type="range"]');
        if (!slider || !root.contains(slider)) return;
        this.constructor.syncDualRangeInput(slider);
        this.constructor.updateRangeOutput(slider);
      },
      { capture: true, signal: ac.signal },
    );
  }

  /**
   * Remove synchronized-direction live control listeners.
   *
   * @returns {void}
   */
  _fxmUnwireSynchronizedDirectionControls() {
    try {
      this._fxmSynchronizedDirectionAbort?.abort?.();
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
    this._fxmSynchronizedDirectionAbort = null;
    if (this._fxmSynchronizedDirectionHook) {
      try {
        globalThis.Hooks?.off?.("fxmasterSynchronizedDirectionSourceChanged", this._fxmSynchronizedDirectionHook);
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
      this._fxmSynchronizedDirectionHook = null;
    }
  }

  /**
   * Apply synchronized-direction disabled state without rerendering the app.
   *
   * @returns {void}
   */
  _fxmWireSynchronizedDirectionControls() {
    this._fxmUnwireSynchronizedDirectionControls();

    const root = this.element;
    if (!root) return;

    const ac = new AbortController();
    this._fxmSynchronizedDirectionAbort = ac;
    const apply = () => this.constructor._fxmApplySynchronizedDirectionControls(root);
    const schedule = (event) => {
      if (this.constructor._fxmIsColorControlEvent(event)) return;
      requestAnimationFrame(apply);
    };

    apply();
    root.addEventListener("change", schedule, { signal: ac.signal, capture: true });
    root.addEventListener("input", schedule, { signal: ac.signal, capture: true });

    this._fxmSynchronizedDirectionHook = schedule;
    globalThis.Hooks?.on?.("fxmasterSynchronizedDirectionSourceChanged", schedule);
  }

  /**
   * Resolve a synchronized-direction field prefix from a form control name.
   *
   * @param {string} name
   * @returns {string|null}
   */
  static _fxmSynchronizedDirectionPrefix(name) {
    const text = String(name ?? "");
    const suffix = "_synchronizedDirection";
    return text.endsWith(suffix) ? text.slice(0, -suffix.length) : null;
  }

  /**
   * Resolve the synchronized-direction context for form locking.
   *
   * @param {object|null|undefined} [options]
   * @returns {object|null}
   */
  static _fxmSynchronizedDirectionContext(options = null) {
    const explicit = options?.__fxmRuntimeContext ?? options?.__fxmParticleContext ?? null;
    if (explicit && typeof explicit === "object") return explicit;
    const sceneId = canvas?.scene?.id ?? null;
    return sceneId ? { scope: "scene", sceneId } : null;
  }

  /**
   * Build the synchronized-direction lock tooltip.
   *
   * @returns {string}
   */
  static _fxmSynchronizedDirectionTooltip(context = null) {
    const source = CONFIG.fxmaster?.getSynchronizedDirectionSourceLabel?.("", context) ?? "";
    if (source) return game.i18n.format("FXMASTER.ParamTooltips.SynchronizedDirectionControlledBy", { source });
    return "";
  }

  /**
   * Apply direction-control enabled state for every synchronized-direction toggle in a rendered form.
   *
   * @param {HTMLElement|null|undefined} root
   * @returns {void}
   */
  static _fxmApplySynchronizedDirectionControls(root) {
    if (!root) return;

    const directionParams = ["direction", "flowDirection", "waveDirection"];
    const tooltipDirection = String(game?.settings?.get?.(packageId, "tooltipDirection") ?? "UP").toUpperCase();
    const direction = ["UP", "DOWN", "LEFT", "RIGHT"].includes(tooltipDirection) ? tooltipDirection : "UP";

    for (const toggle of root.querySelectorAll('input[name$="_synchronizedDirection"]')) {
      const prefix = this._fxmSynchronizedDirectionPrefix(toggle.name);
      if (!prefix) continue;
      const enabled = this._fxmReadInputValue(toggle) === true;
      const context = this._fxmSynchronizedDirectionContext();
      const locked = enabled && (CONFIG.fxmaster?.hasSynchronizedDirectionSource?.(context) ?? false);
      const tooltip = locked ? this._fxmSynchronizedDirectionTooltip(context) : "";

      for (const param of directionParams) {
        const name = `${prefix}_${param}`;
        const controls = Array.from(root.querySelectorAll(`[name="${CSS.escape(name)}"]`)).filter(
          (el) => el?.dataset?.fxmSynchronizedDirectionHidden !== "true",
        );
        for (const control of controls) {
          const tag = String(control?.tagName ?? "").toLowerCase();
          if (!["input", "select", "textarea"].includes(tag)) continue;
          if (control.dataset.fxmOriginalTooltip === undefined) control.dataset.fxmOriginalTooltip = control.dataset.tooltip ?? "";
          if (control.dataset.fxmOriginalTooltipDirection === undefined) {
            control.dataset.fxmOriginalTooltipDirection = control.dataset.tooltipDirection ?? "";
          }

          control.disabled = locked;
          if (locked) {
            control.setAttribute("aria-disabled", "true");
            control.dataset.tooltip = tooltip;
            control.dataset.tooltipDirection = direction;
            let hidden = control.parentElement?.querySelector(
              `input[type="hidden"][name="${CSS.escape(name)}"][data-fxm-synchronized-direction-hidden="true"]`,
            );
            if (!hidden) {
              hidden = document.createElement("input");
              hidden.type = "hidden";
              hidden.name = name;
              hidden.dataset.fxmSynchronizedDirectionHidden = "true";
              control.insertAdjacentElement("afterend", hidden);
            }
            hidden.value = control.value ?? "";
          } else {
            control.removeAttribute("aria-disabled");
            const originalTip = control.dataset.fxmOriginalTooltip ?? "";
            const originalDir = control.dataset.fxmOriginalTooltipDirection ?? "";
            if (originalTip) control.dataset.tooltip = originalTip;
            else delete control.dataset.tooltip;
            if (originalDir) control.dataset.tooltipDirection = originalDir;
            else delete control.dataset.tooltipDirection;
            for (const hidden of root.querySelectorAll(
              `input[type="hidden"][name="${CSS.escape(name)}"][data-fxm-synchronized-direction-hidden="true"]`,
            )) {
              hidden.remove();
            }
          }
        }
      }
    }
  }

  /**
   * Remove any previously-attached conditional visibility listeners.
   */
  _fxmUnwireConditionalVisibility() {
    try {
      this._fxmConditionalVisibilityAbort?.abort();
    } catch (err) {
      logger.debug("FXMaster:", err);
    }
    this._fxmConditionalVisibilityAbort = null;
    this._fxmConditionalVisibilityRules = null;
  }

  /**
   * Wire conditional parameter visibility based on other parameter values.
   *
   * Parameter configs can declare `showWhen`, `hideWhen`, `regionOnly`, or `sceneOnly`.
   */
  _fxmWireConditionalVisibility() {
    this._fxmUnwireConditionalVisibility();

    const root = this.element;
    if (!root) return;

    const sources = [];
    try {
      const cfg = CONFIG?.fxmaster;
      if (cfg?.particleEffects) sources.push(cfg.particleEffects);
      if (cfg?.filterEffects) sources.push(cfg.filterEffects);
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    if (!sources.length) return;

    const ac = new AbortController();
    this._fxmConditionalVisibilityAbort = ac;

    const rules = [];

    for (const defs of sources) {
      for (const cls of Object.values(defs ?? {})) {
        const label = cls?.label;
        const params = cls?.parameters;
        if (!label || !params) continue;

        for (const [paramName, paramCfg] of Object.entries(params)) {
          const showWhen = paramCfg?.showWhen;
          const hideWhen = paramCfg?.hideWhen;
          const regionOnly = !!paramCfg?.regionOnly;
          const sceneOnly = !!paramCfg?.sceneOnly;
          if (!showWhen && !hideWhen && !regionOnly && !sceneOnly) continue;

          const inputName = `${label}_${paramName}`;
          const input =
            root.querySelector(`[name="${inputName}"]`) ||
            root.querySelector(`[name="${inputName}_apply"]`) ||
            root.querySelector(`[name="${inputName}_min"]`) ||
            root.querySelector(`[name="${inputName}_max"]`) ||
            null;
          if (!input || input.dataset?.fxmHiddenParameter === "true") continue;

          const row = this.constructor._fxmFindFieldRow(input, root);
          if (!row) continue;

          rules.push({ label, paramName, showWhen, hideWhen, regionOnly, sceneOnly, row });
        }
      }
    }

    if (!rules.length) return;

    this._fxmConditionalVisibilityRules = rules;

    const getValue = (effectLabel, dep) => {
      const nm = `${effectLabel}_${dep}`;
      const el = root.querySelector(`[name="${nm}"]`) || root.querySelector(`[name="${nm}_apply"]`) || null;
      return this.constructor._fxmReadInputValue(el);
    };

    const evalCond = (cond, effectLabel) => {
      if (!cond) return true;
      if (Array.isArray(cond)) return cond.some((entry) => evalCond(entry, effectLabel));
      if (typeof cond === "function") {
        try {
          return !!cond({ get: (k) => getValue(effectLabel, k) });
        } catch {
          return true;
        }
      }
      if (typeof cond === "object") {
        return Object.entries(cond).every(([k, expected]) => {
          const actual = getValue(effectLabel, k);
          return this.constructor._fxmLooseEquals(actual, expected);
        });
      }
      return true;
    };

    const applyAll = () => {
      const isRegionContext = false;
      for (const r of rules) {
        const showOk = evalCond(r.showWhen, r.label);
        const hideOk = r.hideWhen ? evalCond(r.hideWhen, r.label) : false;
        const regionOk = !r.regionOnly || isRegionContext;
        const sceneOk = !r.sceneOnly || !isRegionContext;
        const syncDirectionOk = r.paramName !== "synchronizedDirection" || (CONFIG.fxmaster?.synchronizedDirectionAvailable?.() ?? false);
        const visible = showOk && !hideOk && regionOk && sceneOk && syncDirectionOk;
        r.row.style.display = visible ? "" : "none";
      }
    };

    applyAll();

    let raf = null;
    const schedule = (event) => {
      if (this.constructor._fxmIsColorControlEvent(event)) return;
      if (raf != null) return;
      raf = requestAnimationFrame(() => {
        raf = null;
        applyAll();
      });
    };

    root.addEventListener("change", schedule, { signal: ac.signal, capture: true });
    root.addEventListener("input", schedule, { signal: ac.signal, capture: true });
  }

  /**
   * Best-effort read of an input's current value.
   * @param {HTMLElement|null} el
   */
  static _fxmReadInputValue(el) {
    if (!el) return undefined;

    const tag = (el.tagName ?? "").toLowerCase();
    if (tag === "multi-select") {
      const mv = el?.value;
      if (mv instanceof Set) return Array.from(mv);
      if (Array.isArray(mv)) return mv;

      const tags = el?.querySelectorAll?.("tag") ?? [];
      if (tags.length) {
        const vals = Array.from(tags)
          .map((t) => t.value)
          .filter((v) => v != null && v !== "");
        if (vals.length) return vals;
      }

      const inner = el?.querySelector?.("select[multiple]");
      if (String(inner?.tagName ?? "").toLowerCase() === "select") {
        return Array.from(inner.selectedOptions).map((o) => o.value);
      }

      const hidden = el?.querySelectorAll?.('input[type="hidden"][name$="[]"]') ?? [];
      if (hidden.length) {
        const vals = Array.from(hidden)
          .map((h) => h.value)
          .filter((v) => v != null && v !== "");
        if (vals.length) return vals;
      }

      if (typeof mv === "string" && mv.length) {
        try {
          const parsed = JSON.parse(mv);
          if (Array.isArray(parsed)) return parsed;
        } catch (err) {
          logger.debug("FXMaster:", err);
        }
      }

      return [];
    }

    if (tag === "select") {
      if (el.multiple) return Array.from(el.selectedOptions).map((o) => o.value);
      return el.value;
    }

    if (tag === "input") {
      if (el.type === "checkbox") return !!el.checked;
      if (el.type === "range" || el.type === "number") {
        const n = Number(el.value);
        return Number.isFinite(n) ? n : undefined;
      }
      return el.value;
    }

    if (tag === "color-picker") {
      const v = el.value ?? el.getAttribute?.("value");
      return v;
    }
    if (el?.value instanceof Set) return Array.from(el.value);
    return el.value ?? el.getAttribute?.("value");
  }

  /**
   * Loose equality that handles common HTML coercions (e.g., "true" vs true).
   */
  static _fxmLooseEquals(actual, expected) {
    if (typeof expected === "boolean") {
      if (typeof actual === "string") return (actual === "true") === expected;
      return !!actual === expected;
    }

    if (typeof expected === "number") {
      const n = Number(actual);
      if (!Number.isFinite(n)) return false;
      return n === expected;
    }

    if (Array.isArray(expected)) {
      if (!Array.isArray(actual)) return false;
      return expected.length === actual.length && expected.every((v) => actual.includes(v));
    }

    return actual === expected;
  }

  /**
   * Attempt to find the container element that represents a single "row" for a given parameter control.
   */
  static _fxmFindFieldRow(el, root) {
    if (!el) return null;

    const selectors = [
      ".form-group",
      ".fxmaster-setting",
      ".fxmaster-param",
      ".fxmaster-parameter",
      ".fxmaster-filter-param",
      ".fxmaster-particle-param",
      ".fxmaster-param-field",
      ".fxmaster-particles-param",
      ".fxmaster-filters-param",
      ".setting",
    ];

    for (const sel of selectors) {
      const row = el.closest(sel);
      if (row && row !== root && root.contains(row)) return row;
    }

    const wrapper = el.closest(
      ".fxmaster-input-range, .fxmaster-input-range-dual, .fxmaster-input-checkbox, .fxmaster-input-color, .fxmaster-input-multi, .fxmaster-input-select",
    );
    if (wrapper) {
      const parent = wrapper.parentElement;
      if (parent && parent !== root) return parent;
      if (wrapper !== root) return wrapper;
    }

    const parent = el.parentElement;
    if (parent?.matches?.(".fxmaster-particle-params, .fxmaster-filter-params")) return null;
    if (parent && parent !== root) return parent;
    return null;
  }

  animateTitleBar(app) {
    const titleBackground = app?.element?.querySelector(".window-header");
    if (!titleBackground) return;

    const win = titleBackground.ownerDocument?.defaultView ?? globalThis.window;
    try {
      const previous = app._fxmTitleBarAnimation;
      if (previous?.frame != null) previous.win?.cancelAnimationFrame?.(previous.frame);
    } catch (err) {
      logger.debug("FXMaster:", err);
    }

    const duration = 20000;
    let startTime = null;
    const animation = { win, frame: null };
    app._fxmTitleBarAnimation = animation;

    titleBackground.style.border = "2px solid";
    titleBackground.style.borderImageSlice = 1;

    const { baseColor, highlightColor } = getDialogColors();

    const step = (timestamp) => {
      if (!titleBackground.isConnected || app._fxmTitleBarAnimation !== animation) {
        if (app._fxmTitleBarAnimation === animation) app._fxmTitleBarAnimation = null;
        return;
      }
      if (!startTime) startTime = timestamp;
      const elapsed = timestamp - startTime;
      const progress = (elapsed % duration) / duration;
      const angle = 360 * progress;

      titleBackground.style.borderImage = `linear-gradient(${angle}deg, ${baseColor}, ${highlightColor}, ${baseColor}) 1`;
      animation.frame = win.requestAnimationFrame(step);
    };

    animation.frame = win.requestAnimationFrame(step);
  }
}
